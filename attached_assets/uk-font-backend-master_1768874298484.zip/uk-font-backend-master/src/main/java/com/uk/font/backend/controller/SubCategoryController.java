package com.uk.font.backend.controller;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.dto.SubCategoryResponseDTO;
import com.uk.font.backend.service.SubCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/category")
public class SubCategoryController {

    @Autowired
    SubCategoryService categoryService;

    @GetMapping("/{name}")
    ResponseDTO getCategoryByName(@PathVariable String name){
        return categoryService.getCategoryByName(name);
    }

    @GetMapping("filter/{name}")
    ResponseDTO getFilterCategoryByName(@PathVariable String name){
        return categoryService.getFilterCategoryByName(name);
    }

    @GetMapping("/list")
    ResponseDTO getCategoryListByName(@RequestParam(value = "name",required = false) String name,
                                      @RequestParam(value = "pageNumber",required = false) Integer pageNumber,
                                      @RequestParam(value = "pageSize",required = false) Integer pageSize){
        return categoryService.getCategoryListByName(name,pageNumber,pageSize);
    }
    @PostMapping("/add/new")
    ResponseEntity<ResponseDTO> addCategory(@RequestBody SubCategoryResponseDTO category ){
        return categoryService.addCategory(category);
    }

}
