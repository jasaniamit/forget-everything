package com.uk.font.backend.entity;

import javax.persistence.*;
import java.util.List;
/**
 * Created by Kapil Chauhan on 10/08/21.
 */
@Entity
public class Designer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String name;
    private String email;
    private String website;
    private String designerImageUrl;
    private String designerInfo;
    private String licensedAs;
    private String commercialLicences;

    @OneToMany(mappedBy = "designer",cascade = CascadeType.ALL)
    private List<Font> fonts;

    @OneToOne(mappedBy = "designer")
    private SocialMedia socialMedia;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public List<Font> getFonts() {
        return fonts;
    }

    public void setFonts(List<Font> fonts) {
        this.fonts = fonts;
    }

    public SocialMedia getSocialMedia() {
        return socialMedia;
    }

    public void setSocialMedia(SocialMedia socialMedia) {
        this.socialMedia = socialMedia;
    }

    public String getDesignerImageUrl() {
        return designerImageUrl;
    }

    public void setDesignerImageUrl(String designerImageUrl) {
        this.designerImageUrl = designerImageUrl;
    }

    public String getDesignerInfo() {
        return designerInfo;
    }

    public void setDesignerInfo(String designerInfo) {
        this.designerInfo = designerInfo;
    }

    public String getLicensedAs() {
        return licensedAs;
    }

    public void setLicensedAs(String licensedAs) {
        this.licensedAs = licensedAs;
    }


    public String getCommercialLicences() {
        return commercialLicences;
    }

    public void setCommercialLicences(String commercialLicences) {
        this.commercialLicences = commercialLicences;
    }
}
