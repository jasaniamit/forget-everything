package com.uk.font.backend.repository;

import com.uk.font.backend.entity.Font;
import com.uk.font.backend.entity.SubCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FontRepository extends JpaRepository<Font, Integer> {

    Font findByNameAndActive(String fontName, boolean active);

    List<Font> findAllByActive(boolean b);

    Font findByIdAndActive(Integer id, boolean b);


    Integer countByNameContainingIgnoreCaseAndActive(String name, boolean b);

    Font findByName(String name);

    List<Font> findAllBySubCategoryAndActive(SubCategory subCategory, boolean b);
}
