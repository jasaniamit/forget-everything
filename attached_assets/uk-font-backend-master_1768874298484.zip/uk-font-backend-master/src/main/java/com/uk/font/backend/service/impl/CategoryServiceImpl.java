package com.uk.font.backend.service.impl;

import com.uk.font.backend.dto.CategoryResponseDTO;
import com.uk.font.backend.dto.NameAndIdDTO;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.entity.Category;
import com.uk.font.backend.entity.SubCategory;
import com.uk.font.backend.repository.CategoryRepository;
import com.uk.font.backend.service.CategoryService;
import com.uk.font.backend.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    private static final Logger log = LoggerFactory.getLogger(CategoryServiceImpl.class);

    @Override
    public ResponseDTO getCategoryList() {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        List<CategoryResponseDTO> categoryResponseDTOList = new ArrayList<>();
        List<Category> categoryList = categoryRepository.findAll();
        categoryList.forEach(category -> {
            CategoryResponseDTO dto = new CategoryResponseDTO();
            dto.setName(category.getName());
            dto.setId(category.getId());
            List<SubCategory> subCategories = category.getSubCategories();
            List<NameAndIdDTO> dtoList = new ArrayList<>();
            subCategories.forEach(subCategory -> {
                NameAndIdDTO nameAndIdDTO = new NameAndIdDTO();
                nameAndIdDTO.setId(subCategory.getId());
                nameAndIdDTO.setName(subCategory.getName());
                dtoList.add(nameAndIdDTO);
            });
            dto.setSubCategory(dtoList);
            categoryResponseDTOList.add(dto);
        });
        if (!CollectionUtils.isEmpty(categoryResponseDTOList)) {

            responseDTO.setCode(Constant.OK);
            responseDTO.setData(categoryResponseDTOList);
            responseDTO.setStatus(Boolean.TRUE);
            responseDTO.setMessage(Constant.REQUEST_SUCCESS);
            log.info("Category List");
        } else {
            responseDTO.setMessage(Constant.NO_DATA_FOUND);
            log.info("No data found");
        }

        return responseDTO;
    }

    @Override
    public ResponseEntity<ResponseDTO> addCategory(NameAndIdDTO category) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        Category existing = categoryRepository.findByName(category.getName());
        if (Objects.nonNull(existing)) {
            responseDTO.setCode(Constant.BAD_REQUEST);
            responseDTO.setMessage("Category with name " + category.getName() + " already present");
            log.info("category already present");
            return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
        }
        Category newCategory = new Category();
        newCategory.setName(category.getName());
        categoryRepository.save(newCategory);
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        responseDTO.setCode(Constant.OK);
        log.info("category saved success");
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
}
