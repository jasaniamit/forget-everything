package com.uk.font.backend.service.impl;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.StorageOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.StorageClient;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.dto.UploadResponseDTO;
import com.uk.font.backend.entity.Font;
import com.uk.font.backend.repository.FontRepository;
import com.uk.font.backend.service.FirebaseService;
import com.uk.font.backend.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.uk.font.backend.util.FilePath.*;


@Service
public class FirebaseServiceImpl implements FirebaseService {

    @Value("${firebase.bucket.name}")
    private String bucketName;

    @Value("${firebase.server.config}")
    private String serverConfig;

    @Autowired
    private FontRepository fontRepository;

    private static final Logger log = LoggerFactory.getLogger(FirebaseServiceImpl.class);


    @Override
    public ResponseDTO uploadFile(MultipartFile[] files, String filetype) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        List<UploadResponseDTO> list = new ArrayList<>();
        for (MultipartFile file : files) {
            UploadResponseDTO uploadResponseDTO = new UploadResponseDTO();
            try {
                String fontFileName = file.getOriginalFilename();
                File fileFont = convertToFile(file, fontFileName);
                String FONT_URL = upload(fileFont, fontFileName, filetype);
                fileFont.delete();

                uploadResponseDTO.setFileName(file.getOriginalFilename());
                uploadResponseDTO.setUrl(FONT_URL);
                uploadResponseDTO.setStatus("SUCCESS");

                responseDTO.setStatus(Boolean.TRUE);
                responseDTO.setCode(Constant.OK);
                responseDTO.setMessage("Successfully Uploaded ! ");
                log.info("upload success.");
            } catch (Exception e) {
                responseDTO.setMessage("Unsuccessfully Uploaded! " + e);
                e.printStackTrace();
                responseDTO.setCode(Constant.EXCEPTION_FAILED);
                uploadResponseDTO.setStatus("FAILED");
                log.info("Unsuccessfully Uploaded!");
            }
            list.add(uploadResponseDTO);
        }
        responseDTO.setData(list);
        return responseDTO;
    }

    @Override
    public ResponseEntity<ResponseDTO> delete(Integer id) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        Font font = fontRepository.findByIdAndActive(id, true);

        if (Objects.nonNull(font)) {
            try {
                boolean delete = true;//getBucket().get(font.getFileName()).delete();
                if (delete) {
                    font.setActive(Boolean.FALSE);
                    fontRepository.save(font);
                    responseDTO.setMessage("Font deleted success");
                    responseDTO.setCode(Constant.OK);
                    responseDTO.setStatus(Boolean.TRUE);
                    log.info("Font deleted success");
                    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
                } else {
                    responseDTO.setMessage(Constant.REQUEST_NOT_PROCESSED);
                    responseDTO.setCode(Constant.BAD_REQUEST);
                    return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
                }
            } catch (Exception e) {
                log.info("Exception while deleting " + e);
                e.printStackTrace();
                responseDTO.setMessage("Exception while deleting " + e);
                responseDTO.setCode(Constant.EXCEPTION_FAILED);
                responseDTO.setStatus(Boolean.FALSE);
            }
        } else {
            responseDTO.setMessage(Constant.NO_DATA_FOUND);
            responseDTO.setCode(Constant.BAD_REQUEST);
            log.info("No Data found.");
            return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(responseDTO,HttpStatus.EXPECTATION_FAILED);
    }

    private String upload(File file, String fileName, String fileType) throws IOException {

        String DOWNLOAD_URL = "https://firebasestorage.googleapis.com/v0/b/" + bucketName + "/o/%s?alt=media";

        String filepath = createFilePath(fileType, fileName);

        BlobId blobId = BlobId.of(bucketName, filepath);
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("media").build();
        StorageOptions
                .newBuilder()
                .setCredentials(GoogleCredentials.fromStream(new FileInputStream(serverConfig)))
                .build()
                .getService()
                .create(blobInfo, Files.readAllBytes(file.toPath()));
        return String.format(DOWNLOAD_URL, URLEncoder.encode(fileName, String.valueOf(StandardCharsets.UTF_8)));
    }

    private String createFilePath(String fileType, String fileName) {

        if (StringUtils.hasText(fileName)) {
            if (fileType.equals(FONT)) {
                return "Fonts/" + fileName;
            } else if (fileType.equals(CATEGORY)) {
                return "Category/" + fileName;
            } else if (fileType.equals(PICTURE)) {
                return "Designer/" + fileName;
            } else if (fileType.equals(ZIP)) {
                return "ZIP/" + fileName;
            } else if (fileType.equals(FONT_IMG)) {
                return "FontImage/" + fileName;
            } else {
                return fileName;
            }
        }
        return fileName;
    }

    private File convertToFile(MultipartFile multipartFile, String fileName) {
        File tempFile = new File(fileName);
        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            fos.write(multipartFile.getBytes());
        } catch (Exception e) {
            log.info("Exception while converting to file " + e);
            e.printStackTrace();
        }
        return tempFile;
    }

    private Bucket getBucket() throws IOException {
        log.info("getting bucket ..");
        FirebaseOptions options = FirebaseOptions
                .builder()
                .setCredentials(GoogleCredentials.fromStream(new FileInputStream(serverConfig)))
                .setStorageBucket(bucketName)
                .build();
        FirebaseApp.initializeApp(options);
        return StorageClient.getInstance().bucket();
    }
}
