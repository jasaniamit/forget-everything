package com.uk.font.backend.util;

public final class Constant {

    public final static String OK = "200";
    public final static String BAD_REQUEST = "400";
    public final static String FOR_BIDDEN = "403";
    public final static String UNAUTHORIZED = "401";
    public final static String EXCEPTION_FAILED = "500";
    public final static String REQUEST_SUCCESS = "Request Processed Successfully";
    public final static String REQUEST_NOT_PROCESSED = "Unable to process request";
    public final static String NO_DATA_FOUND = "No data found";


    private Constant() {
    }
}
