package com.uk.font.backend.entity;

import javax.persistence.*;
/**
 * Created by Kapil Chauhan on 10/08/21.
 */
@Entity
public class SocialMedia {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String facebook;
    private String instagram;
    private String linkedIn;
    private String twitter;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "designerId")
    private Designer designer;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public String getLinkedIn() {
        return linkedIn;
    }

    public void setLinkedIn(String linkedIn) {
        this.linkedIn = linkedIn;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public Designer getDesigner() {
        return designer;
    }

    public void setDesigner(Designer designer) {
        this.designer = designer;
    }
}
