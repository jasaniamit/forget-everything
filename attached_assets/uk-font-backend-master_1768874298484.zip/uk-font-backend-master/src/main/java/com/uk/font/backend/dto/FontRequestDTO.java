package com.uk.font.backend.dto;

import java.util.List;

public class FontRequestDTO {
    private String fontName;
    private String url;
    private String about;
    private String license;
    private String description;
    private List<ImageDTO> fontImage;
    private String fontZipUrl;
    private boolean commercial;

    public String getFontName() {
        return fontName;
    }

    public void setFontName(String fontName) {
        this.fontName = fontName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public boolean isCommercial() {
        return commercial;
    }

    public void setCommercial(boolean commercial) {
        this.commercial = commercial;
    }

    public List<ImageDTO> getFontImage() {
        return fontImage;
    }

    public void setFontImage(List<ImageDTO> fontImage) {
        this.fontImage = fontImage;
    }

    public String getFontZipUrl() {
        return fontZipUrl;
    }

    public void setFontZipUrl(String fontZipUrl) {
        this.fontZipUrl = fontZipUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
