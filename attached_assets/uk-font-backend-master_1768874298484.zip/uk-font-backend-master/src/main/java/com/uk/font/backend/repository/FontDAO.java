package com.uk.font.backend.repository;

import com.uk.font.backend.dto.FontDTO;
import com.uk.font.backend.dto.FontResponseDTO;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.dto.StyleDTO;
import com.uk.font.backend.entity.FontStyle;
import com.uk.font.backend.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Repository
public class FontDAO {

    @Autowired
    private JdbcTemplate jdbcTemplateRead;
    @Autowired
    private FontRepository fontRepository;
    @Autowired
    private DesignerRepository designerRepository;

    public FontResponseDTO getFilteredFontList(ResponseDTO responseDTO, String name, Integer pageNumber, Integer pageSize, Character alphabet, Boolean isCommercial, StyleDTO styleDTO, String category, Integer designer) {

        FontResponseDTO fontResponseDTO = new FontResponseDTO();
        String query = "select *,COUNT(*) OVER () as total_count from font";

        if (styleDTO != null) {
            query = query + " JOIN font_style ON font.id = font_style.font_id  ";
            query = filterOnStyle(query, styleDTO);
        }
        if (category != null && category != "") {
            query = query + " join sub_category sc on font.sub_category_id = sc.id where sc.name = '" + category + "'";
        }

        if (name != null && name != "") {
            query = query + " and name like '%" + name + "%'";
        }
        if (alphabet != null) {
            query = query + " and name like '" + alphabet + "%'";
        }

        if (isCommercial != null) {
            query = query + " and is_commercial =  " + isCommercial;
        }

        if (designer != null) {
            query = query + " and designer_id = " + designer;
        }
        query = query + " and active = true limit " + pageSize + " OFFSET " + pageNumber * pageSize;

        RowMapper<FontDTO> rowMapper = (rs, rowNum) -> {
            FontDTO data = new FontDTO();
            data.setId(rs.getInt("id"));
            data.setLicense(rs.getString("license"));
            data.setFontName(rs.getString("name"));
            data.setBody(rs.getString("body"));
            data.setUrl(rs.getString("url"));
            data.setCommercial(rs.getBoolean("is_commercial"));
            data.setExtension(rs.getString("font_extension"));
            data.setDesigner(rs.getInt("designer_id"));
            data.setFontZipUrl(rs.getString("font_zip_url"));
            fontResponseDTO.setTotalCount(rs.getInt("total_count"));
            data.setStyles(setStyles(fontRepository.findById(data.getId()).get().getFontStyle()));
            data.setDesignerName(designerRepository.findById(data.getDesigner()).get().getName());

            return data;
        };
        List<FontDTO> fontDTOS = null;
        try {
            fontDTOS = jdbcTemplateRead.query(query, rowMapper);
        } catch (Exception e) {
            responseDTO.setMessage(e.getMessage());
            responseDTO.setCode(Constant.BAD_REQUEST);
        }
        fontResponseDTO.setFontDTO(fontDTOS);
        return fontResponseDTO;
    }


    private String filterOnStyle(String query, StyleDTO styleDTO) {
        if (styleDTO.getHeight() != null && styleDTO.getHeight() != "") {
            query = query + " and height = '" + styleDTO.getHeight() + "'";
        }
        if (styleDTO.getWidth() != null && styleDTO.getWidth() != "") {
            query = query + " and width = '" + styleDTO.getWidth() + "'";
        }
        if (styleDTO.getWeight() != null && styleDTO.getWeight() != "") {
            query = query + " and weight = '" + styleDTO.getWeight() + "'";
        }
        if (styleDTO.getContrast() != null && styleDTO.getContrast() != "") {
            query = query + " and contrast = '" + styleDTO.getContrast() + "'";
        }
        if (styleDTO.getFigure() != null && styleDTO.getFigure() != "") {
            query = query + " and figure = '" + styleDTO.getFigure() + "'";
        }
        if (styleDTO.getStandardOrCaps() != null && styleDTO.getStandardOrCaps() != "") {
            query = query + " and standard_or_caps = '" + styleDTO.getStandardOrCaps() + "'";
        }
        return query;
    }

    private Map<String, String> setStyles(FontStyle fontStyle) {

        if (Objects.nonNull(fontStyle)) {
            Map<String, String> styles = new HashMap<>();
            styles.put("Height", fontStyle.getHeight());
            styles.put("Weight", fontStyle.getWeight());
            styles.put("Width", fontStyle.getWidth());
            styles.put("Contrast", fontStyle.getContrast());
            styles.put("Figure", fontStyle.getFigure());
            styles.put("Standard Or Caps", fontStyle.getStandardOrCaps());

            return styles;
        }
        return null;
    }
}
