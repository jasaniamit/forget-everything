package com.uk.font.backend.service;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.dto.SubCategoryResponseDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface SubCategoryService {
    ResponseDTO getCategoryByName(String name);

    ResponseDTO getFilterCategoryByName(String name);


    ResponseDTO getCategoryListByName(String name, Integer pageNumber, Integer pageSize);

    ResponseEntity<ResponseDTO> addCategory(SubCategoryResponseDTO category);
}
