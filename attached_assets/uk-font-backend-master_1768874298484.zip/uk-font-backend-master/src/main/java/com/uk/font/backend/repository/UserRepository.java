package com.uk.font.backend.repository;

import com.uk.font.backend.entity.UserTable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserTable,Integer> {
    UserTable findByUserName(String username);
}
