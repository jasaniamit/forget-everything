package com.uk.font.backend.repository;

import com.uk.font.backend.entity.SubCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubCategoryRepository extends JpaRepository<SubCategory,Integer> {
    SubCategory findByName(String name);

    List<SubCategory> findByNameIgnoreCaseContaining(String name);

    Integer countByNameContainingIgnoreCase(String name);
}
