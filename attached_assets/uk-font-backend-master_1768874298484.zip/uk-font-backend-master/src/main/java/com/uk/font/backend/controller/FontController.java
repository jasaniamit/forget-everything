package com.uk.font.backend.controller;

import com.uk.font.backend.dto.FontUploadDTO;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.service.FontService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/font")
public class FontController {

    @Autowired
    private FontService fontService;

    private static final Logger log = LoggerFactory.getLogger(FontController.class);


    @GetMapping("/list")
    ResponseDTO fetFontList(@RequestParam(value = "pageNumber", required = false) Integer pageNumber,
                            @RequestParam(value = "pageSize", required = false) Integer pageSize,
                            @RequestParam(value = "name", required = false) String name,
                            @RequestParam(value = "alphabet", required = false) Character alphabet,
                            @RequestParam(value = "isCommercial", required = false) Boolean isCommercial,
                            @RequestParam(value = "weight", required = false) String weight,
                            @RequestParam(value = "figure", required = false) String figure,
                            @RequestParam(value = "height", required = false) String height,
                            @RequestParam(value = "contrast", required = false) String contrast,
                            @RequestParam(value = "standardOrCaps", required = false) String standardOrCaps,
                            @RequestParam(value = "category", required = false) String category,
                            @RequestParam(value = "designer", required = false) Integer designer,
                            @RequestParam(value = "width", required = false) String width) {
        return fontService.getFontList(pageNumber, pageSize, name, alphabet, isCommercial, weight, figure, height, contrast, standardOrCaps, width, category, designer);
    }

    @GetMapping("/name/list")
    ResponseDTO fontNameList() {
        return fontService.fontNameList();
    }

    @PostMapping("/save")
    ResponseEntity<ResponseDTO> saveFont(@RequestBody FontUploadDTO fontUploadDTO) {
        return fontService.saveFont(fontUploadDTO);
    }

    @GetMapping("/{name}")
    ResponseDTO getByName(@PathVariable String name) {
        return fontService.getByName(name);
    }

    @GetMapping("/map")
    ResponseDTO getFontMap(){
        return fontService.getFontMap();
    }

}
