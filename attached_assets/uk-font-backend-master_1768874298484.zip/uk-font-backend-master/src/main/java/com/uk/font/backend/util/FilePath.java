package com.uk.font.backend.util;

public enum FilePath {
    FONT,
    CATEGORY,
    PICTURE,
    ZIP,
    FONT_IMG;
}
