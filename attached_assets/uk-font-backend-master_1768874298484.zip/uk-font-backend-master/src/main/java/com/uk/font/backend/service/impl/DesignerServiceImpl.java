package com.uk.font.backend.service.impl;

import com.uk.font.backend.dto.*;
import com.uk.font.backend.dto.DesignerSearchDTO.DSearchDTO;
import com.uk.font.backend.entity.Designer;
import com.uk.font.backend.entity.SocialMedia;
import com.uk.font.backend.repository.DesignerDAO;
import com.uk.font.backend.repository.DesignerRepository;
import com.uk.font.backend.service.DesignerService;
import com.uk.font.backend.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class DesignerServiceImpl implements DesignerService {

    @Autowired
    private DesignerRepository designerRepository;
    @Autowired
    private DesignerDAO designerDAO;

    private static final Logger log = LoggerFactory.getLogger(DesignerServiceImpl.class);


    @Override
    public ResponseDTO designerInfo(Integer id) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        Optional<Designer> optionalDesigner = designerRepository.findById(id);
        if (optionalDesigner.isPresent()) {
            Designer designer = optionalDesigner.get();
            DesignerResponseDTO dto = mapDesignerToDTO(designer);
            responseDTO.setCode(Constant.OK);
            responseDTO.setStatus(Boolean.TRUE);
            responseDTO.setMessage(Constant.REQUEST_SUCCESS);
            responseDTO.setData(dto);
            log.info("getting designer info..");
        } else {
            responseDTO.setMessage(Constant.NO_DATA_FOUND);
            responseDTO.setCode(Constant.BAD_REQUEST);
            log.info("no data found");
        }

        return responseDTO;
    }

    @Override
    public ResponseDTO designerListByName(String name, Integer pageNumber, Integer pageSize) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        List<Object[]> list = designerDAO.findByName(name, pageNumber, pageSize);
        DesignerSearchDTO searchDTOS = new DesignerSearchDTO();
        List<DSearchDTO> dtoList = new ArrayList<>();
        if (list != null && !list.isEmpty()) {
            for (Object[] designer : list) {
                DSearchDTO dto = new DSearchDTO();
                dto.setId(Objects.nonNull(designer[0]) ? (Integer) designer[0] : null);
                dto.setName(Objects.nonNull(designer[1]) ? (designer[1].toString()) : null);
                dto.setProfilePhoto(Objects.nonNull(designer[2]) ? (designer[2].toString()) : null);
                searchDTOS.setPageSize(Objects.nonNull(designer[3]) ? ((Long) designer[3]).intValue() : null);
                dto.setFontCount(designerRepository.findById((Integer) designer[0]).get().getFonts().size());
                dtoList.add(dto);
            }
            searchDTOS.setDesigner(dtoList);
            responseDTO.setData(searchDTOS);
            responseDTO.setCode(Constant.OK);
            responseDTO.setStatus(Boolean.TRUE);
            responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        }
        return responseDTO;
    }

    public DesignerResponseDTO mapDesignerToDTO(Designer designer) {
        DesignerResponseDTO dto = new DesignerResponseDTO();
        dto.setDesignerName(designer.getName());
        dto.setEmail(designer.getEmail());
        dto.setWebsiteAddress(designer.getWebsite());
        dto.setDesignerInfo(designer.getDesignerInfo());
        dto.setDesignerImageUrl(designer.getDesignerImageUrl());
        dto.setCommercialLicences(designer.getCommercialLicences());
        dto.setLicensedAs(designer.getLicensedAs());

        AdditionalInfoDTO additionalInfo = new AdditionalInfoDTO();
        additionalInfo.setWebsiteAddress(designer.getWebsite());
        additionalInfo.setEmail(designer.getEmail());
        dto.setAdditionalInfo(additionalInfo);

        SocialMediaDTO socialMediaDTO = new SocialMediaDTO();
        SocialMedia socialMedia = designer.getSocialMedia();
        if (socialMedia != null) {
            socialMediaDTO.setFacebook(socialMedia.getFacebook());
            socialMediaDTO.setInstagram(socialMedia.getInstagram());
            socialMediaDTO.setLinkedIn(socialMedia.getLinkedIn());
            socialMediaDTO.setTwitter(socialMedia.getTwitter());
            dto.setSocialMediaLinks(socialMediaDTO);
        }

        return dto;
    }

    private Designer setDesignerInfo(DesignerRequestDTO dto) {

        Designer designer = new Designer();
        designer.setName(dto.getName());
        designer.setEmail(dto.getEmail());
        designer.setWebsite(dto.getWebsite());

        SocialMedia socialMedia = new SocialMedia();
        socialMedia.setInstagram(dto.getSocialMediaLinks().getInstagram());
        socialMedia.setFacebook(dto.getSocialMediaLinks().getFacebook());
        socialMedia.setTwitter(dto.getSocialMediaLinks().getTwitter());
        socialMedia.setLinkedIn(dto.getSocialMediaLinks().getLinkedIn());

        designer.setSocialMedia(socialMedia);
        return designerRepository.save(designer);
    }

}
