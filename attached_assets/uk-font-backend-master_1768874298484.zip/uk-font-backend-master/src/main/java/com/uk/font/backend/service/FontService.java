package com.uk.font.backend.service;

import com.uk.font.backend.dto.FontUploadDTO;
import com.uk.font.backend.dto.ResponseDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


@Service
public interface FontService {


    ResponseDTO getFontList(Integer pageNumber, Integer pageSize, String name, Character alphabet, Boolean isCommercial, String weight, String figure, String height, String contrast, String standardOrCaps, String width, String category, Integer designer);

    ResponseDTO fontNameList();

    ResponseEntity<ResponseDTO> saveFont(FontUploadDTO fontUploadDTO);

    ResponseDTO getByName(String name);

    ResponseDTO getFontMap();
}
