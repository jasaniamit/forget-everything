package com.uk.font.backend.service.impl;

import com.uk.font.backend.dto.CountDTO;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.repository.DesignerRepository;
import com.uk.font.backend.repository.FontRepository;
import com.uk.font.backend.repository.SubCategoryRepository;
import com.uk.font.backend.service.SearchService;
import com.uk.font.backend.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SearchServiceImpl implements SearchService {

    @Autowired
    private DesignerRepository designerRepository;
    @Autowired
    private SubCategoryRepository categoryRepository;
    @Autowired
    private FontRepository fontRepository;


    private static final Logger log = LoggerFactory.getLogger(SearchServiceImpl.class);

    @Override
    public ResponseDTO getCount(String name) {
        log.info("getting counts..");
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        Integer designerCount = designerRepository.countByNameContainingIgnoreCase(name);
        Integer categoryCount = categoryRepository.countByNameContainingIgnoreCase(name);
        Integer fontCount = fontRepository.countByNameContainingIgnoreCaseAndActive(name, true);

        CountDTO countDTO = new CountDTO();
        countDTO.setCategory(categoryCount);
        countDTO.setFont(fontCount);
        countDTO.setDesigner(designerCount);

        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setCode(Constant.OK);
        responseDTO.setData(countDTO);
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        log.info("fond "+designerCount+" designer, "+categoryCount+" category, "+fontCount+" fonts, by name "+name);
        return responseDTO;
    }
}
