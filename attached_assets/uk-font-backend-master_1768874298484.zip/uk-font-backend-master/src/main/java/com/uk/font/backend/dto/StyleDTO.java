package com.uk.font.backend.dto;

public class StyleDTO {
    private String weight;
    private String width;
    private String figure;
    private String height;
    private String contrast;
    private String standardOrCaps;

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getFigure() {
        return figure;
    }

    public void setFigure(String figure) {
        this.figure = figure;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getContrast() {
        return contrast;
    }

    public void setContrast(String contrast) {
        this.contrast = contrast;
    }

    public String getStandardOrCaps() {
        return standardOrCaps;
    }

    public void setStandardOrCaps(String standardOrCaps) {
        this.standardOrCaps = standardOrCaps;
    }
}
