package com.uk.font.backend;

import com.uk.font.backend.entity.Admin;
import com.uk.font.backend.entity.UserTable;
import com.uk.font.backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;
import java.util.Objects;

/**
 * Created by Kapil Chauhan on 10/08/21.
 */
@SpringBootApplication
public class BackendApplication {


	public static void main(String[] args) {
		SpringApplication.run(BackendApplication.class, args);
	}

	@Value("${system.user.name}")
	private String username;
	@Value("${system.user.password}")
	private String password;
	@Bean
	public ApplicationRunner createSystemAgent(@Autowired UserRepository userRepository) {
		return (ApplicationArguments args) -> {
			UserTable user = userRepository.findByUserName(username);
			if (Objects.nonNull(user)) {
				user.setPassword(new BCryptPasswordEncoder().encode(password));
				userRepository.save(user);
			} else {
				List<UserTable> adminList = userRepository.findAll();
				if (adminList.isEmpty()) {
					Admin admin = new Admin();
					admin.setUserName(username);
					admin.setPassword(new BCryptPasswordEncoder().encode(password));
					admin.setRoles("ROLE_ADMIN");
					admin.setActive(Boolean.TRUE);
					userRepository.save(admin);
				}else {
					adminList.forEach(existingAdmin->{
						existingAdmin.setUserName(username);
						existingAdmin.setPassword(new BCryptPasswordEncoder().encode(password));
						userRepository.save(existingAdmin);
					});
				}
			}
		};
	}


}
