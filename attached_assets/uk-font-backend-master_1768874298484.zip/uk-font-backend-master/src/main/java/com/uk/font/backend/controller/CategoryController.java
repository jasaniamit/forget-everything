package com.uk.font.backend.controller;

import com.uk.font.backend.dto.NameAndIdDTO;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/list/all")
    ResponseDTO getCategoryList(){
        return categoryService.getCategoryList();
    }

    @PostMapping("/add")
    ResponseEntity<ResponseDTO> addCategory(@RequestBody NameAndIdDTO category){
        return categoryService.addCategory(category);
    }
}
