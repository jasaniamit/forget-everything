package com.uk.font.backend.controller;

import com.uk.font.backend.dto.AuthRequestDTO;
import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.security.JwtUtil;
import com.uk.font.backend.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private AuthenticationManager authenticationManager;


    @PostMapping("/authenticate")
    public ResponseEntity<ResponseDTO> generateToken(@RequestBody AuthRequestDTO authRequest) throws Exception {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        String token;
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
            );
            token = jwtUtil.generateToken(authRequest.getUsername());
            responseDTO.setCode(Constant.OK);
            responseDTO.setStatus(Boolean.TRUE);
            responseDTO.setMessage("Login Success");
            responseDTO.setData(token);
            return new ResponseEntity(responseDTO,HttpStatus.OK);
        } catch (Exception ex) {
            responseDTO.setCode(Constant.FOR_BIDDEN);
            responseDTO.setMessage("Invalid Credentials");
            return new ResponseEntity(responseDTO,HttpStatus.FORBIDDEN);
        }
    }

}
