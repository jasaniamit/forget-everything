package com.uk.font.backend.dto;

import java.util.List;

public class CategorySearchDTO {
    private Integer pageSize;
    private List<CSearchDTO> category;

    public static class CSearchDTO {
        private Integer id;
        private String name;
        private Integer fontCount;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getFontCount() {
            return fontCount;
        }

        public void setFontCount(Integer fontCount) {
            this.fontCount = fontCount;
        }
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<CSearchDTO> getCategory() {
        return category;
    }

    public void setCategory(List<CSearchDTO> category) {
        this.category = category;
    }
}
