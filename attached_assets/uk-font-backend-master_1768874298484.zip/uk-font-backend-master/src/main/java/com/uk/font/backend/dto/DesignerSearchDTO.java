package com.uk.font.backend.dto;

import java.util.List;

public class DesignerSearchDTO {

    private Integer pageSize;
    private List<DSearchDTO> designer;

    public static class DSearchDTO {
        private Integer id;
        private String name;
        private String profilePhoto;
        private Integer fontCount;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getProfilePhoto() {
            return profilePhoto;
        }

        public void setProfilePhoto(String profilePhoto) {
            this.profilePhoto = profilePhoto;
        }


        public Integer getFontCount() {
            return fontCount;
        }

        public void setFontCount(Integer fontCount) {
            this.fontCount = fontCount;
        }
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<DSearchDTO> getDesigner() {
        return designer;
    }

    public void setDesigner(List<DSearchDTO> designer) {
        this.designer = designer;
    }
}
