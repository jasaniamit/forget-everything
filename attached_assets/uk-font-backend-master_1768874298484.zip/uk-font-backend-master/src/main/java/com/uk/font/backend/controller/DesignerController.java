package com.uk.font.backend.controller;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.service.DesignerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/designer")
public class DesignerController {

    @Autowired
    private DesignerService designerService;

    @GetMapping("/info/{id}")
    ResponseDTO designerInfo(@PathVariable("id") Integer id){
        return designerService.designerInfo(id);
    }

    @GetMapping("/list")
    ResponseDTO designerListByName(@RequestParam(value = "name",required = false) String name,
                                   @RequestParam(value = "pageSize",required = false) Integer pageSize,
                                   @RequestParam(value = "pageNumber",required = false) Integer pageNumber){
        return designerService.designerListByName(name,pageNumber,pageSize);
    }



}
