package com.uk.font.backend.entity;


import javax.persistence.*;
import java.util.List;
/**
 * Created by Kapil Chauhan on 10/08/21.
 */
@Entity
public class Font {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String name;
    private String fileName;
    private String fontExtension;
    private String url;
    private String about;
    private String description;
    private String license;
    private String fontZipUrl;
    private Boolean isCommercial;
    private Boolean active;

    @ManyToOne
    @JoinColumn(name="designer_id")
    private Designer designer;

    @OneToOne(mappedBy = "font",cascade = CascadeType.ALL)
    private FontStyle fontStyle;

    @ManyToOne
    @JoinColumn(name="sub_category_id")
    private SubCategory subCategory;

    @OneToMany(mappedBy = "font",cascade = CascadeType.ALL)
    private List<Image> fontImages;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Designer getDesigner() {
        return designer;
    }

    public void setDesigner(Designer designer) {
        this.designer = designer;
    }

    public String getFontExtension() {
        return fontExtension;
    }

    public void setFontExtension(String fontExtension) {
        this.fontExtension = fontExtension;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }


    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public void setCommercial(Boolean commercial) {
        isCommercial = commercial;
    }

    public Boolean getCommercial() {
        return isCommercial;
    }

    public FontStyle getFontStyle() {
        return fontStyle;
    }

    public void setFontStyle(FontStyle fontStyle) {
        this.fontStyle = fontStyle;
    }

    public SubCategory getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(SubCategory subCategory) {
        this.subCategory = subCategory;
    }

    public List<Image> getFontImages() {
        return fontImages;
    }

    public void setFontImages(List<Image> fontImages) {
        this.fontImages = fontImages;
    }

    public String getFontZipUrl() {
        return fontZipUrl;
    }

    public void setFontZipUrl(String fontZipUrl) {
        this.fontZipUrl = fontZipUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
