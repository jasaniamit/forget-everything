package com.uk.font.backend.dto;

public class DesignerResponseDTO {
    private String designerName;
    private String email;
    private String websiteAddress;
    private SocialMediaDTO socialMediaLinks;
    private String designerImageUrl;
    private String designerInfo;
    private String licensedAs;
    private String commercialLicences;
    private AdditionalInfoDTO additionalInfo;



    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebsiteAddress() {
        return websiteAddress;
    }

    public void setWebsiteAddress(String websiteAddress) {
        this.websiteAddress = websiteAddress;
    }

    public SocialMediaDTO getSocialMediaLinks() {
        return socialMediaLinks;
    }

    public void setSocialMediaLinks(SocialMediaDTO socialMediaLinks) {
        this.socialMediaLinks = socialMediaLinks;
    }

    public String getDesignerName() {
        return designerName;
    }

    public void setDesignerName(String designerName) {
        this.designerName = designerName;
    }

    public String getDesignerImageUrl() {
        return designerImageUrl;
    }

    public void setDesignerImageUrl(String designerImageUrl) {
        this.designerImageUrl = designerImageUrl;
    }

    public String getDesignerInfo() {
        return designerInfo;
    }

    public void setDesignerInfo(String designerInfo) {
        this.designerInfo = designerInfo;
    }

    public String getLicensedAs() {
        return licensedAs;
    }

    public void setLicensedAs(String licensedAs) {
        this.licensedAs = licensedAs;
    }


    public String getCommercialLicences() {
        return commercialLicences;
    }

    public void setCommercialLicences(String commercialLicences) {
        this.commercialLicences = commercialLicences;
    }

    public AdditionalInfoDTO getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(AdditionalInfoDTO additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
