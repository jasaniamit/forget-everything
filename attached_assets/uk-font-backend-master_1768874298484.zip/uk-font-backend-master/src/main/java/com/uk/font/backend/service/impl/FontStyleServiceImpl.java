package com.uk.font.backend.service.impl;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.repository.FontStyleRepository;
import com.uk.font.backend.service.FontStyleService;
import com.uk.font.backend.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class FontStyleServiceImpl implements FontStyleService {

    @Autowired
    private FontStyleRepository repository;

    @Override
    public ResponseDTO getStyles() {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        Set<String> fontStyles = new HashSet<>();
        fontStyles.add("Weight");
        fontStyles.add("Width");
        fontStyles.add("Figure");
        fontStyles.add("X-Height");
        fontStyles.add("Contrast");
        fontStyles.add("Standard Or Caps");
        responseDTO.setCode(Constant.OK);
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setData(fontStyles);
        return responseDTO;
    }
}
