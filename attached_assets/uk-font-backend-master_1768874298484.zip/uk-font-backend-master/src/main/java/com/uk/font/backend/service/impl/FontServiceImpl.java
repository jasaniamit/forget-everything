package com.uk.font.backend.service.impl;

import com.uk.font.backend.dto.*;
import com.uk.font.backend.dto.FontMap.CategoryFont;
import com.uk.font.backend.entity.*;
import com.uk.font.backend.repository.*;
import com.uk.font.backend.service.FirebaseService;
import com.uk.font.backend.service.FontService;
import com.uk.font.backend.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FontServiceImpl implements FontService {

    @Autowired
    private FontRepository fontRepository;
    @Autowired
    private DesignerRepository designerRepository;
    @Autowired
    private FirebaseService firebase;
    @Autowired
    private FontDAO fontDAO;
    @Autowired
    private SubCategoryRepository categoryRepository;
    @Autowired
    private FontStyleRepository fontStyleRepository;
    @Autowired
    private SocialMediaRepository socialMediaRepository;
    @Autowired
    private DesignerServiceImpl designerService;
    @Autowired
    private ImageRepository imageRepository;

    private static final Logger log = LoggerFactory.getLogger(FontServiceImpl.class);

    @Override
    public ResponseDTO getFontList(Integer pageNumber, Integer pageSize, String name, Character alphabet, Boolean isCommercial, String weight, String figure, String height, String contrast, String standardOrCaps, String width, String category, Integer designer) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        StyleDTO styleDTO = getStyles(weight, figure, height, contrast, standardOrCaps, width);
        FontResponseDTO fontResponseDTO = fontDAO.getFilteredFontList(responseDTO, name, pageNumber, pageSize, alphabet, isCommercial, styleDTO, category, designer);
        responseDTO.setCode(Constant.OK);
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setData(fontResponseDTO);
        responseDTO.setMessage("List of all the fonts ");
        log.info("total number of fonts found");

        return responseDTO;
    }

    private StyleDTO getStyles(String weight, String figure, String height, String contrast, String standardOrCaps, String width) {
        StyleDTO styleDTO = new StyleDTO();
        styleDTO.setContrast(contrast);
        styleDTO.setFigure(figure);
        styleDTO.setHeight(height);
        styleDTO.setWeight(weight);
        styleDTO.setWidth(width);
        styleDTO.setStandardOrCaps(standardOrCaps);
        return styleDTO;
    }


    @Override
    public ResponseDTO fontNameList() {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        List<Font> fontList = fontRepository.findAllByActive(true);
        Set<NameAndIdDTO> fonts = new HashSet<>();
        fontList.forEach(font -> {
            NameAndIdDTO andIdDTO = new NameAndIdDTO();
            andIdDTO.setName(font.getName());
            andIdDTO.setId(font.getId());
            fonts.add(andIdDTO);
        });
        responseDTO.setData(fonts);
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setCode(Constant.OK);
        return responseDTO;
    }

    @Override
    public ResponseEntity<ResponseDTO> saveFont(FontUploadDTO fontUploadDTO) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        FontRequestDTO fontDetail = fontUploadDTO.getFontDetail();
        if (Objects.nonNull(fontDetail)) {
            Font byNameAndActive = fontRepository.findByNameAndActive(fontDetail.getFontName().split("\\.")[0], true);
            if (Objects.nonNull(byNameAndActive)) {
                responseDTO.setMessage("Font " + fontDetail.getFontName().split("\\.")[0] + " already present.");
                responseDTO.setCode(Constant.BAD_REQUEST);
                return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
            }
            try {
                Font font = new Font();
                font = setFont(font, fontDetail);
                font.setDesigner(setDesigner(fontUploadDTO.getDesignerDetail()));
                font.setSubCategory(categoryRepository.findById(fontUploadDTO.getCategory()).get());
                FontStyle fontStyle = fontStyles(fontUploadDTO.getStyle());
                font.setFontStyle(fontStyle);
                Font savedFont = fontRepository.save(font);
                fontStyle.setFont(savedFont);
                setFontImage(savedFont, fontDetail.getFontImage());
                fontStyleRepository.save(fontStyle);

                responseDTO.setCode(Constant.OK);
                responseDTO.setMessage(Constant.REQUEST_SUCCESS);
                responseDTO.setStatus(Boolean.TRUE);
            } catch (Exception e) {
                responseDTO.setCode(Constant.EXCEPTION_FAILED);
                return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    private void setFontImage(Font font, List<ImageDTO> fontImages) {
        fontImages.forEach(fontImage -> {
            Image image = new Image();
            image.setUrl(fontImage.getUrl());
            image.setName(fontImage.getUrl());
            image.setFont(font);
            imageRepository.save(image);
        });
    }

    @Override
    public ResponseDTO getByName(String name) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        Font font = fontRepository.findByNameAndActive(name,true);
        if (Objects.nonNull(font)) {
            SubCategoryResponseDTO dto = new SubCategoryResponseDTO();
            dto.setId(font.getId());
            dto.setName(font.getName());
            dto.setAbout(font.getAbout());
            dto.setLicense(font.getLicense());
            dto.setUrl(font.getUrl());
            dto.setDescription(font.getDescription());

            List<Image> fontImages = font.getFontImages();
            List<String> imageUrl = new ArrayList<>();
            fontImages.forEach(fontImage -> imageUrl.add(fontImage.getUrl()));
            dto.setImages(imageUrl);
            Set<DesignerResponseDTO> designers = new HashSet<>();
            Set<Designer> designerSet = new HashSet<>();
            designerSet.add(font.getDesigner());
            designerSet.forEach(designer -> designers.add(designerService.mapDesignerToDTO(designer)));
            dto.setDesigners(designers);
            responseDTO.setData(dto);
            responseDTO.setCode(Constant.OK);
            responseDTO.setMessage(Constant.REQUEST_SUCCESS);
            responseDTO.setStatus(Boolean.TRUE);
            log.info("Font details");
        } else {
            responseDTO.setMessage(Constant.NO_DATA_FOUND);
            responseDTO.setCode(Constant.OK);
            log.info("No data found by font Name");
        }
        return responseDTO;
    }

    @Override
    public ResponseDTO getFontMap() {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        List<Font> allByActive = fontRepository.findAllByActive(true);

        List<FontMap> fontMapList = new ArrayList<>();
        allByActive.forEach(font -> {
            FontMap fontMap = new FontMap();
            fontMap.setFontFamilyName(font.getName());
            fontMap.setDownloadUrl(font.getUrl());
            fontMap.setType(font.getSubCategory().getName());
            List<Font> categoryFontList = fontRepository.findAllBySubCategoryAndActive(font.getSubCategory(), true);
            List<CategoryFont> categoryFonts = new ArrayList<>();
            categoryFontList.forEach(categoryFont -> {
                CategoryFont category = new CategoryFont();
                category.setFontFamilyName(categoryFont.getName());
                category.setDownloadUrl(categoryFont.getUrl());
                category.setType(categoryFont.getSubCategory().getName());
                categoryFonts.add(category);
            });
            fontMap.setSimilarFonts(categoryFonts);
            fontMapList.add(fontMap);
        });
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        responseDTO.setCode(Constant.OK);
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setData(fontMapList);
        return responseDTO;
    }

    private FontStyle fontStyles(StyleDTO style) {
        FontStyle fontStyle = new FontStyle();
        String weight = getWeight(style.getWeight());
        String width = getWidth(style.getWidth());
        String figure = getFigure(style.getFigure());
        String height = getHeight(style.getHeight());
        String contrast = getContrast(style.getContrast());
        String standardOrCaps = getStandardOrCaps(style.getStandardOrCaps());

        fontStyle.setContrast(contrast);
        fontStyle.setFigure(figure);
        fontStyle.setWidth(width);
        fontStyle.setWeight(weight);
        fontStyle.setHeight(height);
        fontStyle.setStandardOrCaps(standardOrCaps);
        return fontStyleRepository.save(fontStyle);
    }

    private String getHeight(String height) {
        if (height != null) {
            if (height.equals("1")) {
                return "16";
            }
            if (height.equals("2")) {
                return "18";
            }
            if (height.equals("2")) {
                return "20";
            }
        }
        return null;
    }

    private String getWeight(String weight) {
        if (weight != null) {
            if (weight.equals("1")) {
                return "200";
            }
            if (weight.equals("2")) {
                return "600";
            }
            if (weight.equals("2")) {
                return "800";
            }
        }
        return null;
    }

    private String getWidth(String width) {
        if (width != null) {
            if (width.equals("1")) {
                return "16";
            }
            if (width.equals("2")) {
                return "30";
            }
            if (width.equals("2")) {
                return "45";
            }
        }
        return null;
    }

    private String getFigure(String figure) {
        if (figure != null) {
            if (figure.equals("1")) {
                return "no idea";
            }
            if (figure.equals("2")) {
                return "no idea";
            }
            if (figure.equals("2")) {
                return "no idea";
            }
        }
        return null;
    }

    private String getContrast(String contrast) {
        if (contrast != null) {
            if (contrast.equals("1")) {
                return "bright";
            }
            if (contrast.equals("2")) {
                return "normal";
            }
            if (contrast.equals("2")) {
                return "dark";
            }
        }
        return null;
    }

    private String getStandardOrCaps(String standardOrCaps) {
        if (standardOrCaps != null) {
            if (standardOrCaps.equals("1")) {
                return "lowercase";
            }
            if (standardOrCaps.equals("2")) {
                return "normalcase";
            }
            if (standardOrCaps.equals("2")) {
                return "uppercase";
            }
        }
        return null;
    }

    private Designer setDesigner(DesignerRequestDTO designerDetail) {

        if (designerDetail.getId() != null) {
            return designerRepository.findById(designerDetail.getId()).get();
        } else {
            Designer designer = new Designer();
            designer.setName(designerDetail.getName());
            designer.setEmail(designerDetail.getEmail());
            designer.setWebsite(designerDetail.getWebsite());
            designer.setDesignerInfo(designerDetail.getDesignerInfo());
            designer.setDesignerImageUrl(designerDetail.getUrl());
            designer.setCommercialLicences(designerDetail.getCommercialLicense());
            designer.setLicensedAs(designerDetail.getLicense());
            Designer save = designerRepository.save(designer);
            designer.setSocialMedia(socialMedia(save, designerDetail.getSocialMediaLinks()));
            return save;
        }
    }


    private SocialMedia socialMedia(Designer designer, SocialMediaDTO social) {
        SocialMedia socialMedia = new SocialMedia();
        socialMedia.setInstagram(social.getInstagram());
        socialMedia.setFacebook(social.getFacebook());
        socialMedia.setTwitter(social.getTwitter());
        socialMedia.setLinkedIn(social.getLinkedIn());
        socialMedia.setDesigner(designer);
        return socialMediaRepository.save(socialMedia);
    }

    private Font setFont(Font font, FontRequestDTO fontDetail) {
        font.setName(fontDetail.getFontName().split("\\.")[0]);
        font.setFontExtension(fontDetail.getFontName().split("\\.")[1]);
        font.setFileName(fontDetail.getFontName());
        font.setLicense(font.getLicense());
        font.setActive(Boolean.TRUE);
        font.setDescription(fontDetail.getDescription());
        font.setCommercial(fontDetail.isCommercial());
        font.setAbout(fontDetail.getAbout());
        font.setUrl(fontDetail.getUrl());
        font.setFontZipUrl(fontDetail.getFontZipUrl());
        return font;
    }
}
