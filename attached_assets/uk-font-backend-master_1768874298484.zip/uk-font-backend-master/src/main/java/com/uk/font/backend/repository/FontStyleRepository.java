package com.uk.font.backend.repository;

import com.uk.font.backend.entity.FontStyle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FontStyleRepository extends JpaRepository<FontStyle,Integer> {
}
