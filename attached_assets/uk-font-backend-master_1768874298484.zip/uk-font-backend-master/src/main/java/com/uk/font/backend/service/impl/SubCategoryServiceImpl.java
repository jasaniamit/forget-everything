package com.uk.font.backend.service.impl;

import com.uk.font.backend.dto.*;
import com.uk.font.backend.dto.CategorySearchDTO.CSearchDTO;
import com.uk.font.backend.entity.Image;
import com.uk.font.backend.entity.Designer;
import com.uk.font.backend.entity.Font;
import com.uk.font.backend.entity.SubCategory;
import com.uk.font.backend.repository.CategoryDAO;
import com.uk.font.backend.repository.CategoryRepository;
import com.uk.font.backend.repository.ImageRepository;
import com.uk.font.backend.repository.SubCategoryRepository;
import com.uk.font.backend.service.SubCategoryService;
import com.uk.font.backend.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SubCategoryServiceImpl implements SubCategoryService {
    @Autowired
    private SubCategoryRepository categoryRepository;
    @Autowired
    DesignerServiceImpl designerService;
    @Autowired
    private CategoryDAO categoryDAO;
    @Autowired
    private CategoryRepository repository;
    @Autowired
    private ImageRepository imageRepository;

    private static final Logger log = LoggerFactory.getLogger(SubCategoryServiceImpl.class);

    @Override
    public ResponseDTO getCategoryByName(String name) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        SubCategory category = categoryRepository.findByName(name);

        if (Objects.nonNull(category)) {
            SubCategoryResponseDTO dto = new SubCategoryResponseDTO();
            dto.setId(category.getId());
            dto.setName(category.getName());
            dto.setDescription(category.getDescription());
            dto.setAbout(category.getAbout());
            dto.setLicense(category.getLicense());
            List<Image> categoryImages = category.getCategoryImages();
            List<String> imageUrl = new ArrayList<>();
            categoryImages.forEach(categoryImage -> imageUrl.add(categoryImage.getUrl()));
            dto.setImages(imageUrl);
            List<Font> fonts = category.getFonts();
            Set<DesignerResponseDTO> designers = new HashSet<>();
            Set<Designer> designerSet = new HashSet<>();
            fonts.forEach(font -> designerSet.add(font.getDesigner()));
            designerSet.forEach(designer -> designers.add(designerService.mapDesignerToDTO(designer)));
            dto.setDesigners(designers);
            responseDTO.setData(dto);
            responseDTO.setCode(Constant.OK);
            responseDTO.setMessage(Constant.REQUEST_SUCCESS);
            responseDTO.setStatus(Boolean.TRUE);
            log.info("Category details");
        } else {
            responseDTO.setMessage(Constant.NO_DATA_FOUND);
            responseDTO.setCode(Constant.OK);
            log.info("No data found by category Name");
        }
        return responseDTO;
    }

    @Override
    public ResponseDTO getFilterCategoryByName(String name) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        List<SubCategory> subCategories = categoryRepository.findByNameIgnoreCaseContaining(name);
        List<NameAndIdDTO> categoriesList = new ArrayList<>();
        subCategories.forEach(subCategory -> {
            NameAndIdDTO nameAndIdDTO = new NameAndIdDTO();
            nameAndIdDTO.setName(subCategory.getName());
            nameAndIdDTO.setId(subCategory.getId());
            categoriesList.add(nameAndIdDTO);
        });
        responseDTO.setData(categoriesList);
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setCode(Constant.OK);
        return responseDTO;
    }


    @Override
    public ResponseDTO getCategoryListByName(String name, Integer pageNumber, Integer pageSize) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);
        List<Object[]> byName = categoryDAO.findByName(name, pageNumber, pageSize);
        CategorySearchDTO categorySearchDTO = new CategorySearchDTO();
        List<CSearchDTO> andIdDTOS = new ArrayList<>();
        if (byName != null && !byName.isEmpty()) {
            for (Object[] category : byName) {
                CSearchDTO dto = new CSearchDTO();
                dto.setId(Objects.nonNull(category[0]) ? (Integer) category[0] : 0);
                dto.setName(Objects.nonNull(category[1]) ? category[1].toString() : null);
                categorySearchDTO.setPageSize(Objects.nonNull(category[2]) ? ((Long) category[2]).intValue() : 0);
                dto.setFontCount(categoryRepository.findById((Integer) category[0]).get().getFonts().size());
                andIdDTOS.add(dto);
            }
            categorySearchDTO.setCategory(andIdDTOS);
            responseDTO.setMessage(Constant.REQUEST_SUCCESS);
            responseDTO.setCode(Constant.OK);
            responseDTO.setStatus(Boolean.TRUE);
            responseDTO.setData(categorySearchDTO);
        }
        return responseDTO;
    }

    @Override
    public ResponseEntity<ResponseDTO> addCategory(SubCategoryResponseDTO category) {
        ResponseDTO responseDTO = new ResponseDTO(false, Constant.REQUEST_NOT_PROCESSED);

        SubCategory byName = categoryRepository.findByName(category.getName());
        if(Objects.nonNull(byName)){
            responseDTO.setMessage("Category "+category.getName()+ " already present");
            responseDTO.setCode(Constant.BAD_REQUEST);
            log.info("category already present");
            return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
        }
        SubCategory subCategory = new SubCategory();
        subCategory.setName(category.getName());
        subCategory.setAbout(category.getAbout());
        subCategory.setDescription(category.getDescription());
        subCategory.setLicense(category.getLicense());
        subCategory.setCategory(repository.findById(category.getId()).get());
        categoryImages(categoryRepository.save(subCategory),category.getImageList());
        responseDTO.setStatus(Boolean.TRUE);
        responseDTO.setCode(Constant.OK);
        responseDTO.setMessage(Constant.REQUEST_SUCCESS);
        log.info("category saved success");
        return new ResponseEntity<>(responseDTO,HttpStatus.OK);
    }

    private void categoryImages(SubCategory subCategory, List<ImageDTO> imageList) {

        imageList.forEach(image->{
            Image newImage = new Image();
            newImage.setUrl(image.getUrl());
            newImage.setName(image.getName());
            newImage.setSubCategory(subCategory);
            imageRepository.save(newImage);

        });
    }
}
