package com.uk.font.backend.security;

import com.uk.font.backend.exception.GlobalExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Autowired
    UserDetailsService userDetailsService;

    @Autowired
    private JwtFilter jwtFilter;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService);
    }

    @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public static BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/font/save").hasRole("ADMIN")
                .antMatchers("/firebase/upload").hasRole("ADMIN")
                .antMatchers("/firebase/delete/{id}").hasRole("ADMIN")
                .antMatchers("/category/add").hasRole("ADMIN")
                .antMatchers("/category/add/new").hasRole("ADMIN")
                .antMatchers("/authenticate")
                .permitAll()
                .and()
                .csrf()
                .disable()
                .httpBasic()
                .and()
                .exceptionHandling()
                .authenticationEntryPoint(new GlobalExceptionHandler());
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
                .antMatchers("/font/{name}")
                .antMatchers("/font/name/list")
                .antMatchers("/font/list")
                .antMatchers("/font/fontmap")
                .antMatchers("/designer/list")
                .antMatchers("/designer/info/{id}")
                .antMatchers("/designer/list")
                .antMatchers("/style/list")
                .antMatchers("/search/count/{name}")
                .antMatchers("/firebase/delete/{id}")
                .antMatchers("/category/list")
                .antMatchers("/category/{name}")
                .antMatchers("/category/list/all")
                .antMatchers("/category/filter/{name}")
                .antMatchers("/category/name/list");


    }

}
