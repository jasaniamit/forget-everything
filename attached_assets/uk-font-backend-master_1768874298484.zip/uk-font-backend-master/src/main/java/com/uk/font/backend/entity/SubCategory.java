package com.uk.font.backend.entity;

import javax.persistence.*;
import java.util.List;
/**
 * Created by Kapil Chauhan on 10/08/21.
 */
@Entity
public class SubCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String name;
    private String description;
    private String about;
    private String license;

    @ManyToOne
    @JoinColumn(name="category_id")
    private Category category;

    @OneToMany(mappedBy = "subCategory",cascade = CascadeType.ALL)
    private List<Font> fonts;

    @OneToMany(mappedBy = "subCategory",cascade = CascadeType.ALL)
    private List<Image> categoryImages;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public List<Font> getFonts() {
        return fonts;
    }

    public void setFonts(List<Font> fonts) {
        this.fonts = fonts;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public List<Image> getCategoryImages() {
        return categoryImages;
    }

    public void setCategoryImages(List<Image> categoryImages) {
        this.categoryImages = categoryImages;
    }
}
