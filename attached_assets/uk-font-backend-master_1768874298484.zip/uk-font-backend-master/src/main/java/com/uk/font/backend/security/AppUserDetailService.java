package com.uk.font.backend.security;


import com.uk.font.backend.entity.UserTable;
import com.uk.font.backend.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AppUserDetailService implements UserDetailsService {
    @Autowired
    UserRepository userRepository;
    private static final Logger logger = LoggerFactory.getLogger(AppUserDetailService.class);

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        logger.info("Trying to authenticate user :: "+ username);
        Optional<UserTable> user = Optional.ofNullable(userRepository.findByUserName(username));
        user.orElseThrow(() -> new UsernameNotFoundException("User Not Found " + username));
        return user.map(AppUser::new).get();
    }
}
