package com.uk.font.backend.service;

import com.uk.font.backend.dto.ResponseDTO;
import org.springframework.stereotype.Service;

@Service
public interface SearchService {
    ResponseDTO getCount(String name);

}
