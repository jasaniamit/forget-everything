package com.uk.font.backend.dto;

public class DesignerRequestDTO {

    private Integer id;
    private String name;
    private String email;
    private String photoName;
    private String url;
    private String about;
    private String license;
    private String commercialLicense;
    private String website;
    private String designerInfo;
    private SocialMediaDTO socialMediaLinks;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public SocialMediaDTO getSocialMediaLinks() {
        return socialMediaLinks;
    }

    public void setSocialMediaLinks(SocialMediaDTO socialMediaLinks) {
        this.socialMediaLinks = socialMediaLinks;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPhotoName() {
        return photoName;
    }

    public void setPhotoName(String photoName) {
        this.photoName = photoName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public String getCommercialLicense() {
        return commercialLicense;
    }

    public void setCommercialLicense(String commercialLicense) {
        this.commercialLicense = commercialLicense;
    }

    public String getDesignerInfo() {
        return designerInfo;
    }

    public void setDesignerInfo(String designerInfo) {
        this.designerInfo = designerInfo;
    }
}
