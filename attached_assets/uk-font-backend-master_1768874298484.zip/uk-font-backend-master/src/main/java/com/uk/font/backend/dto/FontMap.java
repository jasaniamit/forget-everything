package com.uk.font.backend.dto;

import java.util.List;

public class FontMap {
    private String fontFamilyName;
    private String downloadUrl;
    private String type;
    private List<CategoryFont> similarFonts;

    public static class CategoryFont {
        private String fontFamilyName;
        private String downloadUrl;
        private String type;

        public String getFontFamilyName() {
            return fontFamilyName;
        }

        public void setFontFamilyName(String fontFamilyName) {
            this.fontFamilyName = fontFamilyName;
        }

        public String getDownloadUrl() {
            return downloadUrl;
        }

        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    public String getFontFamilyName() {
        return fontFamilyName;
    }

    public void setFontFamilyName(String fontFamilyName) {
        this.fontFamilyName = fontFamilyName;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<CategoryFont> getSimilarFonts() {
        return similarFonts;
    }

    public void setSimilarFonts(List<CategoryFont> similarFonts) {
        this.similarFonts = similarFonts;
    }
}
