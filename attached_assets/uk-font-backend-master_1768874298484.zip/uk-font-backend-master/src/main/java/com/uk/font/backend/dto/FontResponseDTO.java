package com.uk.font.backend.dto;

import java.util.List;

public class FontResponseDTO {
    private Integer totalCount=0;
    private List<FontDTO> fontDTO;


    public List<FontDTO> getFontDTO() {
        return fontDTO;
    }

    public void setFontDTO(List<FontDTO> fontDTO) {
        this.fontDTO = fontDTO;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
}
