package com.uk.font.backend.dto;

public class FontUploadDTO {

    private FontRequestDTO fontDetail;
    private DesignerRequestDTO designerDetail;
    private StyleDTO style;
    private Integer category;

    public FontRequestDTO getFontDetail() {
        return fontDetail;
    }

    public void setFontDetail(FontRequestDTO fontDetail) {
        this.fontDetail = fontDetail;
    }

    public DesignerRequestDTO getDesignerDetail() {
        return designerDetail;
    }

    public void setDesignerDetail(DesignerRequestDTO designerDetail) {
        this.designerDetail = designerDetail;
    }

    public StyleDTO getStyle() {
        return style;
    }

    public void setStyle(StyleDTO style) {
        this.style = style;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }
}
