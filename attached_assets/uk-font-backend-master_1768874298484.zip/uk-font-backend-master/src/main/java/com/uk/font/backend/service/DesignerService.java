package com.uk.font.backend.service;

import com.uk.font.backend.dto.ResponseDTO;
import org.springframework.stereotype.Service;

@Service
public interface DesignerService {


    ResponseDTO designerInfo(Integer id);

    ResponseDTO designerListByName(String name, Integer pageNumber, Integer pageSize);
}
