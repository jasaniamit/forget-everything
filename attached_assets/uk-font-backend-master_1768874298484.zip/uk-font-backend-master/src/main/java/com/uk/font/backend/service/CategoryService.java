package com.uk.font.backend.service;

import com.uk.font.backend.dto.NameAndIdDTO;
import com.uk.font.backend.dto.ResponseDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface CategoryService {
    ResponseDTO getCategoryList();

    ResponseEntity<ResponseDTO> addCategory(NameAndIdDTO category);
}
