package com.uk.font.backend.dto;

import java.util.List;
import java.util.Set;

public class SubCategoryResponseDTO {
    private Integer id;
    private String name;
    private String description;
    private String about;
    private String license;
    private String url;
    private List<String> images;
    private List<ImageDTO> imageList;
    private Set<DesignerResponseDTO> designers;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public Set<DesignerResponseDTO> getDesigners() {
        return designers;
    }

    public void setDesigners(Set<DesignerResponseDTO> designers) {
        this.designers = designers;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<ImageDTO> getImageList() {
        return imageList;
    }

    public void setImageList(List<ImageDTO> imageList) {
        this.imageList = imageList;
    }
}
