package com.uk.font.backend.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class DesignerDAO {

    @Autowired
    private JdbcTemplate jdbcTemplateRead;

    public List<Object[]> findByName(String name, Integer pageNumber, Integer pageSize) {


        String query = "select id, name, designer_image_url, COUNT(*) OVER () as total_count from designer ";

        if (name != null && pageNumber != null && pageSize != null) {
            query = query + " where name like '%" + name + "%' limit " + pageSize + " OFFSET " + pageNumber * pageSize;
        }
        if (pageNumber != null && pageSize != null && name == null) {
            query = query + " limit " + pageSize + " OFFSET " + pageNumber * pageSize;
        }
        if (name != null && pageNumber == null && pageSize == null) {
            query = query + " where name like '%" + name + "%'";
        }
        List<Map<String, Object>> list = null;
        try {
            list = jdbcTemplateRead.queryForList(query);
        } catch (Exception e) {
        }
        List<Object[]> result = new ArrayList<>();
        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> map : list) {
                if (map != null && !map.isEmpty()) {
                    int i = 0;
                    Object[] objects = new Object[5];
                    for (String key : map.keySet()) {
                        objects[i++] = map.get(key);
                    }
                    result.add(objects);
                }
            }
        }
        return result;
    }
}
