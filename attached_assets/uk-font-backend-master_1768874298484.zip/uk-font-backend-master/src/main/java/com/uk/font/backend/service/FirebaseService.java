package com.uk.font.backend.service;

import com.uk.font.backend.dto.ResponseDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;



@Service
public interface FirebaseService {

    ResponseDTO uploadFile(MultipartFile[] file, String filetype);

    ResponseEntity<ResponseDTO> delete(Integer id);

}
