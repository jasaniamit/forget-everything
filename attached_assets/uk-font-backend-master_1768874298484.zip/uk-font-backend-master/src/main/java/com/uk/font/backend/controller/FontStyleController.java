package com.uk.font.backend.controller;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.service.FontStyleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/style")
public class FontStyleController {

    @Autowired
    private FontStyleService fontStyleService;

    @GetMapping("/list")
    ResponseDTO getStyleList(){
        return fontStyleService.getStyles();
    }
}
