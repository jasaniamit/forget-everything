package com.uk.font.backend.controller;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.service.FirebaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/firebase")
public class FirebaseController {

    @Autowired
    private FirebaseService firebaseService;

    @PostMapping("/upload")
    ResponseDTO upload(@RequestParam("file") MultipartFile[] file, @RequestParam(value = "fileType", required = false) String filetype){
        return firebaseService.uploadFile(file, filetype);
    }
    @PostMapping("/delete/{id}")
    ResponseEntity<ResponseDTO> deleteFont(@PathVariable("id") Integer id) throws IOException {
        return firebaseService.delete(id);
    }
}
