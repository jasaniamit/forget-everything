package com.uk.font.backend.controller;

import com.uk.font.backend.dto.ResponseDTO;
import com.uk.font.backend.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/search")
public class SearchController {

    @Autowired
    private SearchService searchService;

    @GetMapping("/count/{name}")
    ResponseDTO getCount(@PathVariable String name){
        return searchService.getCount(name);
    }


}
