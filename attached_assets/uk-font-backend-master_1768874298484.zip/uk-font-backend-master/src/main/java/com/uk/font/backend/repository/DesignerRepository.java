package com.uk.font.backend.repository;

import com.uk.font.backend.entity.Designer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DesignerRepository extends JpaRepository<Designer,Integer> {
    Integer countByNameContainingIgnoreCase(String name);
}
