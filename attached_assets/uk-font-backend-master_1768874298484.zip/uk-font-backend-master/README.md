Created by Kapil Chauhan on 10/08/21.
# uk-font-backend

Technology used java(1.8) SpringBoot(2.3.5.RELEASE).
Database used MySql.
For storage - Firebase bucket.


