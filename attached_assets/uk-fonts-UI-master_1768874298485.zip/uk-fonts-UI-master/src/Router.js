import React, { useEffect } from 'react'
import { Route, Redirect, Switch } from 'react-router-dom'
import NavigationPanel from './components/NavigationPanel/NavigationPanel'
import Home from './views/Home/Home'
import './Router.scss'
import Footer from './components/Footer/Footer'
import container from './common/container/container'
import { urlStoreSync } from './common/utils/urlStoreSync'
import FontMapView from './views/FontMapView/FontMapView'
import FontPairingView from './views/FontPairingView/FontPairingView'
import { windowResizeHandler } from './common/utils/windowResizeHandler'
import FontCategoryView from './views/FontCategoryView/FontCategoryView'
import DesignerView from './views/DesignerView/DesignerView'
import Admin from './views/Admin/Admin'
import { Toaster } from 'react-hot-toast';
import FontDetailsView from './views/FontDetailsView/FontDetailsView'

const Router = ({
    isDarkMode,
    screenWidth,
    location: { search }
}) => {

    useEffect(() => {
        urlStoreSync(search)
        windowResizeHandler()
        window.addEventListener("resize", windowResizeHandler)
        return () => window.removeEventListener("resize", windowResizeHandler)
    }, [search])

    return (
        <div className='routerhome'>
            <NavigationPanel screenWidth={screenWidth} />
            <div className={`appBody ${isDarkMode ? 'darkModeBackground' : ''}`}>
                <Switch>
                    <Route path='/' exact render={() => <Redirect to='/home' />} />
                    <Route path={`/home`} exact render={() => <Home />} />
                    <Route path={`/fontMap`} exact render={() => <FontMapView />} />
                    <Route path={`/fontPairing`} exact render={() => <FontPairingView />} />
                    <Route path={`/category`} exact render={() => <FontCategoryView />} />
                    <Route path={`/designers`} exact render={() => <DesignerView />} />
                    <Route path={`/fontDetails`} exact render={() => <FontDetailsView />} />
                    <Route path={`/admin`} exact render={() => <Admin />} />
                </Switch>
                <Toaster
                    position="top-center"
                    reverseOrder={false}
                    gutter={8}
                    containerClassName=""
                    containerStyle={{}}
                    toastOptions={{
                        // Define default options
                        className: '',
                        duration: 3000,
                        style: {
                            width: '25rem'
                        },
                        // Default options for specific types
                        loading: {
                            duration: Infinity,
                        },
                    }}
                />
            </div>
            <Footer />
        </div>
    )
}

const mapStateToProps = (state) => {
    const { isDarkMode,
        screenWidth
    } = state.selectedOptionsReducer
    return {
        isDarkMode,
        screenWidth
    }
}

const mapDispatchToProps = {
}
export default container(Router, mapStateToProps, mapDispatchToProps)