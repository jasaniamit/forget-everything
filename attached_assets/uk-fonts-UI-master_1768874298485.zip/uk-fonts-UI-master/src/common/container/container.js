import { withRouter } from "react-router"
import { connect } from "react-redux"

const container = (component, ...args) => withRouter(connect(...args)(component))

export default container