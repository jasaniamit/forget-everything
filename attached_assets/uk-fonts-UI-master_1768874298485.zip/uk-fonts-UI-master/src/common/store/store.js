import { applyMiddleware, compose, createStore } from "redux"
import thunk from 'redux-thunk'
import reducers from './../reducers/reducers'

const validDevTools = window.__REDUX_DEVTOOLS_EXTENSION__
    ? window.__REDUX_DEVTOOLS_EXTENSION__({ trace: true, traceLimit: 10 })
    : (f) => f

const store = createStore(
    reducers,
    compose(
        applyMiddleware(...[thunk]),
        process.env.NODE_ENV === 'development' ? validDevTools : (f) => f
    )
)

export default store