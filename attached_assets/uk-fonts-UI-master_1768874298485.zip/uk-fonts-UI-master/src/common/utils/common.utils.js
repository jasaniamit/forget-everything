import { fontCategoryStyles, propertiesMapper, socialMediaIconsMapper } from "./mappers"
import store from './../store/store'
import { stylesOptions } from "../constants/defaults"
import { sessionExpiredHandler } from "./auth.utils"
import createNotification from "../../components/UI/Notifications/Notifications"

export const generateContentForCategoryStyles = (styleListArr, fontCategoryData) => {
    const fontStyleArr = styleListArr.map(item => {
        return {
            fontFamilyName: 'Inter',
            primarylinks: [{ name: item, route: '#' }],
            secondarylinks: [
                { name: 'PERSONAL USE', route: '#' }],
            styles: fontCategoryStyles[item]
        }
    })
    return fontStyleArr
}

export const generateContentForFontStyles = (styleListArr, selectedFont) => {
    const fontStyleArr = styleListArr.map(item => {
        return {
            fontFamilyName: selectedFont,
            primarylinks: [{ name: item, route: '#' }],
            secondarylinks: [
                { name: 'PERSONAL USE', route: '#' }],
            styles: fontCategoryStyles[item]
        }
    })
    return fontStyleArr
}

export const getIconItems = (socialMediaLinks, color) => {
    const newIconsItems = Object.keys(socialMediaLinks).map(item => {
        return { comp: socialMediaIconsMapper[item], link: socialMediaLinks[item], color }
    })
    return newIconsItems
}

export const fontLoader = (data, stopLoadingAction, isDispatch = true) => {
    try {
        document.fonts.ready
            .then(fontFaceSet => {
                data.forEach(async (fontData, index) => {
                    try {
                        if (!fontFaceSet.check(`16px ${fontData.fontFamilyName}`)) {
                            const newFont = new FontFace(fontData.fontFamilyName, `url(${fontData.downloadUrl})`,/* { style: 'normal', weight: 700 }*/)
                            const newFontFace = await newFont.load()
                            newFontFace && document.fonts.add(newFontFace)
                        }
                    } catch (err) {
                        console.log(err)
                        fontLoaderUsingTags(fontData)
                    }
                    index === data.length - 1 && isDispatch ? store.dispatch(stopLoadingAction(false)) : stopLoadingAction(false)
                })
            })
            .catch((err => {
                createNotification('error', 'Error loading Font')
                isDispatch ? store.dispatch(stopLoadingAction(false)) : stopLoadingAction(false)
            }))
    } catch (err) {
        console.log(err)
    }
}

export const fontLoaderUsingTags = (fontData) => {
    let newfont = document.createElement("style")
    newfont.setAttribute("font", fontData.fontFamilyName)
    newfont.innerHTML = `@font-face {font-family: ${fontData.fontFamilyName};  src: url(${fontData.downloadUrl});}`
    document.getElementsByTagName('head')[0].appendChild(newfont)
}

export const generateFontListForIncomingData = (data = []) => {
    const newData = []
    data.forEach(fontData => {
        const primaryLinks = [
            { name: fontData.fontName, route: `/fontDetails?font=${fontData.fontName}` },
            { name: fontData.designerName, route: `/designers?designer=${fontData.designer}` }
        ]
        fontData['styles'] && Object.keys(fontData['styles']).forEach(item => {
            if (fontData['styles'][item]) {
                primaryLinks.push({ name: `${item}: ${fontData['styles'][item]}`, route: '#' })
            }
        })
        newData.push({
            fontFamilyName: fontData.fontName,
            primarylinks: primaryLinks,
            secondarylinks: [
                { name: `${fontData.commercial ? 'COMMERCIAL USE' : 'PERSONAL USE'}`, route: '#' }],
            styles: {},
            imagePath: fontData.imagePath,
            tags: fontData.tags,
            downloadUrl: fontData.url,
            downloadZip: fontData.fontZipUrl
        })
    })
    return newData
}

export const linkDownloader = (url, fileName) => {
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `${fileName}.ttf`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
}

export const parseIncommingList = (data) => {
    const options = data.map(item => {
        return { key: item.id, text: item.name }
    })
    return options
}

export const parseStylesList = (data) => {
    const options = data.map(item => {
        return { label: item, key: item, required: false, type: 'choiceGroup', options: stylesOptions, defaultKey: '' }
    })
    return options
}

export const actionsErrorCatch = (error, dispatchFunctions, notificationMsg) => {
    console.log(error)
    dispatchFunctions.forEach(item => {
        const runningFunction = item()
        store.dispatch(runningFunction)
    })
    if (error.response) {
        if (error.response.status == 401)
            /*eslint-disable eqeqeq*/
            sessionExpiredHandler()
        else
            createNotification('error', error.response.data.message)
    } else if (error.message === "Network Error") {
        createNotification('error', 'Network Error')
        return
    } else {
        createNotification('error', notificationMsg, error.msg || '')
    }
}

export const getSelectedProperties = (selectedProperties) => {
    let properties = {}

    Object.keys(propertiesMapper).forEach(item => {
        properties[item] = selectedProperties[item] ? propertiesMapper[item][selectedProperties[item]] : ''
    })
    return properties
}