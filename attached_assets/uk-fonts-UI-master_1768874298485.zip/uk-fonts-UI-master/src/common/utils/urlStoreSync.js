import { decodeURL } from './URL'
import * as actionsDispatcher from "../actions/actionsDispatcher"
import { defaultSelectedFontControls } from "../constants/defaults"
import { equals } from 'ramda'
import store from './../store/store'

export const urlStoreSync = (search) => {
    const queryObject = decodeURL(search)
    const {
        isDarkMode,
        selectedFontControlOptions,
        searchText,
        selectedAlphabet,
        selectedFontMap,
        selectedFontPairing,
        selectedFontCategory,
        selectedProperties,
        selectedPage,
        selectedDesigner,
        selectedFont,
        selectedSearchType } = store.getState().selectedOptionsReducer
    const {
        isDarkModeEnable = false,
        selectedFontControls = defaultSelectedFontControls,
        page = 0,
        query = '',
        alphabet = '',
        fontMap = '',
        fontPairing = {},
        fontCategory = '',
        properties = {},
        designer = '',
        font = '',
        searchType = '' } = queryObject


    if (isDarkModeEnable !== isDarkMode) {
        store.dispatch(actionsDispatcher.setDarkMode(isDarkModeEnable))
    }
    if (!equals(selectedFontControls, selectedFontControlOptions)) {
        store.dispatch(actionsDispatcher.setSelectedFontOptions(selectedFontControls))
    }
    if (query !== searchText) {
        store.dispatch(actionsDispatcher.setSearchText(query))
    }
    if (alphabet !== selectedAlphabet) {
        store.dispatch(actionsDispatcher.setAlphabet(alphabet))
    }
    if (fontMap !== selectedFontMap) {
        store.dispatch(actionsDispatcher.setFontMap(fontMap))
    }
    if (!equals(fontPairing, selectedFontPairing)) {
        store.dispatch(actionsDispatcher.setfontPairing(fontPairing))
    }
    if (selectedFontCategory !== fontCategory) {
        store.dispatch(actionsDispatcher.setFontCategory(fontCategory))
    }
    if (!equals(properties, selectedProperties)) {
        store.dispatch(actionsDispatcher.setProperties(properties))
    }
    if (page !== selectedPage) {
        store.dispatch(actionsDispatcher.setPage(page))
    }
    if (designer !== selectedDesigner) {
        store.dispatch(actionsDispatcher.setDesigner(designer))
    }
    if (font !== selectedFont) {
        store.dispatch(actionsDispatcher.setSelectedFont(font))
    }
    if (searchType !== selectedSearchType) {
        store.dispatch(actionsDispatcher.setSelectedSearchType(searchType))
    }

}
