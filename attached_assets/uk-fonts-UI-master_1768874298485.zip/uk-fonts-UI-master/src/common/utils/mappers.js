import { Facebook, Instagram, LinkedLn, Twitter } from "../../assets/icons"

export const fontCategoryStyles = {
    'Light': { fontWeight: '200' },
    'Light italic': { fontWeight: '200', fontStyle: 'italic' },
    'Regular': { fontWeight: '400' },
    'Italic': { fontWeight: '400', fontStyle: 'italic' },
    'Semibold': { fontWeight: '600' },
    'Semibold Italic': { fontWeight: '600', fontStyle: 'italic' },
    'Bold': { fontWeight: '1000' }
}

export const socialMediaIconsMapper = {
    facebook: <Facebook className='socialIcon' />,
    instagram: <Instagram className='socialIcon' />,
    twitter: <Twitter className='socialIcon' />,
    linkedIn: <LinkedLn className='socialIcon' />
}
export const propertiesMapper = {
    'contrast': { 1: 'bright', 2: 'normal', 3: 'high' },
    'figure': { 1: '', 2: '', 3: '' },
    'standardOrCaps': { 1: 'lowercase', 2: 'normalcase', 3: 'uppercase' },
    'weight': { 1: 200, 2: 600, 3: 800 },
    'width': { 1: 16, 2: 30, 3: 45 },
    'height': { 1: 16, 2: 18, 3: 20 },

}