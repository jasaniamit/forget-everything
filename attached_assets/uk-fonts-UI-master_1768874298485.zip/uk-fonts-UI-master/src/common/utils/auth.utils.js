import createNotification from "../../components/UI/Notifications/Notifications"
import store from "../store/store"
import * as actionsDispatcher from '../actions/actionsDispatcher'

export const getToken = () => {
    return sessionStorage.getItem('token')
}

export const setToken = (token) => {
    return sessionStorage.setItem('token', token)
}

export const getAuthHeader = () => {
    const token = getToken()
    if (token === '') {
        const error = new Error('Session Expired')
        error.code = 403
        throw error
    }
    else {
        return { Authorization: `Bearer ${token}` }
    }

}

export const sessionExpiredHandler = () => {
    setToken('')
    createNotification('error', 'Session Expired')
    store.dispatch(actionsDispatcher.setAuth({ isLoggedIn: false }))
}