/* eslint-disable no-param-reassign */
import produce from 'immer'
import * as actionTypes from '../constants/actionTypes'

const initialState = {
    authentication: {
        isLoading: false,
        error: '',
        isLoggedIn: false
    },
    designerList: [],
    isDesignerListLoading: false,
    fontStylesList: [],
    isFontStylesList: false,
    categoriesList: [],
    isCategoriesListLoading: false,
    fontList: [],
    isFontListLoading: false,
    isDeleteFontLoading: false,
    isFontSubmitLoading: false,
}

const admin = (state = initialState, action) =>
    produce(state, (draft) => {
        switch (action.type) {
            case actionTypes.SET_AUTHENTICATION:
                draft.authentication = {
                    ...state.authentication,
                    ...action.data
                }
                break
            case actionTypes.SET_DESIGNER_LIST:
                draft.designerList = action.data
                break
            case actionTypes.SET_DESIGNER_LIST_LOADING:
                draft.isDesignerListLoading = action.data
                break
            case actionTypes.SET_FONT_STYLE_LIST:
                draft.fontStylesList = action.data
                break
            case actionTypes.SET_FONT_STYLE_LIST_LOADING:
                draft.isFontStylesList = action.data
                break
            case actionTypes.SET_CATEGORIES_NAME_LIST:
                draft.categoriesList = action.data
                break
            case actionTypes.SET_CATEGORIES_NAME_LIST_LOADING:
                draft.isCategoriesListLoading = action.data
                break
            case actionTypes.SET_FONT_NAME_LIST:
                draft.fontList = action.data
                break
            case actionTypes.SET_FONT_NAME_LIST_LOADING:
                draft.isFontListLoading = action.data
                break
            case actionTypes.SET_DELETE_FONT_LOADING:
                draft.isDeleteFontLoading = action.data
                break
            case actionTypes.SET_FONT_SUBMIT_LOADING:
                draft.isFontSubmitLoading = action.data
                break
            // case actionTypes.SET_SELECTED_FONT_MAP:
            //     draft.selectedFontMap = action.data
            //     break
            // case actionTypes.SET_SELECTED_FONT_PARING:
            //     draft.selectedFontPairing = {
            //         ...state.selectedFontPairing,
            //         ...action.data
            //     }
            //     break
            // case actionTypes.SET_SELECTED_FONT_CATEGORY:
            //     draft.selectedFontCategory = action.data
            //     break
            //   case actionTypes.SAVE_FORM_DATA:
            //     draft.formData = action.data
            //     break
            //   case actionTypes.SET_PRICES:
            //     draft.prices = action.data
            //     break
            //   case actionTypes.GET_PAYMENT_DATA:
            //     draft.paymentData = action.data
            //     break
            //   case actionTypes.UPDATE_PAYMENT_STATUS:
            //     draft.paymentStatus = action.data
            //     break
            default:
                break
        }
    })

export default admin
