import { combineReducers } from 'redux'
import selectedOptionsReducer from './selectedOptionsReducer'
import incomingDataReducer from './incomingDataReducer'
import admin from './admin'

const rootReducer = combineReducers({
    selectedOptionsReducer,
    incomingDataReducer,
    admin
})

export default rootReducer