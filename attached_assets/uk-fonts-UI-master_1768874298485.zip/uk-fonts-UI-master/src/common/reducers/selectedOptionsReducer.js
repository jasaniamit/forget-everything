/* eslint-disable no-param-reassign */
import produce from 'immer'
import { defaultSelectedFontControls } from '../constants/defaults'
import * as actionTypes from '../constants/actionTypes'

const initialState = {
    screenWidth: 1920,
    isDarkMode: false,
    selectedFontControlOptions: defaultSelectedFontControls,
    searchText: '',
    selectedAlphabet: '',
    selectedFontMap: '',
    selectedFontPairing: {
        heading: '',
        subHeading: '',
        body: ''
    },
    selectedFontCategory: '',
    selectedProperties: {},
    selectedPage: 0,
    selectedDesigner: '',
    selectedFont: '',
    selectedSearchType: 'font',
}

const selectedOptionsReducer = (state = initialState, action) =>
    produce(state, (draft) => {
        switch (action.type) {
            case actionTypes.SET_SCREEN_WIDTH:
                draft.screenWidth = action.data
                break
            case actionTypes.SET_SELECTED_FONT_CONTROL_OPTIONS:
                draft.selectedFontControlOptions = {
                    ...state.selectedFontControlOptions,
                    ...action.data
                }
                break
            case actionTypes.SET_DARK_MODE:
                draft.isDarkMode = action.data
                break
            case actionTypes.SET_SEARCH_TEXT:
                draft.searchText = action.data
                break
            case actionTypes.SET_SELECTED_ALPHABET:
                draft.selectedAlphabet = action.data
                break
            case actionTypes.SET_SELECTED_FONT_MAP:
                draft.selectedFontMap = action.data
                break
            case actionTypes.SET_SELECTED_FONT_PARING:
                draft.selectedFontPairing = {
                    ...state.selectedFontPairing,
                    ...action.data
                }
                break
            case actionTypes.SET_SELECTED_FONT_CATEGORY:
                draft.selectedFontCategory = action.data
                break
            case actionTypes.SET_SELECTED_PROPERTIES:
                draft.selectedProperties = action.data
                break
            case actionTypes.SET_SELECTED_PAGE:
                draft.selectedPage = action.data
                break
            case actionTypes.SET_SELECTED_DESIGNER:
                draft.selectedDesigner = action.data
                break
            case actionTypes.SET_SELECTED_FONT:
                draft.selectedFont = action.data
                break
            case actionTypes.SET_SELECTED_SEARCH_TYPE:
                draft.selectedSearchType = action.data
                break
            default:
                break
        }
    })

export default selectedOptionsReducer
