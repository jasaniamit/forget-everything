/* eslint-disable no-param-reassign */
import produce from 'immer'
import * as actionTypes from '../constants/actionTypes'

const initialState = {
    fontListData: {},
    isFontListLoading: false,
    fontCategoryList: [],
    isFontCategoryListLoading: false,
    fontCategoryData: {},
    isFontCategoryDataLoading: false,
    designerData: {},
    isDesignerDataLoading: false,
    searchData: {
        "font": 0,
        "category": 0,
        "designer": 0,
    },
    isSearchDataLoading: false,
    fontDetails: {},
    isFontDetailsLoading: false,
    searchCategoryList: {},
    isSearchCategoryListLoading: false,
    searchDesignerList: {},
    isSearchDesignerListLoading: false,
    fontMapData: [],
    isFontMapDataLoading: false,
}

const incomingDataReducer = (state = initialState, action) =>
    produce(state, (draft) => {
        switch (action.type) {
            case actionTypes.SET_FONT_LIST_DATA:
                draft.fontListData = action.data
                break
            case actionTypes.SET_FONT_LIST_DATA_LOADING:
                draft.isFontListLoading = action.data
                break
            case actionTypes.SET_FONT_CATEGORY_LIST_DATA:
                draft.fontCategoryList = action.data
                break
            case actionTypes.SET_FONT_CATEGORY_LIST_LOADING:
                draft.isFontCategoryListLoading = action.data
                break
            case actionTypes.SET_FONT_CATEGORY_DATA:
                draft.fontCategoryData = action.data
                break
            case actionTypes.SET_FONT_CATEGORY_DATA_LOADING:
                draft.isFontCategoryDataLoading = action.data
                break
            case actionTypes.SET_DESIGNER_DATA:
                draft.designerData = action.data
                break
            case actionTypes.SET_DESIGNER_DATA_LOADING:
                draft.isDesignerDataLoading = action.data
                break
            case actionTypes.SET_SEARCH_DATA:
                draft.searchData = {
                    ...state.searchData,
                    ...action.data
                }
                break
            case actionTypes.SET_SEARCH_DATA_LOADING:
                draft.isSearchDataLoading = action.data
                break
            case actionTypes.SET_FONT_DETAILS:
                draft.fontDetails = action.data
                break
            case actionTypes.SET_FONT_DETAILS_LOADING:
                draft.isFontDetailsLoading = action.data
                break
            case actionTypes.SET_SEARCH_CATEGORY_LIST:
                draft.searchCategoryList = action.data
                break
            case actionTypes.SET_SEARCH_CATEGORY_LIST_LOADING:
                draft.isSearchCategoryListLoading = action.data
                break
            case actionTypes.SET_SEARCH_DESIGNER_LIST:
                draft.searchDesignerList = action.data
                break
            case actionTypes.SET_SEARCH_DESIGNER_LIST_LOADING:
                draft.isSearchDesignerListLoading = action.data
                break
            case actionTypes.SET_FONT_MAP_DATA:
                draft.fontMapData = action.data
                break
            case actionTypes.SET_FONT_MAP_DATA_LOADING:
                draft.isFontMapDataLoading = action.data
                break
            // case actionTypes.SET_SELECTED_FONT_CATEGORY:
            //     draft.selectedFontCategory = action.data
            //     break
            //   case actionTypes.SAVE_FORM_DATA:
            //     draft.formData = action.data
            //     break
            //   case actionTypes.SET_PRICES:
            //     draft.prices = action.data
            //     break
            //   case actionTypes.GET_PAYMENT_DATA:
            //     draft.paymentData = action.data
            //     break
            //   case actionTypes.UPDATE_PAYMENT_STATUS:
            //     draft.paymentStatus = action.data
            //     break
            default:
                break
        }
    })

export default incomingDataReducer
