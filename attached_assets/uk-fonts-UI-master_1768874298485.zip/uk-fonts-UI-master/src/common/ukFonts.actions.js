import axios from "axios"
import { pathOr } from 'ramda'
import * as services from './serviceUrl'
import { actionsErrorCatch, fontLoader, generateFontListForIncomingData, getSelectedProperties, parseIncommingList, parseStylesList } from "./utils/common.utils"
import * as actionsDispatcher from './actions/actionsDispatcher'
import { string } from './utils/stringUtils'
import createNotification from '../components/UI/Notifications/Notifications'
import toast from 'react-hot-toast'
import { getAuthHeader, setToken } from "./utils/auth.utils"

export const getFontList = () => async (dispatch, getState) => {
    try {
        let data = {}
        const { selectedFontControlOptions: { isCommercial },
            selectedPage,
            searchText,
            selectedAlphabet,
            selectedProperties,
            selectedFontCategory,
            selectedDesigner } = getState().selectedOptionsReducer
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.getFontByName}`
        const payload = {
            pageNumber: selectedPage,
            pageSize: 14,
            name: searchText,
            tags: '',
            alphabet: selectedAlphabet,
            isCommercial: isCommercial,
            category: selectedFontCategory,
            designer: selectedDesigner,
            ...getSelectedProperties(selectedProperties)
        }

        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setIsFontListLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const incomingData = pathOr({}, ['data', 'data'])(response)
        data['data'] = generateFontListForIncomingData(incomingData['fontDTO'])
        data['count'] = incomingData['totalCount']
        dispatch(actionsDispatcher.setFontListData(data))
        if (data['count'] > 0) {
            fontLoader(data['data'], actionsDispatcher.setIsFontListLoading)
        } else {
            dispatch(actionsDispatcher.setIsFontListLoading(false))
        }
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setFontListData({ data: [], count: 0 }))
        dispatch(actionsDispatcher.setIsFontListLoading(false))
    }
}

export const getSearchData = () => async (dispatch, getState) => {
    try {
        const { searchText } = getState().selectedOptionsReducer
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.searchData}`
        const payload = {
            searchText
        }

        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setSearchDataLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = pathOr({}, ['data', 'data'])(response)
        dispatch(actionsDispatcher.setSearchData(data))
        dispatch(actionsDispatcher.setSearchDataLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setSearchData({
            "font": 0,
            "category": 0,
            "designer": 0,
        }))
        dispatch(actionsDispatcher.setSearchDataLoading(false))
    }
}

export const getSearchCategoryList = () => async (dispatch, getState) => {
    try {
        let data = {}
        const {
            selectedPage,
            searchText } = getState().selectedOptionsReducer
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.searchCategoryList}`
        const payload = {
            pageNumber: selectedPage,
            pageSize: 14,
            searchText,
        }
        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setSearchCategoryListLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const incomingData = pathOr({}, ['data', 'data'])(response)
        data['data'] = incomingData['category']
        data['count'] = incomingData['pageSize']
        dispatch(actionsDispatcher.setSearchCategoryList(data))
        dispatch(actionsDispatcher.setSearchCategoryListLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setSearchCategoryList({ data: [], count: 0 }))
        dispatch(actionsDispatcher.setSearchCategoryListLoading(false))
    }
}

export const getSearchDesignerList = () => async (dispatch, getState) => {
    try {
        let data = {}
        const {
            selectedPage,
            searchText } = getState().selectedOptionsReducer
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.searchDesignerList}`
        const payload = {
            pageNumber: selectedPage,
            pageSize: 14,
            searchText,
        }
        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setSearchDesignerListLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const incomingData = pathOr([], ['data', 'data'])(response)
        data['data'] = incomingData['designer']
        data['count'] = incomingData['pageSize']
        dispatch(actionsDispatcher.setSearchDesignerList(data))
        dispatch(actionsDispatcher.setSearchDesignerListLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setSearchDesignerList({ data: [], count: 0 }))
        dispatch(actionsDispatcher.setSearchDesignerListLoading(false))
    }
}

export const getCategoryList = () => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.getCategoryList}`

        dispatch(actionsDispatcher.setIsFontCategoryListLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = pathOr([], ['data', 'data'])(response)
        dispatch(actionsDispatcher.setFontCategoryListData(data))
        dispatch(actionsDispatcher.setIsFontCategoryListLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setFontCategoryListData([]))
        dispatch(actionsDispatcher.setIsFontCategoryListLoading(false))
    }
}

export const getCategoryInfo = () => async (dispatch, getState) => {
    try {
        const { selectedFontCategory } = getState().selectedOptionsReducer

        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.getCategoryData}`
        const payload = {
            category: selectedFontCategory
        }

        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setIsFontCategoryDataLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = pathOr({}, ['data', 'data'])(response)
        dispatch(actionsDispatcher.setFontCategoryData(data))
        dispatch(actionsDispatcher.setIsFontCategoryDataLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setFontCategoryData({}))
        dispatch(actionsDispatcher.setIsFontCategoryDataLoading(false))
    }
}

export const getFontInfo = () => async (dispatch, getState) => {
    try {
        const { selectedFont } = getState().selectedOptionsReducer

        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.fontInfo}`
        const payload = {
            fontName: selectedFont
        }
        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setFontDetailsLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = pathOr({}, ['data', 'data'])(response)
        dispatch(actionsDispatcher.setFontDetails(data))
        dispatch(actionsDispatcher.setFontDetailsLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setFontDetails({}))
        dispatch(actionsDispatcher.setFontDetailsLoading(false))
    }
}

export const getDesignerInfo = () => async (dispatch, getState) => {
    try {
        const { selectedDesigner } = getState().selectedOptionsReducer

        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.getDesignerInfo}`
        const payload = {
            designer: selectedDesigner
        }

        url = string.substitute(url, payload)

        dispatch(actionsDispatcher.setIsDesignerDataLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = pathOr({}, ['data', 'data'])(response)
        dispatch(actionsDispatcher.setDesignerData(data))
        dispatch(actionsDispatcher.setIsDesignerDataLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setDesignerData({}))
        dispatch(actionsDispatcher.setIsDesignerDataLoading(false))
    }
}
export const getAuth = (username, password) => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.auth}`
        const payload = {
            username,
            password
        }
        dispatch(actionsDispatcher.setAuth({ isLoading: true, isError: false }))
        const response = await axios({
            method: 'post',
            url: url,
            data: payload
        })
        const incomingData = pathOr([], ['data'])(response)
        if (incomingData.code === '403') {
            throw new Error(incomingData.message)
        } else {
            setToken(incomingData.data)
            dispatch(actionsDispatcher.setAuth({ isLoading: false, isLoggedIn: true }))
            createNotification('success', 'Logged in')
        }
    }
    catch (err) {
        console.log(err)
        dispatch(actionsDispatcher.setAuth({ isLoading: false, error: err.message }))
    }
}

export const getDesignersList = () => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.designerList}`
        dispatch(actionsDispatcher.setIsDesignerListLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = parseIncommingList(pathOr([], ['data', 'data', 'designer'])(response))
        dispatch(actionsDispatcher.setDesignerList(data))
        dispatch(actionsDispatcher.setIsDesignerListLoading(false))
    }
    catch (err) {
        console.log(err)
        createNotification('error', err.message)
        dispatch(actionsDispatcher.setDesignerList([]))
        dispatch(actionsDispatcher.setIsDesignerListLoading(false))
    }
}

export const getstylesList = () => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.styleList}`
        dispatch(actionsDispatcher.setFontStyleListLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = parseStylesList(pathOr([], ['data', 'data'])(response))
        dispatch(actionsDispatcher.setFontStyleList(data))
        dispatch(actionsDispatcher.setFontStyleListLoading(false))
    }
    catch (err) {
        actionsErrorCatch(err,
            [() => actionsDispatcher.setFontStyleList([]), () => actionsDispatcher.setFontStyleListLoading(false)],
            'Failed to get styles list')
    }
}

export const getCategoryNameList = () => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.categoryNameList}`
        dispatch(actionsDispatcher.setCategoriesNameListisLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = parseIncommingList(pathOr([], ['data', 'data', 'category'])(response))
        dispatch(actionsDispatcher.setCategoriesNameList(data))
        dispatch(actionsDispatcher.setCategoriesNameListisLoading(false))
    }
    catch (err) {
        actionsErrorCatch(err,
            [() => actionsDispatcher.setCategoriesNameList([]),
            () => actionsDispatcher.setCategoriesNameListisLoading(false)],
            'Failed to get category list')
    }
}

export const getFontNameList = () => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.fontNameList}`
        dispatch(actionsDispatcher.setFontsNameListIsLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = parseIncommingList(pathOr([], ['data', 'data'])(response))
        dispatch(actionsDispatcher.setFontsNameList(data))
        dispatch(actionsDispatcher.setFontsNameListIsLoading(false))
    }
    catch (err) {
        actionsErrorCatch(err,
            [() => actionsDispatcher.setFontsNameList([]),
            () => actionsDispatcher.setFontsNameListIsLoading(false)],
            'Failed to get font list')
    }
}

export const deleteFont = (id) => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.deleteFont}`
        const payload = {
            fontId: id,
        }

        url = string.substitute(url, payload)
        dispatch(actionsDispatcher.setDeleteFontLoading(true))
        const response = await axios({
            method: 'post',
            url: url
        })
        if (response) {
            dispatch(actionsDispatcher.setDeleteFontLoading(false))
            createNotification('success', 'Font deleted successfully')
        }
    }
    catch (err) {
        actionsErrorCatch(err, [() => actionsDispatcher.setDeleteFontLoading(false)], 'Failed to delete font')
    }
}

export const logout = () => async (dispatch, getState) => {
    try {
        setToken('')
        dispatch(actionsDispatcher.setAuth({ isLoggedIn: false }))
    }
    catch (err) {
        actionsErrorCatch(err, [], 'Failed to Log out')
    }
}

export const uploadFile = async (files, fileType) => {
    let toastId = ''
    try {
        const authHeader = getAuthHeader()
        const formData = new FormData()
        for (const file of files) {
            formData.append('file', file)
        }
        formData.set('fileType', fileType)
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.uploadFiles}`
        toastId = createNotification('loading', 'Uploading files')
        const response = await axios({
            method: 'post',
            url: url,
            data: formData,
            headers: { 'Content-Type': 'multipart/form-data', ...authHeader }
        })
        const data = pathOr({}, ['data', 'data'])(response)
        toast.dismiss(toastId)
        createNotification('info', 'Checking file upload status')
        const modifiedData = []
        data.forEach(item => {
            if (item.status === 'SUCCESS')
                modifiedData.push({ name: item.fileName, url: item.url })
            else {
                createNotification('error', `Failed to upload ${item.fileName}`, 'Please reupload the file')
            }
        })
        createNotification('success', 'File Uploaded')
        return modifiedData
    }
    catch (err) {
        toast.dismiss(toastId)
        actionsErrorCatch(err, [], 'Failed to upload files')
    }
}

export const submitFont = (formData) => async (dispatch, getState) => {
    try {
        const authHeader = getAuthHeader()
        const payload = {
            fontDetail: {
                fontName: formData?.fontFileforBrowser[0]?.name,
                url: formData?.fontFileforBrowser[0]?.url,
                about: formData?.fontAbout,
                description: formData?.fontDescription,
                license: formData?.fontLicensetype,
                fontImage: formData?.fontImages,
                fontZipUrl: formData?.fontFileZip[0]?.url,
                commercial: formData['fontIsComercial'] && formData['fontIsComercial'] === 'true' ? true : false,
            },
            designerDetail: {
                id: formData?.designerId || '',
                name: formData?.designerName || '',
                email: formData?.designerEmail || '',
                photoName: formData?.designerProfileImage[0]?.name || '',
                url: formData?.designerProfileImage[0]?.url || '',
                about: formData?.designerAbout || '',
                license: formData?.designerLicense || '',
                commercialLicense: formData?.designerCommercialLicense || '',
                website: formData?.designerWebsite || '',
                designerInfo: formData?.designerAbout || '',
                socialMediaLinks: {
                    facebook: formData?.designerFacebook || '',
                    instagram: formData?.designerInstagram || '',
                    linkedIn: formData?.designerLinkedIn || '',
                    twitter: formData?.designerTwitter || '',
                },
            },
            style: {
                weight: formData['Weight'] ? formData['Weight'] : '',
                width: formData['Width'] ? formData['Width'] : '',
                figure: formData['Figure'] ? formData['Figure'] : '',
                height: formData['X-Height'] ? formData['X-Height'] : '',
                contrast: formData['Contrast'] ? formData['Contrast'] : '',
                standardOrCaps: formData['Standard Or Caps'] ? formData['Standard Or Caps'] : '',
            },
            category: formData?.categories
        }
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.submitFont}`
        dispatch(actionsDispatcher.setFontSubmitLoading(true))
        const response = await axios({
            method: 'post',
            url: url,
            data: payload,
            headers: { ...authHeader }
        })
        const data = pathOr({}, ['data', 'data'])(response)
        if (data) {
            createNotification('success', 'Font submitted')
            dispatch(actionsDispatcher.setFontSubmitLoading(false))
        }
    }
    catch (err) {
        actionsErrorCatch(err, [() => actionsDispatcher.setFontSubmitLoading(false)], 'Failed to submit font')
    }
}

export const getFontMap = (id) => async (dispatch, getState) => {
    try {
        let url = `${services.baseUrl[process.env.NODE_ENV]}/${services.fontMap}`
        dispatch(actionsDispatcher.setFontMapDataLoading(true))
        const response = await axios({
            method: 'get',
            url: url
        })
        const data = pathOr({}, ['data', 'data'])(response)
        if (data.length > 0) {
            dispatch(actionsDispatcher.setFontMapData(data))
            fontLoader(data, actionsDispatcher.setFontMapDataLoading)
        } else {
            dispatch(actionsDispatcher.setFontMapDataLoading(false))
        }
    }
    catch (err) {
        actionsErrorCatch(err, [() => actionsDispatcher.setFontMapDataLoading(false)], 'Failed to load font data')
    }
}