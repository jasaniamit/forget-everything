import * as actionTypes from './../constants/actionTypes'

/* ==================== Selected Options ====================*/
export const updateScreenWidth = (result) => {
    return {
        type: actionTypes.SET_SCREEN_WIDTH,
        data: result
    }
}
export const setSelectedFontOptions = (data) => {
    return {
        type: actionTypes.SET_SELECTED_FONT_CONTROL_OPTIONS,
        data
    }
}
export const setDarkMode = (data) => {
    return {
        type: actionTypes.SET_DARK_MODE,
        data
    }
}
export const setSearchText = (data) => {
    return {
        type: actionTypes.SET_SEARCH_TEXT,
        data
    }
}
export const setAlphabet = (data) => {
    return {
        type: actionTypes.SET_SELECTED_ALPHABET,
        data
    }
}
export const setFontMap = (data) => {
    return {
        type: actionTypes.SET_SELECTED_FONT_MAP,
        data
    }
}
export const setfontPairing = (data) => {
    return {
        type: actionTypes.SET_SELECTED_FONT_PARING,
        data
    }
}

export const setFontCategory = (data) => {
    return {
        type: actionTypes.SET_SELECTED_FONT_CATEGORY,
        data
    }
}

export const setProperties = (data) => {
    return {
        type: actionTypes.SET_SELECTED_PROPERTIES,
        data
    }
}

export const setPage = (data) => {
    return {
        type: actionTypes.SET_SELECTED_PAGE,
        data
    }
}
export const setDesigner = (data) => {
    return {
        type: actionTypes.SET_SELECTED_DESIGNER,
        data
    }
}

export const setSelectedFont = (data) => {
    return {
        type: actionTypes.SET_SELECTED_FONT,
        data
    }
}

export const setSelectedSearchType = (data) => {
    return {
        type: actionTypes.SET_SELECTED_SEARCH_TYPE,
        data
    }
}


/* ==================== Incoming Data ====================*/

export const setFontListData = (data) => {
    return {
        type: actionTypes.SET_FONT_LIST_DATA,
        data
    }
}
export const setIsFontListLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_LIST_DATA_LOADING,
        data
    }
}
export const setFontCategoryListData = (data) => {
    return {
        type: actionTypes.SET_FONT_CATEGORY_LIST_DATA,
        data
    }
}
export const setIsFontCategoryListLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_CATEGORY_LIST_LOADING,
        data
    }
}
export const setFontCategoryData = (data) => {
    return {
        type: actionTypes.SET_FONT_CATEGORY_DATA,
        data
    }
}
export const setIsFontCategoryDataLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_CATEGORY_DATA_LOADING,
        data
    }
}
export const setDesignerData = (data) => {
    return {
        type: actionTypes.SET_DESIGNER_DATA,
        data
    }
}
export const setIsDesignerDataLoading = (data) => {
    return {
        type: actionTypes.SET_DESIGNER_DATA_LOADING,
        data
    }
}
export const setSearchData = (data) => {
    return {
        type: actionTypes.SET_SEARCH_DATA,
        data
    }
}
export const setSearchDataLoading = (data) => {
    return {
        type: actionTypes.SET_SEARCH_DATA_LOADING,
        data
    }
}
export const setFontDetails = (data) => {
    return {
        type: actionTypes.SET_FONT_DETAILS,
        data
    }
}
export const setFontDetailsLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_DETAILS_LOADING,
        data
    }
}
export const setSearchCategoryList = (data) => {
    return {
        type: actionTypes.SET_SEARCH_CATEGORY_LIST,
        data
    }
}
export const setSearchCategoryListLoading = (data) => {
    return {
        type: actionTypes.SET_SEARCH_CATEGORY_LIST_LOADING,
        data
    }
}
export const setSearchDesignerList = (data) => {
    return {
        type: actionTypes.SET_SEARCH_DESIGNER_LIST,
        data
    }
}
export const setSearchDesignerListLoading = (data) => {
    return {
        type: actionTypes.SET_SEARCH_DESIGNER_LIST_LOADING,
        data
    }
}
export const setFontMapData = (data) => {
    return {
        type: actionTypes.SET_FONT_MAP_DATA,
        data
    }
}
export const setFontMapDataLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_MAP_DATA_LOADING,
        data
    }
}

/* ==================== Admin ====================*/

export const setAuth = (data) => {
    return {
        type: actionTypes.SET_AUTHENTICATION,
        data
    }
}

export const setDesignerList = (data) => {
    return {
        type: actionTypes.SET_DESIGNER_LIST,
        data
    }
}

export const setIsDesignerListLoading = (data) => {
    return {
        type: actionTypes.SET_DESIGNER_LIST_LOADING,
        data
    }
}
export const setFontStyleList = (data) => {
    return {
        type: actionTypes.SET_FONT_STYLE_LIST,
        data
    }
}

export const setFontStyleListLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_STYLE_LIST_LOADING,
        data
    }
}
export const setCategoriesNameList = (data) => {
    return {
        type: actionTypes.SET_CATEGORIES_NAME_LIST,
        data
    }
}

export const setCategoriesNameListisLoading = (data) => {
    return {
        type: actionTypes.SET_CATEGORIES_NAME_LIST_LOADING,
        data
    }
}
export const setFontsNameList = (data) => {
    return {
        type: actionTypes.SET_FONT_NAME_LIST,
        data
    }
}
export const setFontsNameListIsLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_NAME_LIST_LOADING,
        data
    }
}
export const setDeleteFontLoading = (data) => {
    return {
        type: actionTypes.SET_DELETE_FONT_LOADING,
        data
    }
}
export const setFontSubmitLoading = (data) => {
    return {
        type: actionTypes.SET_FONT_SUBMIT_LOADING,
        data
    }
}