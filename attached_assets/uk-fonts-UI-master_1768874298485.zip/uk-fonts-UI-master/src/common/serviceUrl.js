/* eslint-disable */

export const baseUrl = {
    production: '',
    development: 'http://localhost:8080'
}
export const getFontByName =
    'font/list?pageNumber=${pageNumber}&pageSize=${pageSize}&name=${name}&alphabet=${alphabet}&isCommercial=${isCommercial}&category=${category}&designer=${designer}&weight=${weight}&figure=${figure}&height=${height}&contrast=${contrast}&standardOrCaps=${standardOrCaps}&width=${width}'
export const getCategoryList = 'category/list/all'
export const getCategoryData = 'category/${category}'
export const getDesignerInfo = 'designer/info/${designer}'
export const auth = 'authenticate'
export const designerList = 'designer/list'
export const styleList = 'style/list'
export const categoryNameList = 'category/list'
export const fontNameList = 'font/name/list'
export const deleteFont = 'firebase/delete/${fontId}'
export const adminLogout = 'doLogout'
export const uploadFiles = 'firebase/upload'
export const submitFont = 'font/save'
export const searchData = 'search/count/${searchText}'
export const searchCategoryList = 'category/list?pageNumber=${pageNumber}&pageSize=${pageSize}&name=${searchText}'
export const searchDesignerList = 'designer/list?pageNumber=${pageNumber}&pageSize=${pageSize}&name=${searchText}'
export const fontInfo = 'font/${fontName}'
export const fontMap = 'font/map'