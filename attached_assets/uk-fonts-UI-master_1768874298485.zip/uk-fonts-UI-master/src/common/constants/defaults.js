import { Facebook, Instagram, LinkedLn, Twitter } from "../../assets/icons"

export const defaultTextColor = {
    true: {
        foregroundColor: '#FFFFFF',
        backgroundColor: '#202632',
    },
    false: {
        foregroundColor: '#000000',
        backgroundColor: '#FFFFFF',
    }
}

export const defaultSelectedFontControls = {
    text: 'The quick brown fox jumps over the lazy dog',
    fontSize: 16,
    color: {
        foregroundColor: '#000000',
        backgroundColor: '#FFFFFF',
    },
    isCommercial: true,
}

export const glyphsPropertyConfig = [
    { weight: 'fontLight', letter: 'G', keyNumber: 1 },
    { weight: 'fontMedium', letter: 'G', keyNumber: 2 },
    { weight: 'fontHeavy', letter: 'G', keyNumber: 3 }
]

export const socialMediaIcons = [
    { comp: <Instagram className='socialIcon' />, link: "https://www.instagram.com" },
    { comp: <Facebook className='socialIcon' />, link: "https://www.facebook.com" },
    { comp: <Twitter className='socialIcon' />, link: "https://www.twitter.com" },
    { comp: <LinkedLn className='socialIcon' />, link: "https://www.linkedin.com" }
]

export const allCharacters = 'ABCČĆDĐEFGHIJKLMNOPQRSŠTUVWXYZŽabcčćdđefghijklmnopqrsštuvwxyzžАБВГҐДЂЕЁЄЖЗЅИІЇЙЈКЛЉМНЊОПРСТЋУЎФХЦЧЏШЩЪЫЬЭЮЯабвгґдђеёєжзѕиіїйјклљмнњопрстћуўфхцчџшщъыьэюяΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάΆέΈέΉίϊΐΊόΌύΰϋΎΫὰάὲέὴήὶίὸόὺύὼώΏĂÂÊÔƠƯăâêôơư1234567890‘?’“!”(%)[#]{@}/&<-+÷×=>®©$€£¥¢:;,.*'

export const stylesOptions = [
    { key: '1', text: '1' },
    { key: '2', text: '2' },
    { key: '3', text: '3' },
]

export const booleanOptions = [
    { key: 'true', text: 'true' },
    { key: 'false', text: 'false' },
]

export const linkListConfigSidebar = [
    { name: 'Instagram Fonts', route: '#' },
    { name: 'Lenny Face Generator', route: '#' },
    { name: 'Font Map', route: '#' },
    { name: 'Emojis', route: '#' },
    { name: 'Font Category', route: '#' },
]
export const designerDetails = [
    { label: 'Name *', placeholder: 'Name *', key: 'designerName', required: true, type: 'text' },
    { label: 'Profile Image *', placeholder: 'Profile Image *', key: 'designerProfileImage', required: true, type: 'file', accept: "image/*" },
    { label: 'Email *', placeholder: 'Email *', key: 'designerEmail', required: true, type: 'email' },
    { label: 'Website', placeholder: 'Website', key: 'designerWebsite', required: true, type: 'text' },
    { label: 'About *', placeholder: 'About *', key: 'designerAbout', required: true, type: 'textarea' },
    { label: 'Licenses *', placeholder: 'Licenses *', key: 'designerLicense', required: true, type: 'text' },
    { label: 'Commercial Licenses *', placeholder: 'Commercial Licenses *', key: 'designerCommercialLicense', required: true, type: 'text' },
    { label: 'Facebook', placeholder: 'Facebook', key: 'designerFacebook', type: 'text' },
    { label: 'Instagram', placeholder: 'Instagram', key: 'designerInstagram', type: 'text' },
    { label: 'LinkedIn', placeholder: 'LinkedIn', key: 'designerLinkedIn', type: 'text' },
    { label: 'Twitter', placeholder: 'Twitter', key: 'designerTwitter', type: 'text' },
]

export const fontDetails = [
    { label: 'Font File for browser *', placeholder: 'Font File for browser *', key: 'fontFileforBrowser', required: true, type: 'file', accept: ".woff, .woff2" },
    { label: 'Font File for Users *', placeholder: 'Font File for Users *', key: 'fontFileZip', required: true, type: 'file', accept: ".zip, .rar, .7zp" },
    { label: 'Font Images *', placeholder: 'Font Images *', key: 'fontImages', required: true, type: 'file', accept: "image/*", multiple: true },
    { label: 'Font Description *', placeholder: 'Font Description *', key: 'fontDescription', required: true, type: 'textarea' },
    { label: 'Font About *', placeholder: 'Font About *', key: 'fontAbout', required: true, type: 'textarea' },
    { label: 'License type *', placeholder: 'License type *', key: 'fontLicensetype', required: true, type: 'textarea' },
    { label: 'Is Commercial', key: 'fontIsComercial', required: true, type: 'choiceGroup', options: booleanOptions, defaultKey: '' },
]