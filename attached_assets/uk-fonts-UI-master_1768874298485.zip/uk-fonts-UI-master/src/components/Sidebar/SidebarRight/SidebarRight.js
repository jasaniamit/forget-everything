import React from 'react'
import './SidebarRight.scss'
import SidebarCatagories from '../../SidebarCatagories/SidebarCatagories'
import { getCategoryList } from '../../../common/ukFonts.actions'
import container from '../../../common/container/container'

const SidebarRight = ({
    isDarkMode,
    fontCategoryList,
    isFontCategoryListLoading,
    componentsRequired = [],
    location: { search, pathname },
    history,
    getCategoryList
}) => {

    return (
        <div className='sidebarRight'>
            <div className='logo'>
            </div>
            <div className='sidebarRightCategories'>
                {componentsRequired.includes('sidebarCategories') &&
                    <SidebarCatagories
                        isDarkMode={isDarkMode}
                        search={search}
                        pathname={pathname}
                        history={history}
                        data={fontCategoryList}
                        isLoading={isFontCategoryListLoading}
                        getCategoryList={getCategoryList} />}
            </div>

        </div>
    )

}
const mapStateToProps = (state) => {
    const { isDarkMode,
    } = state.selectedOptionsReducer

    const {
        fontCategoryList,
        isFontCategoryListLoading,
    } = state.incomingDataReducer
    return {
        isDarkMode,
        fontCategoryList,
        isFontCategoryListLoading,
    }
}

const mapDispatchToProps = {
    getCategoryList
}

export default container(SidebarRight, mapStateToProps, mapDispatchToProps)