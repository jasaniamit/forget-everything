import React from 'react'
import './SidebarLeft.scss'
import LogoMain from './../../../assets/LogoMain.svg'
import LinkList from '../../LinkList/LinkList'
import FontProperties from '../../FontProperties/FontProperties'
import Alphabets from '../../Alphabets/Alphabets'
import container from '../../../common/container/container'
import { linkListConfigSidebar } from './../../../common/constants/defaults'

const SidebarLeft = ({
    isDarkMode,
    componentsRequired = [],
    isRefreshRequired,
    selectedAlphabet,
    selectedProperties,
    history,
    location: { search },
}) => {

    return (
        <div className='sidebarLeft'>
            <div className='sidebarLeft_logo'>
                <img src={LogoMain} alt='logo' className='logoImage' />
            </div>
            {componentsRequired.includes('linkList') &&
                <div className='sidebarLeft_linkList'>
                    < LinkList
                        linkListConfig={linkListConfigSidebar}
                        isDarkMode={isDarkMode} />
                </div>}
            {componentsRequired.includes('fontProperties') &&
                <div className='sidebarLeft_fontProperties'>
                    <FontProperties
                        isDarkMode={isDarkMode}
                        isRefreshRequired={isRefreshRequired}
                        selectedAlphabet={selectedAlphabet}
                        history={history}
                        search={search}
                        selectedProperties={selectedProperties}
                    />
                </div>}
            {componentsRequired.includes('alphabets') &&
                <div className='sidebarLeft_alphabets'>
                    <Alphabets
                        isDarkMode={isDarkMode}
                        isRefreshRequired={isRefreshRequired}
                        selectedAlphabet={selectedAlphabet}
                        history={history}
                        search={search}
                    />
                </div>}
        </div>
    )

}

const mapStateToProps = (state) => {
    const {
        isDarkMode,
        selectedAlphabet,
        selectedProperties,
    } = state.selectedOptionsReducer
    return {
        isDarkMode,
        selectedAlphabet,
        selectedProperties,
    }
}

const mapDispatchToProps = {
}

export default container(SidebarLeft, mapStateToProps, mapDispatchToProps)