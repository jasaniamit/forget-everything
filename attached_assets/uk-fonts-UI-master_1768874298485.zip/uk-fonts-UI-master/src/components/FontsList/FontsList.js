import React, { Fragment, useState } from 'react'
import PaginationComponent from '../PaginationComponent/PaginationComponent'
import Spinner from '../UI/Spinner/Spinner'
import FontListItem from './FontListItem/FontListItem'
import Viewer from 'react-viewer';
import './FontsList.scss'

const FontsList = ({
    isDarkMode,
    isLoading = false,
    options = [],
    count = 0,
    selectedFontControlOptions,
    linksAreClickable = true,
    search,
    history,
    isPaginationRequired,
    selectedPage = 0
}) => {
    const [isImageViewerVisisble, setIsImageViewerVisisble] = useState(false)
    const [viewerImageSource, setViewerImageSource] = useState('')

    const onViewerClose = () => {
        setViewerImageSource('')
        setIsImageViewerVisisble(false)
    }

    return (
        <Fragment>
            {isLoading ?
                <div className='fontsList'>
                    <Spinner
                        isDarkMode={isDarkMode} />
                </div> :
                <div className='fontsList'>
                    {
                        count > 0 ?
                            <Fragment>
                                {
                                    options.map((item, index) => (
                                        <Fragment>
                                            <FontListItem
                                                isDarkMode={isDarkMode}
                                                key={item.fontFamilyName}
                                                itemConfig={item}
                                                selectedFontControlOptions={selectedFontControlOptions}
                                                linksAreClickable={linksAreClickable}
                                                setIsImageViewerVisisble={setIsImageViewerVisisble}
                                                setViewerImageSource={setViewerImageSource}

                                            />
                                            {(index !== options.length - 1) &&
                                                <hr key={index} className='fontList_seperator' />
                                            }
                                        </Fragment>
                                    ))
                                }
                                {isPaginationRequired &&
                                    <PaginationComponent
                                        search={search}
                                        history={history}
                                        selectedPage={selectedPage}
                                        count={count} />}
                            </Fragment> :
                            <div className='noItemFontMsg'>
                                <p className='secondaryHeadings'>No fonts Found</p>
                            </div>
                    }

                </div>}
            <Viewer
                visible={viewerImageSource && isImageViewerVisisble}
                onClose={onViewerClose}
                images={[{ src: viewerImageSource, downloadUrl: viewerImageSource, alt: '' }]}
                //downloadable
                rotatable={false}
                zoomSpeed={1}
            />
        </Fragment>
    )
}

export default FontsList