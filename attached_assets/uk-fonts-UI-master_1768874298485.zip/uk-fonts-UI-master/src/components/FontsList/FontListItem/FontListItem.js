import React, { useRef } from 'react'
import { Download, Image } from '../../../assets/icons'
import { fontLoaderUsingTags, linkDownloader } from '../../../common/utils/common.utils'
import FontDisplay from '../../FontDisplay/FontDisplay'
import LinkList from '../../LinkList/LinkList'
import { toSvg } from 'html-to-image';
import './FontListItem.scss'

const FontListItem = ({
    itemConfig,
    selectedFontControlOptions,
    linksAreClickable = true,
    setViewerImageSource,
    setIsImageViewerVisisble,
    isDarkMode
}) => {
    const ref = useRef()
    const { text, fontSize, color } = selectedFontControlOptions

    const handleDownload = () => {
        linkDownloader(itemConfig.downloadZip, itemConfig.fontFamilyName)
    }
    const handleCreateImage = async () => {
        fontLoaderUsingTags(itemConfig)
        setIsImageViewerVisisble(true)
        const fontEmbedCss = await window.getComputedStyle(ref.current)
        const dataUrl = await toSvg(ref.current, { cacheBust: true, style: { fontFamily: fontEmbedCss.fontFamily } })
        setViewerImageSource(dataUrl)
    }

    return (
        <div className='fontListItem'>
            <div className='fontListItem_inner'>
                <div className='fontDisplayContainer'>
                    <FontDisplay
                        ref={ref}
                        text={text}
                        fontSize={fontSize}
                        textColor={color.foregroundColor}
                        backgroundColor={color.backgroundColor}
                        fontConfig={itemConfig}
                    />
                </div>
                <div className='iconsContainer'>
                    <span className={`fontListItem_icon ${isDarkMode ? 'darkModeSvg' : 'lightModeSvg'}`}
                        onClick={handleCreateImage}>
                        <Image />
                    </span>
                    <span className={`fontListItem_icon ${isDarkMode ? 'darkModeSvg' : 'lightModeSvg'}`}
                        onClick={handleDownload}>
                        <Download />
                    </span>
                </div>
                <div className='longLinkListContainer'>
                    <LinkList
                        linkListConfig={itemConfig.primarylinks}
                        flexPattern={'row'}
                        customClass={'localLinklist'}
                        areClickble={linksAreClickable}
                        isDarkMode={isDarkMode}
                    />
                </div>
                <div className='singleLinkListContainer'>
                    <LinkList
                        linkListConfig={itemConfig.secondarylinks}
                        flexPattern={'row'}
                        customClass={'localLinklist'}
                        isDarkMode={isDarkMode}
                    />
                </div>
            </div>
        </div>
    )
}

export default FontListItem