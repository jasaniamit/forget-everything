import React from 'react'
import './FontCategoryInfo.scss'

const FontCategoryInfo = ({ itemData }) => {
    return (
        <div className='fontCategoryInfo'>
            <p className='heading'>{itemData.name}</p>
            <p className='body'>{itemData.description}</p>
        </div>
    )
}

export default FontCategoryInfo