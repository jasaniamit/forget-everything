import React from 'react'
import Alphabet from './Alphabet/Alphabet'
import './Alphabets.scss'
import RefreshIcon from '../UI/RefreshIcon/RefreshIcon'
import { encodeURL, decodeURL } from '../../common/utils/URL'

const Alphabets = ({
    isDarkMode,
    isRefreshRequired = false,
    search,
    history,
    selectedAlphabet
}) => {

    const handleOnClick = (key) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            alphabet: key
        })
        history.push(`?${encodedUrl}`)
    }

    const onClickReset = (key) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            alphabet: ''
        })
        history.push(`?${encodedUrl}`)
    }

    return (
        <div className='alphabets'>
            <div className={`alphabets_header ${isRefreshRequired ? 'alphabets_header_withRefresh' : 'alphabets_header_withOutRefresh'}`}>
                <p>Alphabets</p>
                {isRefreshRequired &&
                    <RefreshIcon
                        onClickReset={onClickReset} />}
            </div>
            <Alphabet
                isDarkMode={isDarkMode}
                handleOnClick={handleOnClick}
                selectedAlphabet={selectedAlphabet} />
        </div>
    )

}

export default Alphabets