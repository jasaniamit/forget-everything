import React from 'react'
import './Alphabet.scss'
const Alphabet = ({
    isDarkMode,
    handleOnClick,
    selectedAlphabet
}) => {
    const lettersProducer = () => {
        const letters = []
        for (let i = 0; i < 26; i++) {
            const key = (i + 10).toString(36).toUpperCase()
            letters.push(<span key={key}

                className={`${isDarkMode ? 'letter_dark' : 'letter_light'} ${selectedAlphabet === key ? 'active' : ''}`}
                onClick={() => handleOnClick(key)}>
                {key}
            </span>)
        }
        return letters
    }

    return (<div className='alphabet'>
        {lettersProducer()}
    </div>)

}

export default Alphabet