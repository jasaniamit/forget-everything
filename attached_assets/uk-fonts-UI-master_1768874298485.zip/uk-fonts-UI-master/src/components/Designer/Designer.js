import React from 'react'
import SocialMediaIcons from '../SocialMediaIcons/SocialMediaIcons'
import './Designer.scss'

const Designer = ({
    isDarkMode,
    data = {}
}) => {

    return (
        <div className='designer'>
            <div className='designerImage'>
                <img src={data['designerImageUrl']} alt='Profile' className='image' />
            </div>
            <div className={`designerDetails ${isDarkMode ? 'darkModeText' : 'lightModeText'} `}>
                {
                    data['designerName'] &&
                    <div className='secondaryHeadings'>
                        <p>{data['designerName']}</p>
                    </div>
                }
                {
                    data['websiteAddress'] &&
                    <p className='infoSmall'>{data['websiteAddress']}</p>
                }
                {
                    data['socialMediaLinks'] &&
                    <SocialMediaIcons
                        socialMediaLinks={data['socialMediaLinks']}
                        color={'#63748c'}
                    />
                }
                {
                    data['designerInfo'] &&
                    <div className='infoSmall'>
                        <p>{data['designerInfo']}</p>
                    </div>
                }
                <div className='designerExtraInfo'>
                    {
                        data['licensedAs'] &&
                        <div className='infoDiv'>
                            <p className='heading'>Licensed As</p>
                            <p>{data['licensedAs']}</p>
                        </div>
                    }
                    {data['donations'] &&
                        <div className='infoDiv'>
                            <p className='heading'>Donations</p>
                            <p>{data['donations']}</p>
                        </div>
                    }
                    {data['commercialLicences'] &&
                        <div className='infoDiv'>
                            <p className='heading'>Commercial Licenses</p>
                            <p>{data['commercialLicences']}</p>
                        </div>
                    }
                    {data['additionalInfo'] &&
                        <div className='infoDiv'>
                            {data['additionalInfo']['email'] &&
                                <p>Email: {data['additionalInfo']['email']}</p>
                            }
                            {data['additionalInfo']['websiteAddress'] &&
                                <p>Website: {data['additionalInfo']['websiteAddress']}</p>
                            }
                        </div>
                    }
                </div>
            </div>

        </div>
    )

}

export default Designer