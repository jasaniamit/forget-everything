import React from 'react'
import './RefreshIcon.scss'

const RefreshIcon = ({
    onClickReset,
    haveBackground = true,
    isDarkMode = false,
}) => {
    return (
        <div className='customRefresh'>
            <div className={`refreshIcon ${haveBackground && (isDarkMode ? 'darkModeRefresh' : 'lightModeRefresh')} `}
                onClick={onClickReset}>
                <i className="material-icons">&#xe5d5;</i>
            </div>
        </div>
    )
}

export default RefreshIcon