import React, { Fragment, useEffect, useState } from 'react'
import './SearchBar.scss'
import { SearchLens } from '../../../assets/icons'
import { encodeURL, decodeURL } from '../../../common/utils/URL'
import Counts from '../../Counts/Counts'
import container from '../../../common/container/container'
import { getFontList, getSearchData, getSearchCategoryList, getSearchDesignerList } from '../../../common/ukFonts.actions'
import Spinner from '../Spinner/Spinner'
import { defaultTextColor } from '../../../common/constants/defaults'

const SearchBar = ({
    placeholder,
    location: { search },
    searchText,
    history,
    isDarkMode,
    searchData = {},
    isSearchDataLoading = false,
    getSearchData,
    selectedSearchType,
    getFontList,
    getSearchCategoryList,
    getSearchDesignerList
}) => {
    const [localSearchText, setLocalSearchText] = useState(searchText)

    useEffect(() => {
        setLocalSearchText(searchText)
        searchText !== '' && getSearchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchText])

    useEffect(() => {
        if (searchText) {
            switch (selectedSearchType) {
                case 'font':
                case '':
                    getFontList()
                    break
                case 'category':
                    getSearchCategoryList()
                    break
                case 'designer':
                    getSearchDesignerList()
                    break
                default:
                    break
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchText, selectedSearchType])


    const handleSearch = () => {
        const queryObject = decodeURL(search)
        const { searchType = 'font', isDarkModeEnable = false, selectedFontControls = { color: defaultTextColor[false] } } = queryObject
        const encodedUrl = encodeURL({
            query: localSearchText,
            searchType,
            isDarkModeEnable,
            selectedFontControls
        })
        history.push(`/home?${encodedUrl}`)
    }

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            handleSearch()
        }
    }

    const onCountClick = (searchType) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            searchType
        })
        history.push(`?${encodedUrl}`)
    }

    return (
        <div className='customFields'>
            <header className='header'>
                <div className='searchBar'>
                    <input type="text"
                        placeholder={placeholder}
                        value={localSearchText}
                        onChange={e => setLocalSearchText(e.target.value)}
                        onKeyDown={handleKeyDown}
                        className='searchBarInput'
                    />
                    <span className='searchButton' onClick={handleSearch}>
                        <SearchLens width={'2rem'} height={'2rem'} />
                    </span>
                </div>
            </header>
            {isSearchDataLoading ?
                <Spinner
                    isDarkMode={isDarkMode} /> :
                <Fragment>
                    {
                        searchText !== '' &&
                        <div className='searchCountResult'>
                            {
                                Object.keys(searchData).map((item, index) => (
                                    <Counts
                                        key={item}
                                        isDarkMode={isDarkMode}
                                        selectedCount={selectedSearchType}
                                        count={searchData[item]}
                                        categoryName={item}
                                        onCountClick={onCountClick}
                                    />
                                ))
                            }
                        </div>
                    }
                </Fragment>
            }
        </div>
    )
}

const mapStateToProps = (state) => {
    const { isDarkMode,
        searchText,
        selectedSearchType
    } = state.selectedOptionsReducer

    const {
        searchData,
        isSearchDataLoading,
    } = state.incomingDataReducer
    return {
        isDarkMode,
        searchText,
        searchData,
        isSearchDataLoading,
        selectedSearchType
    }
}

const mapDispatchToProps = {
    getSearchData,
    getFontList,
    getSearchCategoryList,
    getSearchDesignerList
}
export default container(SearchBar, mapStateToProps, mapDispatchToProps)