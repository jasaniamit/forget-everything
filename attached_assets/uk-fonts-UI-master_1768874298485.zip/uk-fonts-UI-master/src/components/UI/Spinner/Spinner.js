import React from 'react'
import './Spinner.scss'

const Spinner = ({ isDarkMode }) => {
    return (
        <div className={isDarkMode ? 'spinnerDark' : 'spinnerLight'}>
            <div className="loadingio-spinner-spinner-jwtpl9btymh">
                <div className="ldio-kt3jh6izeu">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    )
}

export default Spinner