import React from 'react'
import './Spinner.scss'

const Spinner = (props) => {
    const { color = 'white', fontSize = '1.2em' } = props
    return (
        <div className="loader"
            style={{ color: color, fontSize: fontSize }} >
            Loading...
        </div>
    )
}

export default Spinner