import React from 'react'
import Spinner from './ButtonSpinner/Spinner'
import './Button.scss'

const Button = ({
    children,
    onClickEvent,
    isDisabled = false,
    buttonLong = false,
    isLoading = false,
    btnType = ""
}) => {

    return (
        <div className='customButton'>
            <button
                type={btnType}
                onClick={onClickEvent}
                disabled={isDisabled}
                className={`btn btn-brown ${isDisabled ? '' : 'btn-enabled'} ${buttonLong ? 'btn-long' : ''}`}>
                <span style={{ display: 'flex', justifyContent: 'center' }}>
                    {isLoading ? <Spinner fontSize={'1rem'} />
                        : children}
                </span>
            </button>
        </div>
    )
}

export default Button


