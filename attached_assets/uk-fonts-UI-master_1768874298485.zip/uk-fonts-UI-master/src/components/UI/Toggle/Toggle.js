import React, { useEffect, useState } from 'react'
import './Toggle.scss'
import { Moon, Sun } from '../../../assets/icons'

const Toggle = ({
  value,
  onChangeHandler
}) => {
  const [isChecked, setIsChecked] = useState(value)

  useEffect(() => {
    setIsChecked(value)
  }, [value])

  const handleCheck = (e) => {
    onChangeHandler(!isChecked)
    setIsChecked(!isChecked)
  }

  return (
    <div className="toggleContainer">
      <label>
        <input
          type="checkbox"
          checked={isChecked}
          onClick={handleCheck}
          onChange={() => { }}
        />
        <div className='toggle'>
          <span className="on"><Sun /></span>
          <span className="off"><Moon /></span>
        </div>
        <i />
      </label>
    </div>
  )
}

export default Toggle
