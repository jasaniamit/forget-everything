import React from 'react'
import './TextField.scss'

const TextField = ({
    handlerKey = '',
    value,
    onChangeTextField,
    isDarkMode = false,
    placeholder = '',
    labelText = '',
    type = 'text',
    required = false,
    accept = '',
    multiple = false
}) => {

    const textFieldSelector = () => {
        let selectedTestField = ''
        switch (type) {
            case 'text':
            case 'password':
            case 'email':
                selectedTestField = <div className='customTextField'>
                    <label className={`textFieldLabel ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
                        htmlFor={labelText}
                    >
                        {labelText}
                    </label>
                    <input
                        id={labelText}
                        value={value}
                        type={type}
                        onChange={(event) => onChangeTextField(handlerKey, event.target.value)}
                        className={`textField ${isDarkMode ? 'darkModeTextField' : 'lightModeTextField'}`}
                        placeholder={placeholder}
                        required={required}
                    />
                </div>
                break
            case 'file':
                selectedTestField = <div className='customTextField'>
                    <label className={`textFieldLabel ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
                        htmlFor={labelText}
                    >
                        {labelText}
                    </label>
                    <input
                        id={labelText}
                        type={type}
                        onChange={(event) => onChangeTextField(handlerKey, event.target.files)}
                        className={`textField ${isDarkMode ? 'darkModeTextField' : 'lightModeTextField'}`}
                        placeholder={placeholder}
                        required={required}
                        accept={accept}
                        multiple={multiple}
                    />
                </div>
                break
            case 'textarea':
                selectedTestField = <div className='customTextField'>
                    <label className={`textFieldLabel ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
                        htmlFor={labelText}
                    >
                        {labelText}
                    </label>
                    <textarea
                        id={labelText}
                        value={value}
                        onChange={(event) => onChangeTextField(handlerKey, event.target.value)}
                        className={`textField ${isDarkMode ? 'darkModeTextField' : 'lightModeTextField'}`}
                        placeholder={placeholder}
                        required={required}
                    />
                </div>
                break
            default:
                break
        }
        return selectedTestField
    }

    return textFieldSelector()

}

export default TextField