import React from 'react'
import './Slider.scss'

const Slider = ({
    handlerKey = '',
    min,
    max,
    value,
    sliderOnChangeHandler,
    isDarkMode
}) => {

    return (
        <div className='customSlider flexCenter'>
            <input
                type="range"
                min={min}
                max={max}
                value={value}
                className={isDarkMode ? 'sliderInput_dark' : 'sliderInput_light'}
                onChange={(event) => sliderOnChangeHandler(handlerKey, event.target.value)}
            />
        </div>
    )

}

export default Slider