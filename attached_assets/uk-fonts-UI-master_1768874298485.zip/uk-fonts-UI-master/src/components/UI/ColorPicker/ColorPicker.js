import React from 'react'
import './ColorPicker.scss'

const ColorPicker = ({
    handlerKey = '',
    foregroundValue,
    backgroundValue,
    onColorPickerChangeHandler
}) => {

    return (
        <div className='customColorPicker flexCenter'>
            <input
                type="color"
                name="foreground"
                value={foregroundValue}
                className='colorPicker foreground'
                onChange={(event) => onColorPickerChangeHandler(handlerKey, {
                    foregroundColor: event.target.value,
                    backgroundColor: backgroundValue
                })}
            />
            <input
                type="color"
                name="background"
                value={backgroundValue}
                className='colorPicker background'
                onChange={(event) => onColorPickerChangeHandler(handlerKey, {
                    foregroundColor: foregroundValue,
                    backgroundColor: event.target.value
                })}
            />
        </div>
    )

}

export default ColorPicker