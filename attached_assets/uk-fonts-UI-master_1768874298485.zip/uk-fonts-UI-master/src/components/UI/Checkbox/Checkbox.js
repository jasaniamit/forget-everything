import React from 'react'
import './Checkbox.scss'

const Checkbox = ({
    handlerKey = '',
    label,
    checked,
    onCheckBoxChangeHandler,
    isDarkMode = false
}) => {
    return (
        <div className='customCheckbox'>
            <label className="container">
                <input
                    name={label}
                    type="checkbox"
                    checked={checked}
                    onChange={(event) => onCheckBoxChangeHandler(handlerKey, event.target.checked)} />
                <span className="checkmark"></span>
            </label>
            <label className={`label ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}>
                {label}
            </label>
        </div>
    )
}

export default Checkbox