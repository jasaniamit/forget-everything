import React from 'react'
import './Select.scss'

const Select = ({
    handlerKey = '',
    options,
    value,
    onChangeSelect,
    isDarkMode = false
}) => {

    return (
        <div className='customSelect'>
            <select value={value}
                onChange={(event) => onChangeSelect(handlerKey, event.target.value)}
                className={`select ${isDarkMode ? 'darkModeSelect' : 'lightModeSelect'}`}
            >
                {
                    options.map((option, index) =>
                        <option key={index} value={option.text}>{option.text}</option>)
                }
            </select>
        </div>
    )

}

export default Select