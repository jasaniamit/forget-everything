import React from 'react'
import Spinner from '../UI/Spinner/Spinner'
import './FontMapItem.scss'

const FontMapItem = ({
    fontName,
    text,
    className,
    handleFontMapClick = undefined,
    canBeSelected = false,
    selectedFontMap,
    isDarkMode = false,
    isLoading = false
}) => {
    const fontStyle = {
        fontFamily: fontName,
    }

    const customClassName = `${className} ${canBeSelected ? selectedFontMap === fontName ? `${className}active` : '' : ''}`
    return (
        <div className={`fontMapItemParent ${isDarkMode ? 'darkModeText' : 'lightModeText'}`} >
            <div className={customClassName} onClick={() => handleFontMapClick && handleFontMapClick(fontName)}>
                {
                    isLoading ? <Spinner
                        isDarkMode={isDarkMode} /> :
                        <p style={fontStyle} >
                            {text}
                        </p>
                }
            </div>
        </div>
    )

}

export default FontMapItem