import React from 'react'
import './SidebarCategory.scss'

const SidebarCategory = ({
    itemConfig,
    isDarkMode,
    handleCategoryClick
}) => {
    const { name = '', subCategory = [] } = itemConfig
    return (
        subCategory.length > 0 &&
        <div className='sidebarCategory'>
            <div className='sidebarCategory_header'>
                <p>{name}</p>
            </div>
            <div className='sidebarCategory_body'>
                {
                    subCategory.map((element, index) =>
                        <span key={index}
                            className={isDarkMode ? 'sidebarCategory_item_dark' : 'sidebarCategory_item_light'}
                            onClick={() => handleCategoryClick(element.name)}>
                            {element.name}
                        </span>)
                }
            </div>
        </div>
    )

}

export default SidebarCategory