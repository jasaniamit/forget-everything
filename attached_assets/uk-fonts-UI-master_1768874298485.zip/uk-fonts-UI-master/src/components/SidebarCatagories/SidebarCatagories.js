import React, { useEffect } from 'react'
import { decodeURL, encodeURL } from '../../common/utils/URL'
import './SidebarCatagories.scss'
import SidebarCategory from './SidebarCategory/SidebarCategory'
import Spinner from '../UI/Spinner/Spinner'

const SidebarCatagories = ({
    isDarkMode,
    pathname,
    search,
    history,
    data = [],
    isLoading,
    getCategoryList
}) => {
    const isCategoryPage = pathname === '/category'

    useEffect(() => {
        getCategoryList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleCategoryClick = (fontName) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            fontCategory: fontName
        })
        history.push(`${isCategoryPage ? '' : '/category'}?${encodedUrl}`)
    }
    return (
        <div className='sidebarCatagories'>
            {
                isLoading ?
                    <Spinner
                        isDarkMode={isDarkMode} /> :
                    <div className='sidebarCatagories_body'>
                        {
                            data.length > 0 ?
                                data.map(item =>
                                    <SidebarCategory
                                        key={item.name}
                                        itemConfig={item}
                                        isDarkMode={isDarkMode}
                                        handleCategoryClick={handleCategoryClick} />) :
                                <div className='noItemFontMsg'>
                                    <p className='secondaryHeadings'>No categories Found</p>
                                </div>
                        }
                    </div>
            }
        </div>
    )

}

export default SidebarCatagories