import React from 'react'
import './NavigationPanel.scss'
import NavigationItem from '../NavigationItem/NavigationItem'
import { withRouter } from 'react-router'
import FullPageNavigation from './../FullPageNavigation/FullPageNavigation'

const NavigationPanel = ({
    history,
    screenWidth
}) => {
    const navigationPanelConfig = [
        { name: 'Home', itemType: 'normal', route: '/home' },
        { name: 'Premium Fonts', itemType: 'normal', route: '/premiumFonts' },
        { name: 'Category', itemType: 'normal', route: '/category' },
        { name: 'Instagram Fonts', itemType: 'normal', route: '/instaFonts' },
        { name: '( ͡° ͜ʖ ͡° )', itemType: 'normal', route: '/idk' },
        { name: 'Designers', itemType: 'normal', route: '/designers' },
        { name: 'Font Pairing', itemType: 'normal', route: '/fontPairing' },
        { name: 'Font Map', itemType: 'normal', route: '/fontMap?alphabet=A' },
        { name: 'Submit a font', itemType: 'normal', route: '/submitAFont' },
        { name: 'Dark Mode Toggle', itemType: 'toggle', route: '' },
    ]

    const navBar = navigationPanelConfig.map((item, index) =>
        <NavigationItem
            key={item.name + index}
            itemConfig={item}
            history={history} />
    )
    return (
        <nav className='navigationPanel'>
            {screenWidth <= 1150 ?
                <FullPageNavigation
                    component={navBar} /> :
                <ul className='navigationList'>
                    {navBar}
                </ul>}
        </nav>
    )
}

export default withRouter(NavigationPanel)