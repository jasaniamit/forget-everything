import React from 'react'
import './Footer.scss'
import LogoFooter from './../../assets/LogoFooter.svg'
import LinkList from '../LinkList/LinkList'
import { ArrowUp } from '../../assets/icons'
import SocialMediaIcons from '../SocialMediaIcons/SocialMediaIcons'

const Footer = () => {

    const socialMediaLinks = {
        facebook: "www.facebook.com",
        instagram: "https://www.instagram.com",
        twitter: "https://www.twitter.com",
        linkedIn: "https://www.linkedin.com"
    }

    const onScrollToTopClickHandler = () => {
        window.scrollTo({ top: 0, behavior: 'smooth' })
    }

    const footerConfig = [
        {
            heading: 'Top Categories',
            links: [{ name: 'Popular Fonts', route: '#' },
            { name: 'Commercial Fonts', route: '#' },
            { name: 'Instagram Fonts', route: '#' },
            { name: 'Cool Fonts', route: '#' },
            { name: 'Cursive Fonts', route: '#' }]
        },
        {
            heading: 'Information',
            links: [{ name: 'About US', route: '#' },
            { name: 'Contact Us', route: '#' },
            { name: 'Support', route: '#' },]
        },
        {
            heading: 'Legal',
            links: [{ name: 'Terms & Conditions', route: '#' },
            { name: 'License Agreement', route: '#' },
            { name: 'Privacy Policy', route: '#' },
            { name: 'Copyright Information', route: '#' },
            { name: 'Cookies Policy', route: '#' },
            { name: 'DCMA', route: '#' }]
        }
    ]
    return (
        <footer className='footer'>
            <div className='footer_inner'>
                <div className='footer_main'>
                    <div className='section'>
                        <div className='footerLogo'>
                            <img src={LogoFooter} alt='logo' className='logo' />
                        </div>
                        <div className='linkSet'>
                            {
                                footerConfig.map((item, index) =>
                                    <div key={index} className='links'>
                                        <div className='linkHeadings'>
                                            <p>
                                                {item.heading}
                                            </p>
                                        </div>
                                        <LinkList
                                            linkListConfig={item.links}
                                            isDarkMode={true} />
                                    </div>
                                )
                            }
                        </div>
                    </div>
                    <div className='clickToTopButton' onClick={onScrollToTopClickHandler}>
                        <ArrowUp />
                        <p className='clickToTopText'>Click to top</p>
                    </div>
                </div>
                <div className='footer_body'>
                    <div className='companyText'>
                        <p>ukfont company</p>
                        <p>copyright © 2020-2021. All rights reserved</p>
                    </div>
                    <SocialMediaIcons
                        socialMediaLinks={socialMediaLinks}
                    />
                </div>
            </div>
        </footer>
    )

}

export default Footer