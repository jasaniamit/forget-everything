import React, { useState } from 'react'
import TextField from './../UI/TextField/TextField'
import Button from './../UI/Button/Button'
import LogoMain from './../../assets/LogoMain.svg'
import './Login.scss'

const Login = ({
    getAuth,
    isLoading = false,
    error = ''
}) => {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    })
    const onChangehandler = (key, value) => {
        setFormData({
            ...formData,
            [key]: value
        })
    }
    const onClickButton = (event) => {
        event.preventDefault();
        getAuth(formData.username, formData.password)
    }

    return (
        <div className='login'>
            <div className='logoContainer'>
                <img src={LogoMain} alt='logo' className='logoImage' />
            </div>
            <p className='mainHeadings'>Login</p>
            <form onSubmit={onClickButton} className='loginForm'>
                <TextField
                    handlerKey={'username'}
                    value={formData.username}
                    placeholder={'Username'}
                    onChangeTextField={onChangehandler}
                    required
                />
                <TextField
                    handlerKey={'password'}
                    value={formData.password}
                    placeholder={'Password'}
                    onChangeTextField={onChangehandler}
                    type={'password'}
                    required
                />
                {error &&
                    <p className='loginError'>{error}</p>
                }
                <Button
                    isDisabled={false}
                    onClickEvent={() => { }}
                    isLoading={isLoading}
                    buttonLong
                    btnType={'submit'}>
                    Login
                </Button>
            </form>
        </div>
    )
}


export default Login