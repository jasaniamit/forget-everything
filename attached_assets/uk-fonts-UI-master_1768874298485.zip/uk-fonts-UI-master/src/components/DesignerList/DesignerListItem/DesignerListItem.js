import React from 'react'
import './DesignerListItem.scss'

const DesignerListItem = ({
    isDarkMode,
    itemConfig,
    handleDesignerClick
}) => {
    const { name = '', fontCount = 0, id = '', profilePhoto = '' } = itemConfig
    return (
        <div className={`designerListItem ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
            onClick={() => handleDesignerClick(id)}>
            <span className='designerinfo'>
                <span className='designerImage'>
                    <img src={profilePhoto} alt='Profile' className='image' />
                </span>
                <span className='designerName'>
                    {name}
                </span>
            </span>
            <span className='designercount'>
                {fontCount} fonts
            </span>
        </div>
    )
}

export default DesignerListItem