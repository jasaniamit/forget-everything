import React, { Fragment } from 'react'
import { defaultTextColor } from '../../common/constants/defaults'
import { decodeURL, encodeURL } from '../../common/utils/URL'
import PaginationComponent from '../PaginationComponent/PaginationComponent'
import Spinner from '../UI/Spinner/Spinner'
import './DesignerList.scss'
import DesignerListItem from './DesignerListItem/DesignerListItem'

const DesignerList = ({
    isDarkMode,
    isLoading = false,
    options = [],
    count = 0,
    search,
    history,
    isPaginationRequired,
    selectedPage = 0
}) => {

    const handleDesignerClick = (id) => {
        const queryObject = decodeURL(search)
        const { isDarkModeEnable = false, selectedFontControls = { color: defaultTextColor[false] } } = queryObject
        const encodedUrl = encodeURL({
            designer: id,
            isDarkModeEnable,
            selectedFontControls
        })
        history.push(`/designers?${encodedUrl}`)
    }

    return (
        <Fragment>
            {isLoading ?
                <div className='designerList'>
                    <Spinner
                        isDarkMode={isDarkMode} />
                </div> :
                <div className='designerList'>
                    {
                        count > 0 ?
                            <Fragment>
                                {
                                    options.map((item, index) => (
                                        <Fragment>
                                            <DesignerListItem
                                                key={item.name}
                                                isDarkMode={isDarkMode}
                                                itemConfig={item}
                                                handleDesignerClick={handleDesignerClick}
                                            />
                                            {(index !== options.length - 1) &&
                                                <hr key={index} className='designerList_seperator' />
                                            }
                                        </Fragment>
                                    ))
                                }
                                {isPaginationRequired &&
                                    <PaginationComponent
                                        search={search}
                                        history={history}
                                        selectedPage={selectedPage}
                                        count={count} />}
                            </Fragment> :
                            <div className='noItemFontMsg'>
                                <p className='secondaryHeadings'>No designer Found</p>
                            </div>
                    }

                </div>}
        </Fragment>
    )
}

export default DesignerList