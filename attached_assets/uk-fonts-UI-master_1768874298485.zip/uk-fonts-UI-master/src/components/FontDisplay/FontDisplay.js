import React, { forwardRef } from 'react'
import './FontDisplay.scss'

const FontDisplay = forwardRef(({
    fontSize = 16,
    text = 'The quick brown fox jumps over the lazy dog',
    textColor = 'black',
    backgroundColor = 'white',
    fontConfig
}, ref) => {
    const { fontFamilyName = '', styles = {} } = fontConfig

    const fontStyle = {
        fontFamily: fontFamilyName,
        fontSize: `${fontSize}px`,
        color: textColor,
        background: backgroundColor,
        transition: 'all 0.2s ease 0s',
        ...styles
    }

    return (
        <div className='fontDisplay' >
            <p style={fontStyle} ref={ref}>
                {text}
            </p>
        </div>
    )
})

export default FontDisplay