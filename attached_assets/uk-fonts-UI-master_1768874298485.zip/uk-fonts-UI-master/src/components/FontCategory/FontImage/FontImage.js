import React, { useEffect, useState } from 'react'
import './FontImage.scss'
import ItemsCarousel from 'react-items-carousel'

const FontImage = ({
    itemImageData = []
}) => {
    const [activeItemIndex, setActiveItemIndex] = useState(0)
    const noOfItems = itemImageData.length
    const noOfCards = 1

    useEffect(() => {
        const tick = () => setActiveItemIndex((activeItemIndex + 1) % (noOfItems - noOfCards + 1))
        const interval = setInterval(() => tick(), 3000)
        return () => clearInterval(interval)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activeItemIndex])

    return (
        <div className='fontImage'>
            <ItemsCarousel
                infiniteLoop
                gutter={12}
                numberOfCards={noOfCards}
                activeItemIndex={activeItemIndex}
                requestToChangeActive={setActiveItemIndex}
                chevronWidth={60}
            >
                {
                    itemImageData.map((item, index) =>
                        <div key={index}>
                            <img src={item} alt={`fontImage${index}`} className='images' />
                        </div>
                    )
                }

            </ItemsCarousel>
        </div>
    )
}

export default FontImage