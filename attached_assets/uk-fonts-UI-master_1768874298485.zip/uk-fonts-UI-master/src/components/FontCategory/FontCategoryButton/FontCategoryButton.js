import React from 'react'
import './FontCategoryButton.scss'

const FontCategoryButton = ({
    itemConfig,
    handleCategoryClick
}) => {
    const { fontName, fontFamilyName } = itemConfig
    return (
        <button
            className={`fontCategoryButton`}
            style={{ fontFamily: fontFamilyName }}
            onClick={() => handleCategoryClick(fontName)}>
            {fontName}
        </button>
    )

}

export default FontCategoryButton