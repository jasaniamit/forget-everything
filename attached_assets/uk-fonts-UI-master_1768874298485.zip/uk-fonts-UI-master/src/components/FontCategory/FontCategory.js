import React from 'react'
import './FontCategory.scss'
import FontCategoryButton from './FontCategoryButton/FontCategoryButton'
import { encodeURL, decodeURL } from '../../common/utils/URL'
import { fontCategoryButtonsMockData } from '../../mockdata/fontCategoryButtonsMockData'

const FontCategory = ({
    isDarkMode,
    options = fontCategoryButtonsMockData,
    pathname,
    search,
    history
}) => {
    const isCategoryPage = pathname === '/category'
    const handleCategoryClick = (fontName) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            fontCategory: fontName
        })
        history.push(`${isCategoryPage ? '' : '/category'}?${encodedUrl}`)
    }

    return (
        <div className='fontCategory'>
            <div className='fontCategory_heading'>
                <p>Browse fonts by category</p>
            </div>
            <div className='fontCategoryButtons'>
                {
                    options.map((item, index) =>
                        <FontCategoryButton
                            key={index}
                            itemConfig={item}
                            handleCategoryClick={handleCategoryClick}
                        />
                    )
                }
            </div>
        </div>
    )
}

export default FontCategory