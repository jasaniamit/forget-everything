import React from 'react'
import './Glyphs.scss'
import { allCharacters } from '../../common/constants/defaults'
import GlyphsItem from './GlyphsItem/GlyphsItem'

const Glyphs = ({
    fontFamilyName,
    isDarkMode = false
}) => {
    return (
        <div className='glyphs'>
            {
                allCharacters.split("").map((item, index) =>
                    <GlyphsItem
                        key={index + item}
                        character={item}
                        fontFamilyName={fontFamilyName}
                        isDarkMode={isDarkMode}
                    />
                )
            }

        </div>
    )
}
export default Glyphs