import React from 'react'
import './GlyphsItem.scss'

const GlyphsItem = ({
    fontFamilyName,
    character,
    isDarkMode = false
}) => {
    const fontStyles = { fontFamily: fontFamilyName }
    return (
        <div className={`glyphsItem ${isDarkMode ? 'darkModeText' : 'lightModeText'}`} style={fontStyles}>
            {character}
        </div>
    )
}
export default GlyphsItem