import React, { useEffect, useState } from 'react'
import './FontCategoryTabs.scss'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs'
import FontsList from '../FontsList/FontsList'
import { generateContentForCategoryStyles } from '../../common/utils/common.utils'
import { isEmpty } from 'ramda'
import Designer from '../Designer/Designer'
import container from '../../common/container/container'
import { getFontList } from '../../common/ukFonts.actions'
import FontControls from '../FontControls/FontControls'
import Spinner from '../UI/Spinner/Spinner'
import { Fragment } from 'react'
import Glyphs from '../Glyphs/Glyphs'

const styleListArr = ['Light', 'Light italic', 'Regular', 'Italic', 'Semibold', 'Semibold Italic', 'Bold']

const FontCategoryTabs = ({
    isDarkMode,
    selectedFontControlOptions,
    selectedFontCategory,
    location: { search },
    history,
    getFontList,
    fontListData,
    isFontListLoading,
    selectedPage,
    fontCategoryData,
    isFontCategoryDataLoading,
}) => {

    const [fontStyleOptions, setFontStyleOptions] = useState([])
    const { name = '', designers = [], about = '', license = '' } = fontCategoryData

    useEffect(() => {
        if (fontCategoryData && !isEmpty(fontCategoryData)) {
            const fontStyleData = generateContentForCategoryStyles(styleListArr, fontCategoryData)
            setFontStyleOptions(fontStyleData)
        }
    }, [selectedFontCategory, fontCategoryData])

    useEffect(() => {
        getFontList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFontControlOptions.isCommercial, selectedPage, selectedFontCategory])


    return (
        <div className='fontCategoryTabs'>
            {
                isFontCategoryDataLoading ? <Spinner /> :
                    <Fragment>
                        <FontControls
                            isDarkMode={isDarkMode}
                            selectedFontControlOptions={selectedFontControlOptions}
                            search={search}
                            history={history}
                            getFontList={getFontList}
                        />
                        <Tabs>
                            <TabList>
                                <Tab>Style</Tab>
                                <Tab>Glyphs</Tab>
                                <Tab>About</Tab>
                                <Tab>License</Tab>
                                <Tab>Related Fonts</Tab>
                            </TabList>

                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>Style</p>
                                </div>
                                <FontsList
                                    isDarkMode={isDarkMode}
                                    options={fontStyleOptions}
                                    count={fontStyleOptions.length}
                                    selectedFontControlOptions={selectedFontControlOptions}
                                    linksAreClickable={false} />
                            </TabPanel>
                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>Glyphs</p>
                                </div>
                                <Glyphs
                                    fontFamilyName={'Inter'}
                                    isDarkMode={isDarkMode}
                                />
                            </TabPanel>
                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>About</p>
                                </div>
                                <div>
                                    <p>{about}</p>
                                </div>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>Designer</p>
                                </div>
                                <div>
                                    {
                                        designers.map((designer, index) =>
                                            <Designer
                                                key={index}
                                                isDarkMode={isDarkMode}
                                                data={designer} />)
                                    }
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>License</p>
                                </div>
                                <div>
                                    <p>{license}</p>
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>{fontListData['count']} Related Fonts found for {name}</p>
                                </div>
                                <FontsList
                                    isDarkMode={isDarkMode}
                                    isLoading={isFontListLoading}
                                    options={fontListData['data']}
                                    count={fontListData['count']}
                                    selectedFontControlOptions={selectedFontControlOptions}
                                    search={search}
                                    history={history}
                                    isPaginationRequired={true}
                                    selectedPage={selectedPage}
                                />
                            </TabPanel>
                        </Tabs>
                    </Fragment>
            }
        </div>
    )
}

const mapStateToProps = (state) => {
    const { selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontCategory,
        selectedProperties,
        selectedPage
    } = state.selectedOptionsReducer

    const {
        fontListData,
        isFontListLoading,
        fontCategoryData,
        isFontCategoryDataLoading,
    } = state.incomingDataReducer
    return {
        selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontCategory,
        fontListData,
        isFontListLoading,
        selectedProperties,
        selectedPage,
        fontCategoryData,
        isFontCategoryDataLoading,
    }
}

const mapDispatchToProps = {
    getFontList
}

export default container(FontCategoryTabs, mapStateToProps, mapDispatchToProps)