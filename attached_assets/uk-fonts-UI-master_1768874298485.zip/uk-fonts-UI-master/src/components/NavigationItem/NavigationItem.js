import React from 'react'
import Toggle from '../UI/Toggle/Toggle'
import './NavigationItem.scss'
import container from '../../common/container/container'
import { setDarkMode, setSelectedFontOptions } from '../../common/actions/actionsDispatcher'
import { defaultTextColor } from '../../common/constants/defaults'
import { encodeURL, decodeURL } from '../../common/utils/URL'

const NavigationItem = ({
    itemConfig,
    history,
    location: { search },
    isDarkMode,
}) => {

    const handleButtonClick = (route) => {
        const queryObject = decodeURL(search)
        const { isDarkModeEnable = false, selectedFontControls = { color: defaultTextColor[false] } } = queryObject
        const encodedUrl = encodeURL({
            isDarkModeEnable,
            selectedFontControls
        })
        history.push(`${route}${route.includes('?') ? '&' : '?'}${encodedUrl}`)
    }

    const toggleChangeHandler = (value) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            isDarkModeEnable: value,
            selectedFontControls: { color: defaultTextColor[value] }
        })
        history.push(`?${encodedUrl}`)
    }

    let itemElement = null
    switch (itemConfig.itemType) {
        case 'normal':
            itemElement =
                <li className='navigationItem' onClick={() => handleButtonClick(itemConfig.route)}>
                    <button className='btn navigationItem_button'>{itemConfig.name}</button>
                </li>
            break
        case 'toggle':
            itemElement = <div className='navigationItem'>
                <Toggle
                    value={isDarkMode}
                    onChangeHandler={toggleChangeHandler}
                /></div>
            break
        default:
            break
    }


    return itemElement
}

const mapStateToProps = (state) => {
    const { isDarkMode
    } = state.selectedOptionsReducer
    return { isDarkMode }
}

const mapDispatchToProps = {
    setDarkMode,
    setSelectedFontOptions
}

export default container(NavigationItem, mapStateToProps, mapDispatchToProps)