import React, { useEffect, useState } from 'react'
import './SocialMediaIcons.scss'
import { getIconItems } from '../../common/utils/common.utils'

const SocialMediaIcons = ({
    socialMediaLinks = {},
    color = '#ffffff'
}) => {
    const [iconsInfo, setIconInfo] = useState([])

    useEffect(() => {
        const iconItems = getIconItems(socialMediaLinks, color)
        setIconInfo(iconItems)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [socialMediaLinks])

    const onSocialLinkClickHandler = (link) => {
        window.open(link, '_blank')
    }
    return (
        <div className="socialLinks">
            {
                iconsInfo.map((item, index) =>
                    <span className='Icons'
                        style={{ fill: color }}
                        key={index}
                        onClick={() => onSocialLinkClickHandler(item.link)} >
                        {item.comp}
                    </span>
                )
            }
        </div>
    )

}

export default SocialMediaIcons