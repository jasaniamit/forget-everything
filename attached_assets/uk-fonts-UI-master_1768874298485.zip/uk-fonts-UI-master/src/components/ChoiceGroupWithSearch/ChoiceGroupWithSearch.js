import React, { useEffect, useState } from 'react'
import TextField from './../UI/TextField/TextField'
import { ChoiceGroup } from '@fluentui/react/lib/ChoiceGroup'
import './ChoiceGroupWithSearch.scss'
import Spinner from '../UI/Spinner/Spinner'

const ChoiceGroupWithSearch = ({
    options = [],
    isDarkMode = false,
    label = '',
    defaultSelectedKey = '',
    onChoiceGroupChange,
    isLoading = false,
}) => {
    const [searchText, setSearchText] = useState('')
    const [localOptions, setLocalOptions] = useState(options)
    const isSearchVisible = options.length > 5

    const onChangehandler = (key, value) => {
        if (key === 'search') {
            setSearchText(value)
        } else if (key === label) {
            onChoiceGroupChange(value)
        }
    }

    useEffect(() => {
        setLocalOptions(options.filter(item => item.text.includes(searchText)))
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchText])

    useEffect(() => {
        setLocalOptions(options)
    }, [options])

    return isLoading ?
        <div className='choiceGroupWithSearchSpinner'>
            <Spinner />
        </div> :
        <div className='choiceGroupWithSearch'>
            <div className='searchBar'>
                {
                    isSearchVisible && <TextField
                        isDarkMode={isDarkMode}
                        handlerKey={'search'}
                        value={searchText}
                        placeholder={`Search ${label}`}
                        labelText={''}
                        onChangeTextField={onChangehandler}
                    />
                }
            </div>
            <div className='choiceGroup'>
                <ChoiceGroup
                    defaultSelectedKey={defaultSelectedKey}
                    options={localOptions}
                    onChange={(event, value) => onChangehandler(label, value.key)}
                    label={label} />
            </div>
        </div>

}


export default ChoiceGroupWithSearch