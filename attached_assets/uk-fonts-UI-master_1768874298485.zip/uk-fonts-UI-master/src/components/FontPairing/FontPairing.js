import React from 'react'
import './FontPairing.scss'
import { Setting } from '../../assets/icons'
const FontPairing = ({
    isDarkMode,
    search,
    history,
    selectedFontPairing,
    handleSelectComponent
}) => {
    const { heading = '', subHeading = '', body = '' } = selectedFontPairing

    const handleKeyDown = (e) => {
        e.target.style.height = 'inherit';
        e.target.style.height = `${e.target.scrollHeight}px`;
    }


    return (
        <div className='fontPairing'>
            <div className='heading'>
                <span className='icon' onClick={() => handleSelectComponent('heading')}>
                    <Setting className={`settingIcon ${isDarkMode ? 'darkModeSvg' : 'lightModeSvg'}`} />
                </span>
                <span className='textAreaField' >
                    <textarea className='h1'
                        style={{ fontFamily: heading }}
                        defaultValue={`Font pairing made easy! Type your main heading here!`}
                        onChange={handleKeyDown}
                    />
                </span>

            </div>
            <div className='subHeading'>
                <span className='icon' onClick={() => handleSelectComponent('subHeading')} >
                    <Setting className={`settingIcon ${isDarkMode ? 'darkModeSvg' : 'lightModeSvg'}`} />
                </span>
                <span className='textAreaField'>
                    <textarea className={`h2 ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
                        style={{ fontFamily: subHeading }}
                        defaultValue={`Sub heading area - click left icon to change fonts`}
                        onChange={handleKeyDown} />
                </span>
            </div>
            <div className='body'>
                <span className='icon' onClick={() => handleSelectComponent('body')}>
                    <Setting className={`settingIcon ${isDarkMode ? 'darkModeSvg' : 'lightModeSvg'}`} />
                </span>
                <span className='textAreaField'>
                    <textarea className={`content ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
                        style={{ fontFamily: body }}
                        defaultValue={`Click (Generate) to create a new font pairing,(Lock) to lock fonts that you want to keep, and (Edit) to choose a font manually. The text is editable, try replacing it with your company name or other copy. The goal of font pairing is to select fonts that share an overarching theme yet have a pleasing contrast. Which fonts work together is largely a matter of intuition, but we approach this problem with a neural net. See Github for more technical details.`}
                        onChange={handleKeyDown}
                    />
                </span>
            </div>
        </div>
    )
}


export default FontPairing