import React from 'react'
import './CategoryListItem.scss'

const CategoryListItem = ({
    isDarkMode,
    itemConfig,
    handleCategoryClick
}) => {
    const { name = '', fontCount = 0 } = itemConfig
    return (
        <div className={`categoryListItem ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}
            onClick={() => handleCategoryClick(name)}>
            <span className='categoryName'>
                {name}
            </span>
            <span className='categorycount'>
                {fontCount} fonts
            </span>
        </div>
    )
}

export default CategoryListItem