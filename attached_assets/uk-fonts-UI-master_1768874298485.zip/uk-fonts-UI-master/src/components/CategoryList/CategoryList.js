import React, { Fragment } from 'react'
import { defaultTextColor } from '../../common/constants/defaults'
import { decodeURL, encodeURL } from '../../common/utils/URL'
import PaginationComponent from '../PaginationComponent/PaginationComponent'
import Spinner from '../UI/Spinner/Spinner'
import './CategoryList.scss'
import CategoryListItem from './CategoryListItem/CategoryListItem'

const CategoryList = ({
    isDarkMode,
    isLoading = false,
    options = [],
    count = 0,
    search,
    history,
    isPaginationRequired,
    selectedPage = 0
}) => {

    const handleCategoryClick = (fontName) => {
        const queryObject = decodeURL(search)
        const { isDarkModeEnable = false, selectedFontControls = { color: defaultTextColor[false] } } = queryObject
        const encodedUrl = encodeURL({
            fontCategory: fontName,
            isDarkModeEnable,
            selectedFontControls
        })
        history.push(`/category?${encodedUrl}`)
    }

    return (
        <Fragment>
            {isLoading ?
                <div className='categoryList'>
                    <Spinner
                        isDarkMode={isDarkMode} />
                </div> :
                <div className='categoryList'>
                    {
                        count > 0 ?
                            <Fragment>
                                {
                                    options.map((item, index) => (
                                        <Fragment>
                                            <CategoryListItem
                                                key={item.name}
                                                isDarkMode={isDarkMode}
                                                itemConfig={item}
                                                handleCategoryClick={handleCategoryClick}
                                            />
                                            {(index !== options.length - 1) &&
                                                <hr key={index} className='categoryList_seperator' />
                                            }
                                        </Fragment>
                                    ))
                                }
                                {isPaginationRequired &&
                                    <PaginationComponent
                                        search={search}
                                        history={history}
                                        selectedPage={selectedPage}
                                        count={count} />}
                            </Fragment> :
                            <div className='noItemFontMsg'>
                                <p className='secondaryHeadings'>No Categories Found</p>
                            </div>
                    }

                </div>}
        </Fragment>
    )
}

export default CategoryList