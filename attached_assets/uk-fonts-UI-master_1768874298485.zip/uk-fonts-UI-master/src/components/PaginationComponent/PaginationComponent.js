import React from 'react'
import './PaginationComponent.scss'
import ReactPaginate from 'react-paginate'
import { encodeURL, decodeURL } from '../../common/utils/URL'


const PaginationComponent = ({
    search,
    history,
    selectedPage = 0,
    count
}) => {
    const handlePageChange = (pageNumber) => {
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            page: pageNumber.selected
        })
        history.push(`?${encodedUrl}`)
    }
    const maxPage = Math.ceil(count / 14) || 1
    return (
        <div className='customPagination'>
            <ReactPaginate
                forcePage={selectedPage}
                previousLabel={''}
                nextLabel={''}
                breakLabel={'...'}
                breakClassName={'break-me'}
                pageCount={maxPage}
                marginPagesDisplayed={2}
                pageRangeDisplayed={5}
                onPageChange={handlePageChange}
                containerClassName={'pagination'}
                activeClassName={'active'}
            />
        </div>
    )
}
export default PaginationComponent