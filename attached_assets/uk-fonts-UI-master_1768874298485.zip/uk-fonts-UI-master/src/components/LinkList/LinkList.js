import React from 'react'
import './LinkList.scss'
import { withRouter } from 'react-router'
import { decodeURL, encodeURL } from '../../common/utils/URL'
import { defaultTextColor } from '../../common/constants/defaults'

const linksFlexPattern = {
    row: 'linksRow',
    column: 'linksColumn'
}

const LinkList = ({
    linkListConfig,
    flexPattern = 'column',
    customClass = '',
    areClickble = true,
    isDarkMode = false,
    history,
    location: { search }
}) => {

    const onLinkClickHandler = (route) => {
        const queryObject = decodeURL(search)
        const { isDarkModeEnable = false, selectedFontControls = { color: defaultTextColor[false] } } = queryObject
        const encodedUrl = encodeURL({
            isDarkModeEnable,
            selectedFontControls
        })
        history.push(`${route}&${encodedUrl}`)
    }

    return (
        <div className={`linkList ${linksFlexPattern[flexPattern]} ${customClass} ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}>
            {
                linkListConfig.map((item, index) => areClickble && item.route !== '#' ?
                    <p key={index} onClick={() => onLinkClickHandler(item.route)} className='links'>
                        {item.name}
                    </p> :
                    <p key={index} className='text'>
                        {item.name}
                    </p>)
            }
        </div>
    )

}

export default withRouter(LinkList)