import React from 'react'
import './Counts.scss'

const Counts = ({
    isDarkMode = false,
    selectedCount,
    count = 0,
    categoryName = '',
    onCountClick
}) => {
    return (
        <div className={`countsContainer  ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}>
            <div className={`counts  ${selectedCount === categoryName ? 'activeCount' : ''}`}
                onClick={() => onCountClick(categoryName)}
            >
                {`${count} ${categoryName}`}
            </div>
        </div>
    )
}
export default Counts