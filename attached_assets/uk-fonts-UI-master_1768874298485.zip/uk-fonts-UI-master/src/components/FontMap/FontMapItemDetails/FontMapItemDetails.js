import React from 'react'
import FontMapItem from '../../FontMapItem/FontMapItem'
import './FontMapItemDetails.scss'

const FontMapItemDetails = ({
    itemConfig,
    selectedAlphabet,
    setIsDetailsOpen,
}) => {
    const { fontFamilyName, similarFonts } = itemConfig
    return (
        <div className='fontMapItemDetails'>
            <div className='fontIcon'>
                <FontMapItem
                    fontName={fontFamilyName}
                    text={selectedAlphabet}
                    className={'fontMapItemAsIcon'}
                />
            </div>
            <div className='fontDetails'>
                <div className='fontDetails_header'>
                    <span className='fontDetails_header_heading'>
                        <p className='heading'>Font Name: {fontFamilyName}</p>
                        <p className='info'>Similar Fonts</p>
                        <hr className='seperator' />
                    </span>
                    <span className='fontDetails_header_close' onClick={setIsDetailsOpen}>
                        <i className="material-icons">&#xe5cd;</i>
                    </span>
                </div>
                <div className='fontDetails_body'>
                    {
                        similarFonts.map((item, index) => (
                            <div key={index}
                                className='fontDetails_body_inner'>
                                <FontMapItem
                                    fontName={item.fontFamilyName}
                                    text={selectedAlphabet}
                                    className={'fontMapItemAsSmallIcon'}
                                />
                                <span className='fontInfo'>
                                    <p className='heading'>{item.fontFamilyName}</p>
                                    <p className='info'>{item.type}</p>
                                </span>
                            </div>
                        ))
                    }
                </div>
            </div>

        </div>
    )

}

export default FontMapItemDetails