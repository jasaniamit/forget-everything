import React, { useEffect, useState } from 'react'
import { fontLoader } from '../../../common/utils/common.utils'
import FontMapItem from '../../FontMapItem/FontMapItem'
import FontMapItemDetails from '../FontMapItemDetails/FontMapItemDetails'
import './FontMapItems.scss'


const FontMapItems = ({
    itemConfig,
    selectedAlphabet,
    selectedFontMap = '',
    handleFontMapClick,
    isDetailsOpen,
    setIsDetailsOpen,
    isDarkMode
}) => {
    const [isLoading, setIsloading] = useState(false)

    useEffect(() => {
        if (selectedFontMap === itemConfig.fontFamilyName) {
            setIsloading(true)
            fontLoader(itemConfig.similarFonts, setIsloading, false)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFontMap])

    return (
        <div className='fontMapItems'>
            <FontMapItem
                fontName={itemConfig.fontFamilyName}
                text={selectedAlphabet}
                selectedFontMap={selectedFontMap}
                className={'fontMapItem'}
                handleFontMapClick={handleFontMapClick}
                canBeSelected={true}
                isDarkMode={isDarkMode}
                isLoading={isLoading}
            />
            <div className='fontOptions'>
                {selectedFontMap === itemConfig.fontFamilyName && isDetailsOpen && !isLoading &&
                    <FontMapItemDetails
                        itemConfig={itemConfig}
                        selectedAlphabet={selectedAlphabet}
                        setIsDetailsOpen={setIsDetailsOpen}
                    />}
            </div>

        </div>
    )

}

export default FontMapItems