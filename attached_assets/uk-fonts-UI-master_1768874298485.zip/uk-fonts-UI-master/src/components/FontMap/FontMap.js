import React, { useState } from 'react'
import './FontMap.scss'
import FontMapItem from './FontMapItems/FontMapItems'
import { encodeURL, decodeURL } from '../../common/utils/URL'

const FontMap = ({
    isDarkMode,
    selectedAlphabet,
    selectedFontMap,
    history,
    search,
    options = []
}) => {
    const [isOpen, setIsOpen] = useState(true)
    const handleFontMapClick = (fontName) => {
        setIsOpen(true)
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            fontMap: fontName
        })
        history.push(`?${encodedUrl}`)
    }

    const handleFontMapDetailsClose = () => {
        setIsOpen(false)
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            fontMap: ''
        })
        history.push(`?${encodedUrl}`)
    }

    return (
        <div className='fontMap'>
            {options.map((item, index) =>
                <FontMapItem
                    isDarkMode={isDarkMode}
                    key={index}
                    itemConfig={item}
                    selectedAlphabet={selectedAlphabet}
                    selectedFontMap={selectedFontMap}
                    history={history}
                    search={search}
                    handleFontMapClick={handleFontMapClick}
                    isDetailsOpen={isOpen}
                    setIsDetailsOpen={handleFontMapDetailsClose}
                />
            )}
        </div>
    )

}

export default FontMap