import React, { useEffect, useRef, useState } from 'react'
import './FullPageNavigation.scss'
import LogoMain from './../../assets/LogoMain.svg'

const FullPageNavigation = ({
    component
}) => {
    const [isVisible, setIsVisible] = useState(false)
    const ref = useRef()
    useEffect(() => {
        const checkIfClickedOutside = e => {
            if (isVisible && ref.current && !ref.current.contains(e.target)) {
                setIsVisible(false)
            }
        }
        document.addEventListener("mousedown", checkIfClickedOutside)
        return () => {
            document.removeEventListener("mousedown", checkIfClickedOutside)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isVisible])

    return (
        <div className="navigation">
            <div className='navbar_logo'>
                <img src={LogoMain} alt='logo' className='logoImage' />
            </div>

            <input type="checkbox"
                className="navigation__checkbox"
                id="navi-toggle"
                value={isVisible}
                onChange={(event) => setIsVisible(event.target.checked)} />

            <label htmlFor="navi-toggle" className="navigation__button">
                <div className='drawerToggle'>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </label>
            {
                isVisible && <nav className="navigation__nav" ref={ref}>
                    <ul className="navlist">
                        {component}
                    </ul>
                </nav>
            }

        </div>
    )

}

export default FullPageNavigation