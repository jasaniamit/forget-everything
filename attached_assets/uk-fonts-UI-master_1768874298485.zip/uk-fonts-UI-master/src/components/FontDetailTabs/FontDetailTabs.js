import React, { useEffect, useState } from 'react'
import './FontDetailTabs.scss'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs'
import FontsList from '../FontsList/FontsList'
import { generateContentForFontStyles } from '../../common/utils/common.utils'
import Designer from '../Designer/Designer'
import container from '../../common/container/container'
import { getFontList } from '../../common/ukFonts.actions'
import FontControls from '../FontControls/FontControls'
import Spinner from '../UI/Spinner/Spinner'
import { Fragment } from 'react'
import Glyphs from '../Glyphs/Glyphs'

const styleListArr = ['Light', 'Light italic', 'Regular', 'Italic', 'Semibold', 'Semibold Italic', 'Bold']

const FontDetailTabs = ({
    isDarkMode,
    selectedFontControlOptions,
    location: { search },
    history,
    getFontList,
    fontListData,
    isFontListLoading,
    selectedPage,
    selectedFont,
    fontDetails = {},
    isFontDetailsLoading = false,
}) => {

    const [fontStyleOptions, setFontStyleOptions] = useState([])
    const { name = '', designers = [], about = '', license = '' } = fontDetails

    useEffect(() => {
        const fontStyleData = generateContentForFontStyles(styleListArr, selectedFont)
        setFontStyleOptions(fontStyleData)
    }, [selectedFont])

    useEffect(() => {
        //getFontList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFontControlOptions.isCommercial, selectedPage, selectedFont])


    return (
        <div className='fontDetailTabs'>
            {
                isFontDetailsLoading ? <Spinner /> :
                    <Fragment>
                        <FontControls
                            isDarkMode={isDarkMode}
                            selectedFontControlOptions={selectedFontControlOptions}
                            search={search}
                            history={history}
                            getFontList={() => { }}
                        />
                        <Tabs>
                            <TabList>
                                <Tab>Style</Tab>
                                <Tab>Glyphs</Tab>
                                {
                                    about && designers.length > 0 && <Tab>About</Tab>
                                }
                                {
                                    license && <Tab>License</Tab>
                                }
                                <Tab>Related Fonts</Tab>
                            </TabList>

                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>Style</p>
                                </div>
                                <FontsList
                                    isDarkMode={isDarkMode}
                                    options={fontStyleOptions}
                                    count={fontStyleOptions.length}
                                    selectedFontControlOptions={selectedFontControlOptions}
                                    linksAreClickable={false} />
                            </TabPanel>
                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>Glyphs</p>
                                </div>
                                <Glyphs
                                    fontFamilyName={selectedFont}
                                    isDarkMode={isDarkMode} />
                            </TabPanel>
                            {
                                about && designers.length > 0 &&
                                <TabPanel>
                                    <div className='tabHeadings'>
                                        <p className='secondaryHeadings'>About</p>
                                    </div>
                                    <div>
                                        {
                                            about && <p>{about}</p>
                                        }
                                    </div>
                                    <div className='tabHeadings'>
                                        <p className='secondaryHeadings'>Designer</p>
                                    </div>
                                    <div>
                                        {
                                            designers.map((designer, index) =>
                                                <Designer
                                                    key={index}
                                                    isDarkMode={isDarkMode}
                                                    data={designer} />)
                                        }
                                    </div>
                                </TabPanel>
                            }
                            {
                                license &&
                                <TabPanel>
                                    <div className='tabHeadings'>
                                        <p className='secondaryHeadings'>License</p>
                                    </div>
                                    <div>
                                        <p>{license}</p>
                                    </div>
                                </TabPanel>
                            }
                            <TabPanel>
                                <div className='tabHeadings'>
                                    <p className='secondaryHeadings'>{fontListData['count']} Related Fonts found for {name}</p>
                                </div>
                                <FontsList
                                    isDarkMode={isDarkMode}
                                    isLoading={isFontListLoading}
                                    options={fontListData['data']}
                                    count={fontListData['count']}
                                    selectedFontControlOptions={selectedFontControlOptions}
                                    search={search}
                                    history={history}
                                    isPaginationRequired={true}
                                    selectedPage={selectedPage}
                                />
                            </TabPanel>
                        </Tabs>
                    </Fragment>
            }
        </div>
    )
}

const mapStateToProps = (state) => {
    const {
        selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedPage,
        selectedFont
    } = state.selectedOptionsReducer

    const {
        fontListData,
        isFontListLoading,
        fontDetails,
        isFontDetailsLoading,
    } = state.incomingDataReducer
    return {
        selectedFontControlOptions,
        isDarkMode,
        searchText,
        fontListData,
        isFontListLoading,
        selectedPage,
        selectedFont,
        fontDetails,
        isFontDetailsLoading,
    }
}

const mapDispatchToProps = {
    getFontList
}

export default container(FontDetailTabs, mapStateToProps, mapDispatchToProps)