import React from 'react'
import './FontProperties.scss'
import Property from './Property/Property'
import RefreshIcon from '../UI/RefreshIcon/RefreshIcon'
import { glyphsPropertyConfig } from '../../common/constants/defaults'
import { encodeURL, decodeURL } from '../../common/utils/URL'
import { FontPropertiesMockData } from '../../mockdata/FontPropertiesMockData'

const FontProperties = ({
    isDarkMode,
    isRefreshRequired = false,
    search,
    history,
    selectedProperties = {}
}) => {

    const handleOnClick = (key, value) => {
        const queryObject = decodeURL(search)
        const properties = { ...queryObject.properties } || {}
        if (properties.hasOwnProperty(key) && properties[key] === value) {
            delete properties[key]
        } else {
            properties[key] = value
        }
        const encodedUrl = encodeURL({
            ...queryObject,
            properties
        })
        history.push(`?${encodedUrl}`)
    }

    const onClickReset = (key, value) => {
        const queryObject = decodeURL(search)
        const properties = {}
        const encodedUrl = encodeURL({
            ...queryObject,
            properties
        })
        history.push(`?${encodedUrl}`)
    }


    return (
        <div className='fontProperties'>
            <div className='properties_header'>
                <p>Properties</p>
                {isRefreshRequired &&
                    <RefreshIcon
                        onClickReset={onClickReset} />}
            </div>
            <div className='properties_body'>
                {
                    FontPropertiesMockData.map((item, index) =>
                        <Property
                            key={item.name + index}
                            propertyConfig={glyphsPropertyConfig}
                            name={item.name}
                            itemKey={item.key}
                            isDarkMode={isDarkMode}
                            handleClick={handleOnClick}
                            selectedProperties={selectedProperties}
                        />
                    )
                }
            </div>
        </div>
    )

}

export default FontProperties