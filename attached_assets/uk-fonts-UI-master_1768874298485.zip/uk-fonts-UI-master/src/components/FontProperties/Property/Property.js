import React from 'react'
import './Property.scss'

const Property = ({
    propertyConfig,
    name = '',
    itemKey = '',
    isDarkMode,
    handleClick,
    selectedProperties = {}
}) => {
    return (
        <div className={`${isDarkMode ? 'property_dark' : 'property_light'} ${name !== '' ? 'propertyMargin' : ''}`}>
            <div className='propertyIcons'>
                {
                    propertyConfig.map((item, index) => {
                        const isActive = selectedProperties.hasOwnProperty(itemKey) && selectedProperties[itemKey] === index + 1
                        return <span
                            key={index}
                            className={`propertyIcon ${item.weight} ${index % 2 !== 0 ? 'elementCenter' : ''} ${isActive ? 'active' : ''}`}
                            onClick={() => handleClick(itemKey, item.keyNumber)}>
                            {item.letter}
                        </span>
                    }
                    )
                }
            </div>
            {name !== '' &&
                < p className='propertyText'>{name}</p>
            }
        </div >
    )
}

export default Property