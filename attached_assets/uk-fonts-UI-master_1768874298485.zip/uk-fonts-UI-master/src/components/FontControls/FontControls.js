import React from 'react'
import Checkbox from '../UI/Checkbox/Checkbox'
import ColorPicker from '../UI/ColorPicker/ColorPicker'
import RefreshIcon from '../UI/RefreshIcon/RefreshIcon'
import Slider from '../UI/Slider/Slider'
import './FontControls.scss'
import { encodeURL, decodeURL } from '../../common/utils/URL'
import { clone } from 'ramda'
import TextField from '../UI/TextField/TextField'
import { defaultSelectedFontControls } from '../../common/constants/defaults'

const FontControls = ({
    selectedFontControlOptions,
    isDarkMode,
    search,
    history,
}) => {
    const { text, fontSize, color, isCommercial } = selectedFontControlOptions

    const handleFontControlsChange = (group, value) => {
        const selectedFontControls = clone(selectedFontControlOptions)
        selectedFontControls[group] = value
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            selectedFontControls
        })
        history.push(`?${encodedUrl}`)
    }

    const handleClickReset = () => {
        const selectedFontControls = defaultSelectedFontControls
        const queryObject = decodeURL(search)
        const encodedUrl = encodeURL({
            ...queryObject,
            selectedFontControls
        })
        history.push(`?${encodedUrl}`)
    }

    return (
        <div className='fontControls'>
            <TextField
                handlerKey={'text'}
                value={text}
                placeholder={'Write something here'}
                labelText='Sample text'
                onChangeTextField={handleFontControlsChange}
            />
            <Slider
                handlerKey={'fontSize'}
                min={16}
                max={150}
                value={fontSize}
                sliderOnChangeHandler={handleFontControlsChange}
                isDarkMode={isDarkMode} />
            <ColorPicker
                handlerKey={'color'}
                foregroundValue={color.foregroundColor}
                backgroundValue={color.backgroundColor}
                onColorPickerChangeHandler={handleFontControlsChange} />
            <Checkbox
                handlerKey={'isCommercial'}
                label={'Commercial Use'}
                checked={isCommercial}
                isDarkMode={isDarkMode}
                onCheckBoxChangeHandler={handleFontControlsChange}
            />
            <RefreshIcon
                haveBackground={false}
                onClickReset={handleClickReset} />
        </div>
    )

}

export default FontControls