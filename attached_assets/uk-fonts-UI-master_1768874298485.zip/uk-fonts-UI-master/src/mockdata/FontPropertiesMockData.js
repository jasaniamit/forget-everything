export const FontPropertiesMockData = [
    { name: 'Weight', key: 'weight' },
    { name: 'Width', key: 'width' },
    { name: 'Case', key: 'standardOrCaps' },
    { name: 'Default Figure', key: 'figure' },
    { name: 'X-height', key: 'height' },
    { name: 'Contrast', key: 'contrast' },
]