export const fontCategoryButtonsMockData = [
    {
        fontName: 'Sans Serif', fontFamilyName: 'sans-serif'
    },
    {
        fontName: 'Slab Serif', fontFamilyName: 'Elephant'
    },
    {
        fontName: 'Serif', fontFamilyName: 'News701 BT'
    },
    {
        fontName: 'Display', fontFamilyName: 'sans-serif'
    },
    {
        fontName: 'Handwritten', fontFamilyName: 'Tempus Sans ITC'
    },
    {
        fontName: 'Script', fontFamilyName: 'Brush Script Std'
    },
]