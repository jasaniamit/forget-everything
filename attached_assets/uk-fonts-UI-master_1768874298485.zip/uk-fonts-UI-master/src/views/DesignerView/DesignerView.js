import React, { useEffect } from 'react'
import './DesignerView.scss'
import SidebarLeft from '../../components/Sidebar/SidebarLeft/SidebarLeft'
import SidebarRight from '../../components/Sidebar/SidebarRight/SidebarRight'
import SearchBar from '../../components/UI/SearchBar/SearchBar'
import FontCategory from '../../components/FontCategory/FontCategory'
import FontControls from '../../components/FontControls/FontControls'
import container from '../../common/container/container'
import FontsList from '../../components/FontsList/FontsList'
import Designer from '../../components/Designer/Designer'
import { getDesignerInfo, getFontList, getSearchDesignerList } from '../../common/ukFonts.actions'
import Spinner from '../../components/UI/Spinner/Spinner'
import { Fragment } from 'react'
import DesignerList from '../../components/DesignerList/DesignerList'

const DesignerView = ({
    selectedFontControlOptions,
    isDarkMode,
    location: { search, pathname },
    history,
    searchText,
    selectedFontCategory,
    selectedDesigner,
    getDesignerInfo,
    designerData,
    isDesignerDataLoading,
    fontListData,
    isFontListLoading,
    selectedPage,
    getFontList,
    searchDesignerList,
    isSearchDesignerListLoading,
    getSearchDesignerList
}) => {

    const designerInfo = () => isDesignerDataLoading ? <Spinner /> :
        <Fragment>
            <FontCategory
                isDarkMode={isDarkMode}
                search={search}
                pathname={pathname}
                history={history}
                selectedFontCategory={selectedFontCategory} />
            <Designer
                isDarkMode={isDarkMode}
                data={designerData}
            />
            <FontControls
                isDarkMode={isDarkMode}
                selectedFontControlOptions={selectedFontControlOptions}
                search={search}
                history={history}
            />
            <FontsList
                isDarkMode={isDarkMode}
                isLoading={isFontListLoading}
                options={fontListData['data']}
                count={fontListData['count']}
                selectedFontControlOptions={selectedFontControlOptions}
                search={search}
                history={history}
                isPaginationRequired={true}
                selectedPage={selectedPage} />
        </Fragment>


    const designerList = () => <DesignerList
        isDarkMode={isDarkMode}
        isLoading={isSearchDesignerListLoading}
        options={searchDesignerList['data']}
        count={searchDesignerList['count']}
        search={search}
        history={history}
        isPaginationRequired={true}
        selectedPage={selectedPage}
    />

    useEffect(() => {
        if (selectedDesigner) {
            getDesignerInfo()
            getFontList()

        } else {
            getSearchDesignerList()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedDesigner])

    return (
        <div className='designerView pageLoad'>
            <div className='designerView_inner'>
                <div className='sidebarLeftContainer'>
                    <SidebarLeft
                        componentsRequired={['linkList']}
                        isRefreshRequired={true} />
                </div>
                <div className='mainBody'>
                    <SearchBar
                        placeholder='Search Fonts, Categories, Designers...' />
                    {
                        selectedDesigner ? designerInfo() : designerList()
                    }
                </div>
                <div className='sidebarRightContainer'>
                    <SidebarRight
                        componentsRequired={[]} />
                </div>
            </div>

        </div >
    )
}

const mapStateToProps = (state) => {
    const { selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontCategory,
        selectedDesigner,
        selectedPage
    } = state.selectedOptionsReducer

    const {
        designerData,
        isDesignerDataLoading,
        fontListData,
        isFontListLoading,
        searchDesignerList,
        isSearchDesignerListLoading
    } = state.incomingDataReducer
    return {
        selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontCategory,
        designerData,
        isDesignerDataLoading,
        selectedDesigner,
        fontListData,
        isFontListLoading,
        selectedPage,
        searchDesignerList,
        isSearchDesignerListLoading
    }
}

const mapDispatchToProps = {
    getDesignerInfo,
    getFontList,
    getSearchDesignerList
}

export default container(DesignerView, mapStateToProps, mapDispatchToProps)