import React, { useEffect, useRef, useState } from 'react'
import './FontPairingView.scss'
import SidebarLeft from '../../components/Sidebar/SidebarLeft/SidebarLeft'
import container from '../../common/container/container'
import { setSelectedFontOptions } from '../../common/actions/actionsDispatcher'
import FontPairing from '../../components/FontPairing/FontPairing'
import { encodeURL, decodeURL } from '../../common/utils/URL'
import FontMapItem from '../../components/FontMapItem/FontMapItem'
import { getFontMap } from '../../common/ukFonts.actions'
import Spinner from '../../components/UI/Spinner/Spinner'

const FontPairingView = ({
    isDarkMode,
    location: { search },
    history,
    selectedFontPairing,
    getFontMap,
    fontMapData,
    isFontMapDataLoading
}) => {
    const [isFontOptionsVisible, setIsFontOptionsVisible] = useState(false)
    const [selectedComponent, isSelectedComponent] = useState('')
    const ref = useRef()

    useEffect(() => {
        getFontMap()
        const checkIfClickedOutside = e => {
            if (isFontOptionsVisible && ref.current && !ref.current.contains(e.target)) {
                setIsFontOptionsVisible(false)
            }
        }
        document.addEventListener("mousedown", checkIfClickedOutside)
        return () => {
            document.removeEventListener("mousedown", checkIfClickedOutside)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isFontOptionsVisible])

    const handleSelectComponent = (componentName) => {
        setIsFontOptionsVisible(true)
        isSelectedComponent(componentName)
    }

    const handleFontMapSelect = (fontName) => {
        const queryObject = decodeURL(search)
        const fontPairing = { ...queryObject.fontPairing } || {}
        fontPairing[selectedComponent] = fontName

        const encodedUrl = encodeURL({
            ...queryObject,
            fontPairing
        })
        history.push(`?${encodedUrl}`)
        setIsFontOptionsVisible(false)
        isSelectedComponent('')
    }

    return (
        <div className='fontPairingView pageLoad'>
            <div className='fontPairingView_inner'>
                <SidebarLeft
                    componentsRequired={['linkList']} />
                <div className='fontPairingView_mainBody'>
                    <header className='fontPairingView_header'>
                        <p className='fontPairingView_header_mainHeadings'>Font Paring</p>
                    </header>
                    <FontPairing
                        isDarkMode={isDarkMode}
                        search={search}
                        history={history}
                        selectedFontPairing={selectedFontPairing}
                        handleSelectComponent={handleSelectComponent}
                    />
                    {isFontOptionsVisible &&
                        <div className='fontMapforPairing' ref={ref}>
                            {
                                isFontMapDataLoading ?
                                    <Spinner
                                        isDarkMode={isDarkMode} /> :
                                    fontMapData.map((item, index) =>
                                        <FontMapItem
                                            key={item.fontFamilyName + index}
                                            fontName={item.fontFamilyName}
                                            text={'A'}
                                            selectedFontMap={selectedFontPairing[selectedComponent]}
                                            className={'fontParingIcons'}
                                            handleFontMapClick={handleFontMapSelect}
                                            canBeSelected={true}
                                        />
                                    )}
                        </div>
                    }
                </div>
            </div>
        </div>
    )
}

const mapStateToProps = (state) => {
    const { selectedFontControlOptions,
        isDarkMode,
        selectedFontPairing
    } = state.selectedOptionsReducer

    const {
        fontMapData,
        isFontMapDataLoading
    } = state.incomingDataReducer
    return {
        selectedFontControlOptions,
        isDarkMode,
        selectedFontPairing,
        fontMapData,
        isFontMapDataLoading
    }
}

const mapDispatchToProps = {
    setSelectedFontOptions,
    getFontMap
}

export default container(FontPairingView, mapStateToProps, mapDispatchToProps)