import React from 'react'
import './Admin.scss'
import container from '../../common/container/container'
import Login from '../../components/Login/Login'
import { getAuth, logout } from '../../common/ukFonts.actions'
import AdminHome from './AdminHome/AdminHome'

const Admin = ({
    getAuth,
    logout,
    authentication
}) => {
    const { isLoading = false,
        error = '',
        isLoggedIn = false } = authentication

    return (
        <div className='admin'>
            {isLoggedIn ?
                <AdminHome
                    onClickLogout={() => logout()}
                /> :
                <Login
                    getAuth={getAuth}
                    isLoading={isLoading}
                    error={error}
                />
            }

        </div>
    )
}

const mapStateToProps = (state) => {
    const {
        authentication
    } = state.admin
    return {
        authentication
    }
}

const mapDispatchToProps = {
    getAuth,
    logout
}

export default container(Admin, mapStateToProps, mapDispatchToProps)