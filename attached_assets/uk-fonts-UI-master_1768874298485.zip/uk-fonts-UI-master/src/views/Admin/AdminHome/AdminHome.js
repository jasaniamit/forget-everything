import React from 'react'
import './AdminHome.scss'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs'
import AddFont from '../AddFont/AddFont'
import DeleteFont from '../DeleteFont/DeleteFont'
import Button from '../../../components/UI/Button/Button'

const AdminHome = ({
    onClickLogout
}) => {
    return (
        <div className='adminHome'>
            <Tabs>
                <TabList>
                    <Tab>Add Font</Tab>
                    <Tab>Delete Font</Tab>
                </TabList>

                <TabPanel>
                    <div className='tabHeadings'>
                        <p className='secondaryHeadings'>Add Font</p>
                    </div>
                    <AddFont />
                </TabPanel>
                <TabPanel>
                    <div className='tabHeadings'>
                        <p className='secondaryHeadings'>Delete Font</p>
                    </div>
                    <DeleteFont />
                </TabPanel>
            </Tabs>
            <div className='logoutButton'>
                <Button
                    isDisabled={false}
                    onClickEvent={onClickLogout}
                    isLoading={false}
                    buttonLong>
                    Logout
                </Button>
            </div>
        </div>
    )
}

export default AdminHome