import React, { useEffect, useState } from 'react'
import './AddCategory.scss'
import container from '../../../common/container/container'
import TextField from '../../../components/UI/TextField/TextField'
import { designerDetails, fontDetails } from '../../../common/constants/defaults'
import Button from '../../../components/UI/Button/Button'
import ChoiceGroupWithSearch from '../../../components/ChoiceGroupWithSearch/ChoiceGroupWithSearch'
import { getDesignersList, getstylesList, getCategoryNameList, uploadFile, submitFont } from '../../../common/ukFonts.actions'
import Spinner from '../../../components/UI/Spinner/Spinner'

const AddCategory = ({
    isDarkMode,
    designerList,
    isDesignerListLoading,
    getDesignersList,
    fontStylesList,
    isFontStylesList,
    categoriesList,
    isCategoriesListLoading,
    getstylesList,
    getCategoryNameList,
    submitFont,
    isFontSubmitLoading
}) => {
    const [formData, setFormData] = useState({})
    const [isNewDesigner, setisNewDesigner] = useState('')

    useEffect(() => {
        getstylesList()
        getCategoryNameList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        isNewDesigner === 'No' && getDesignersList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isNewDesigner])

    const onChangehandler = async (key, value) => {
        switch (key) {
            case 'designerProfileImage': {
                const data = await uploadFile(value, 'PICTURE')
                setFormData({
                    ...formData,
                    [key]: data
                })
                break
            }
            case 'fontImages': {
                const data = await uploadFile(value, 'PICTURE')
                setFormData({
                    ...formData,
                    [key]: data
                })
                break
            }
            case 'fontFile':
            case 'fontFileforBrowser':
            case 'fontFileZip':
                {
                    const data = await uploadFile(value, 'FONT')
                    setFormData({
                        ...formData,
                        [key]: data
                    })
                    break
                }
            default:
                setFormData({
                    ...formData,
                    [key]: value
                })
                break
        }

    }
    const onFormSubmit = (event) => {
        event.preventDefault()
        submitFont(formData)
    }

    const elementArray = (data) => {
        const elementArr = data.map((item, index) => {
            if (item.type === 'choiceGroup') {
                return <ChoiceGroupWithSearch
                    options={item.options}
                    isDarkMode={isDarkMode}
                    label={item.label}
                    defaultSelectedKey={item.defaultKey}
                    onChoiceGroupChange={(option) => onChangehandler(item.key, option)}
                />
            } else {
                return <TextField
                    key={index}
                    isDarkMode={isDarkMode}
                    handlerKey={item.key}
                    value={formData[item.key] || ''}
                    placeholder={item.placeholder}
                    labelText={item.label}
                    onChangeTextField={onChangehandler}
                    type={item.type}
                    required={item.required}
                    accept={item.accept}
                    multiple={item.multiple}
                />
            }
        })
        return elementArr
    }

    return (
        <div className='addCategory'>
            <form onSubmit={onFormSubmit}>
                <fieldset className={`fieldSet ${isDarkMode ? 'darkModeText' : 'lightModeText'}`} >
                    <legend className='legend'>Designer Info</legend>
                    {isNewDesigner ? isNewDesigner === 'Yes' ? elementArray(designerDetails) :
                        <ChoiceGroupWithSearch
                            options={designerList}
                            isDarkMode={isDarkMode}
                            label={'Designers'}
                            defaultSelectedKey={''}
                            onChoiceGroupChange={(option) => onChangehandler('designerId', option)}
                            isLoading={isDesignerListLoading}
                        /> :
                        < div className='choiceGroupSection' >
                            <p>Do you wanna add a new designer? </p>
                            <div className='choiceGroupSection_buttons'>
                                <Button
                                    isDisabled={false}
                                    onClickEvent={() => { setisNewDesigner('Yes') }}
                                    isLoading={false}>
                                    Yes
                                </Button>
                                <Button
                                    isDisabled={false}
                                    onClickEvent={() => { setisNewDesigner('No') }}
                                    isLoading={false}>
                                    No
                                </Button>
                            </div>
                        </div>

                    }
                </fieldset>
                <fieldset className={`fieldSet ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}>
                    <legend className='legend'>Font</legend>
                    {
                        elementArray(fontDetails)
                    }
                </fieldset>
                <fieldset className={`fieldSet ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}>
                    <legend className='legend'>Font Styles</legend>
                    {
                        isFontStylesList ? <Spinner /> :
                            fontStylesList.map((item, index) =>
                                <ChoiceGroupWithSearch
                                    key={index}
                                    options={item.options}
                                    isDarkMode={isDarkMode}
                                    label={item.label}
                                    defaultSelectedKey={item.defaultKey}
                                    onChoiceGroupChange={(option) => onChangehandler(item.key, option)}
                                    isLoading={item.required}
                                />)
                    }
                </fieldset>
                <fieldset className={`fieldSet ${isDarkMode ? 'darkModeText' : 'lightModeText'}`}>
                    <legend className='legend'>Font Info</legend>
                    <ChoiceGroupWithSearch
                        options={categoriesList}
                        isDarkMode={isDarkMode}
                        label={'Cstegories'}
                        defaultSelectedKey={''}
                        onChoiceGroupChange={(option) => onChangehandler('categories', option)}
                        isLoading={isCategoriesListLoading}
                    />
                </fieldset>
                <fieldset className='fieldSet'>
                    <div className='submitButton'>
                        <Button
                            isDisabled={false}
                            onClickEvent={() => { }}
                            isLoading={isFontSubmitLoading}
                            buttonLong
                            btnType={'submit'}>
                            Submit Font
                        </Button>
                    </div>
                </fieldset>
            </form>
        </div >
    )
}

const mapStateToProps = (state) => {
    const {
        isDarkMode
    } = state.selectedOptionsReducer

    const {
        designerList,
        isDesignerListLoading,
        fontStylesList,
        isFontStylesList,
        categoriesList,
        isCategoriesListLoading,
        isFontSubmitLoading
    } = state.admin
    return {
        isDarkMode,
        designerList,
        isDesignerListLoading,
        fontStylesList,
        isFontStylesList,
        categoriesList,
        isCategoriesListLoading,
        isFontSubmitLoading
    }
}

const mapDispatchToProps = {
    getDesignersList,
    getstylesList,
    getCategoryNameList,
    submitFont
}

export default container(AddCategory, mapStateToProps, mapDispatchToProps)