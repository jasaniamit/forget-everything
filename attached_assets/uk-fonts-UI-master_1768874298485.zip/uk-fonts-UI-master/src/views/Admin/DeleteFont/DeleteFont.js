import React, { useEffect, useState } from 'react'
import './DeleteFont.scss'
import container from '../../../common/container/container'
import Button from '../../../components/UI/Button/Button'
import ChoiceGroupWithSearch from '../../../components/ChoiceGroupWithSearch/ChoiceGroupWithSearch'
import { getFontNameList, deleteFont } from '../../../common/ukFonts.actions'
const DeleteFont = ({
    isDarkMode,
    fontList,
    isFontListLoading,
    getFontNameList,
    isDeleteFontLoading,
    deleteFont
}) => {
    const [formData, setFormData] = useState({})

    useEffect(() => {
        getFontNameList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    const onChangehandler = (key, value) => {
        setFormData({
            ...formData,
            [key]: value
        })
    }
    const onClickButton = (event) => {
        event.preventDefault()
        deleteFont(formData['fontId'])
        getFontNameList()
    }

    return (
        <div className='deleteFont'>
            <form onSubmit={onClickButton}>
                <fieldset className={`fieldSet ${isDarkMode ? 'darkModeText' : 'lightModeText'}`} >
                    <legend className='legend'>Select a font to delete</legend>
                    <ChoiceGroupWithSearch
                        options={fontList}
                        isDarkMode={isDarkMode}
                        label={'Font List'}
                        defaultSelectedKey={''}
                        onChoiceGroupChange={(option) => onChangehandler('fontId', option)}
                        isLoading={isFontListLoading}
                    />
                </fieldset>
                <fieldset className='fieldSet'>
                    <div className='submitButton'>
                        <Button
                            isDisabled={false}
                            onClickEvent={() => { }}
                            isLoading={isDeleteFontLoading}
                            buttonLong
                            btnType={'submit'}>
                            Delete font
                        </Button>
                    </div>
                </fieldset>
            </form>
        </div >
    )
}

const mapStateToProps = (state) => {
    const {
        isDarkMode
    } = state.selectedOptionsReducer

    const {
        fontList,
        isFontListLoading,
        isDeleteFontLoading
    } = state.admin
    return {
        isDarkMode,
        fontList,
        isFontListLoading,
        isDeleteFontLoading
    }
}

const mapDispatchToProps = {
    getFontNameList,
    deleteFont
}

export default container(DeleteFont, mapStateToProps, mapDispatchToProps)