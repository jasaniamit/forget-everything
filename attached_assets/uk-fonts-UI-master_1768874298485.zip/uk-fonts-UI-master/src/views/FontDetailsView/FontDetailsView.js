import React, { useEffect } from 'react'
import './FontDetailsView.scss'
import SidebarLeft from '../../components/Sidebar/SidebarLeft/SidebarLeft'
import SidebarRight from '../../components/Sidebar/SidebarRight/SidebarRight'
import SearchBar from '../../components/UI/SearchBar/SearchBar'
import container from '../../common/container/container'
import { isEmpty } from 'ramda'
import FontCategoryInfo from '../../components/FontCategoryInfo/FontCategoryInfo'
import FontImage from '../../components/FontCategory/FontImage/FontImage'
import { getFontInfo } from '../../common/ukFonts.actions'
import { Fragment } from 'react'
import Spinner from '../../components/UI/Spinner/Spinner'
import FontDetailTabs from '../../components/FontDetailTabs/FontDetailTabs'

const FontDetailsView = ({
    isDarkMode,
    location: { search, pathname },
    selectedFont,
    fontDetails = {},
    isFontDetailsLoading,
    getFontInfo
}) => {
    const { images = [], about = '' } = fontDetails
    useEffect(() => {
        selectedFont && getFontInfo()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFont])
    return (
        <div className='fontDetailsView pageLoad'>
            <div className='fontDetailsView_inner'>
                <div className='sidebarLeftContainer'>
                    <SidebarLeft
                        componentsRequired={['linkList']}
                        isRefreshRequired={true} />
                </div>
                <div className='mainBody'>
                    <SearchBar
                        placeholder='Search Fonts, Categories, Designers...' />
                    {
                        isFontDetailsLoading ? <Spinner /> :
                            <Fragment>
                                {fontDetails && !isEmpty(fontDetails) &&
                                    <div className='fontInfoContainer'>
                                        {
                                            about && <FontCategoryInfo
                                                itemData={fontDetails}
                                            />
                                        }
                                        {images.length > 0 &&
                                            <FontImage
                                                itemImageData={images}
                                            />}
                                    </div>}
                                <FontDetailTabs />
                            </Fragment>
                    }
                </div>
                <div className='sidebarRightContainer'>
                    <SidebarRight
                        componentsRequired={[]} />
                </div>
            </div>

        </div>
    )
}

const mapStateToProps = (state) => {
    const {
        isDarkMode,
        searchText,
        selectedFont
    } = state.selectedOptionsReducer

    const {
        fontDetails,
        isFontDetailsLoading,
    } = state.incomingDataReducer
    return {
        isDarkMode,
        searchText,
        selectedFont,
        fontDetails,
        isFontDetailsLoading,
    }
}

const mapDispatchToProps = {
    getFontInfo
}

export default container(FontDetailsView, mapStateToProps, mapDispatchToProps)