import React, { useEffect } from 'react'
import './FontCategoryView.scss'
import SidebarLeft from '../../components/Sidebar/SidebarLeft/SidebarLeft'
import SidebarRight from '../../components/Sidebar/SidebarRight/SidebarRight'
import SearchBar from '../../components/UI/SearchBar/SearchBar'
import FontCategory from '../../components/FontCategory/FontCategory'
import container from '../../common/container/container'
import { isEmpty } from 'ramda'
import FontCategoryInfo from '../../components/FontCategoryInfo/FontCategoryInfo'
import FontImage from '../../components/FontCategory/FontImage/FontImage'
import FontCategoryTabs from '../../components/FontCategoryTabs/FontCategoryTabs'
import { getCategoryInfo, getSearchCategoryList } from '../../common/ukFonts.actions'
import { Fragment } from 'react'
import Spinner from '../../components/UI/Spinner/Spinner'
import CategoryList from '../../components/CategoryList/CategoryList'

const FontCategoryView = ({
    isDarkMode,
    location: { search, pathname },
    history,
    searchText,
    selectedFontCategory,
    getCategoryInfo,
    fontCategoryData = {},
    isFontCategoryDataLoading,
    searchCategoryList,
    isSearchCategoryListLoading,
    getSearchCategoryList,
    selectedPage
}) => {
    const { images = [], about = '' } = fontCategoryData

    const categoryInfo = () => isFontCategoryDataLoading ? <Spinner /> :
        <Fragment>
            <FontCategory
                isDarkMode={isDarkMode}
                search={search}
                pathname={pathname}
                history={history}
                selectedFontCategory={selectedFontCategory} />
            {fontCategoryData && !isEmpty(fontCategoryData) &&
                <div className='fontInfoContainer'>
                    {
                        about && <FontCategoryInfo
                            itemData={fontCategoryData}
                        />
                    }
                    {images.length > 0 &&
                        <FontImage
                            itemImageData={images}
                        />}
                </div>}
            <FontCategoryTabs />
        </Fragment>

    const categoryList = () => <CategoryList
        isDarkMode={isDarkMode}
        isLoading={isSearchCategoryListLoading}
        options={searchCategoryList['data']}
        count={searchCategoryList['count']}
        search={search}
        history={history}
        isPaginationRequired={true}
        selectedPage={selectedPage}
    />

    useEffect(() => {
        if (selectedFontCategory) {
            getCategoryInfo()
        } else {
            getSearchCategoryList()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFontCategory])

    return (
        <div className='fontCategoryView pageLoad'>
            <div className='fontCategoryView_inner'>
                <div className='sidebarLeftContainer'>
                    <SidebarLeft
                        componentsRequired={['linkList']}
                        isRefreshRequired={true} />
                </div>
                <div className='mainBody'>
                    <SearchBar
                        placeholder='Search Fonts, Categories, Designers...' />
                    {
                        selectedFontCategory ? categoryInfo() : categoryList()
                    }
                </div>
                <div className='sidebarRightContainer'>
                    <SidebarRight
                        componentsRequired={[]} />
                </div>
            </div>

        </div>
    )
}

const mapStateToProps = (state) => {
    const {
        isDarkMode,
        searchText,
        selectedFontCategory,
        selectedPage
    } = state.selectedOptionsReducer

    const {
        fontCategoryData,
        isFontCategoryDataLoading,
        searchCategoryList,
        isSearchCategoryListLoading,
    } = state.incomingDataReducer
    return {
        isDarkMode,
        searchText,
        selectedFontCategory,
        fontCategoryData,
        isFontCategoryDataLoading,
        searchCategoryList,
        isSearchCategoryListLoading,
        selectedPage
    }
}

const mapDispatchToProps = {
    getCategoryInfo,
    getSearchCategoryList
}

export default container(FontCategoryView, mapStateToProps, mapDispatchToProps)