import React, { Fragment, useEffect } from 'react'
import './Home.scss'
import SidebarLeft from './../../components/Sidebar/SidebarLeft/SidebarLeft'
import SidebarRight from './../../components/Sidebar/SidebarRight/SidebarRight'
import SearchBar from '../../components/UI/SearchBar/SearchBar'
import FontCategory from '../../components/FontCategory/FontCategory'
import FontControls from '../../components/FontControls/FontControls'
import FontsList from '../../components/FontsList/FontsList'
import container from './../../common/container/container'
import { getFontList } from '../../common/ukFonts.actions'
import CategoryList from '../../components/CategoryList/CategoryList'
import DesignerList from '../../components/DesignerList/DesignerList'

const Home = ({
    selectedFontControlOptions,
    isDarkMode,
    location: { search, pathname },
    history,
    selectedAlphabet,
    getFontList,
    fontListData,
    isFontListLoading,
    selectedProperties,
    selectedPage,
    selectedSearchType,
    searchCategoryList,
    isSearchCategoryListLoading,
    searchDesignerList,
    isSearchDesignerListLoading
}) => {
    useEffect(() => {
        getFontList()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFontControlOptions.isCommercial, selectedPage, selectedAlphabet, selectedProperties])

    const selectedHomeComponents = () => {
        switch (selectedSearchType) {
            case 'font':
            case '':
                return <Fragment>
                    <FontControls
                        isDarkMode={isDarkMode}
                        selectedFontControlOptions={selectedFontControlOptions}
                        search={search}
                        history={history}
                    />
                    <FontsList
                        isDarkMode={isDarkMode}
                        isLoading={isFontListLoading}
                        options={fontListData['data']}
                        count={fontListData['count']}
                        selectedFontControlOptions={selectedFontControlOptions}
                        search={search}
                        history={history}
                        isPaginationRequired={true}
                        selectedPage={selectedPage} />
                </Fragment>
            case 'category':
                return <CategoryList
                    isDarkMode={isDarkMode}
                    isLoading={isSearchCategoryListLoading}
                    options={searchCategoryList['data']}
                    count={searchCategoryList['count']}
                    search={search}
                    history={history}
                    isPaginationRequired={true}
                    selectedPage={selectedPage}
                />
            case 'designer':
                return <DesignerList
                    isDarkMode={isDarkMode}
                    isLoading={isSearchDesignerListLoading}
                    options={searchDesignerList['data']}
                    count={searchDesignerList['count']}
                    search={search}
                    history={history}
                    isPaginationRequired={true}
                    selectedPage={selectedPage}
                />
            default:
                break
        }

    }
    return (
        <div className='home pageLoad'>
            <div className='home_inner'>
                <div className='sidebarLeftContainer'>
                    <SidebarLeft
                        componentsRequired={['linkList', 'fontProperties', 'alphabets']}
                        isRefreshRequired={true} />
                </div>
                <div className='mainBody'>
                    <SearchBar
                        placeholder='Search Fonts, Categories, Designers...'
                    />
                    <FontCategory
                        isDarkMode={isDarkMode}
                        search={search}
                        pathname={pathname}
                        history={history} />
                    {
                        selectedHomeComponents()
                    }
                </div>
                <div className='sidebarRightContainer'>
                    <SidebarRight
                        componentsRequired={['sidebarCategories']} />
                </div>
            </div>
        </div>
    )
}

const mapStateToProps = (state) => {
    const { selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontCategory,
        selectedProperties,
        selectedPage,
        selectedSearchType
    } = state.selectedOptionsReducer

    const {
        fontListData,
        isFontListLoading,
        searchCategoryList,
        isSearchCategoryListLoading,
        searchDesignerList,
        isSearchDesignerListLoading
    } = state.incomingDataReducer
    return {
        selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontCategory,
        fontListData,
        isFontListLoading,
        selectedProperties,
        selectedPage,
        selectedSearchType,
        searchCategoryList,
        isSearchCategoryListLoading,
        searchDesignerList,
        isSearchDesignerListLoading
    }
}

const mapDispatchToProps = {
    getFontList,
}

export default container(Home, mapStateToProps, mapDispatchToProps)