import React, { useEffect } from 'react'
import './FontMapView.scss'
import SidebarLeft from '../../components/Sidebar/SidebarLeft/SidebarLeft'
import SidebarRight from '../../components/Sidebar/SidebarRight/SidebarRight'
import container from '../../common/container/container'
import { setSelectedFontOptions } from '../../common/actions/actionsDispatcher'
import Alphabets from '../../components/Alphabets/Alphabets'
import FontMap from '../../components/FontMap/FontMap'
import { getFontMap } from '../../common/ukFonts.actions'
import Spinner from '../../components/UI/Spinner/Spinner'

const FontMapView = ({
    setSelectedFontOptions,
    selectedFontControlOptions,
    isDarkMode,
    location: { search },
    history,
    searchText,
    selectedAlphabet,
    selectedFontMap,
    getFontMap,
    fontMapData,
    isFontMapDataLoading
}) => {

    useEffect(() => {
        getFontMap()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    return (
        <div className='fontMapView pageLoad'>
            <div className='fontMapView_inner'>
                <SidebarLeft
                    componentsRequired={['linkList']} />
                <div className='mainBody'>
                    <header className='fontMapView_header'>
                        <div className='fontMapView_header_inner'>
                            <p className='mainHeadings'>Font Map</p>
                            <Alphabets
                                isDarkMode={isDarkMode}
                                selectedAlphabet={selectedAlphabet}
                                history={history}
                                search={search} />
                        </div>
                    </header>
                    <div className='mainBody_inner'>
                        {
                            isFontMapDataLoading ? <Spinner
                                isDarkMode={isDarkMode} /> :
                                <FontMap
                                    isDarkMode={isDarkMode}
                                    options={fontMapData}
                                    selectedAlphabet={selectedAlphabet}
                                    selectedFontMap={selectedFontMap}
                                    history={history}
                                    search={search}
                                />
                        }
                    </div>
                </div>
                <SidebarRight />
            </div>

        </div>
    )
}

const mapStateToProps = (state) => {
    const { selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontMap
    } = state.selectedOptionsReducer

    const {
        fontMapData,
        isFontMapDataLoading
    } = state.incomingDataReducer
    return {
        selectedFontControlOptions,
        isDarkMode,
        searchText,
        selectedAlphabet,
        selectedFontMap,
        fontMapData,
        isFontMapDataLoading
    }
}

const mapDispatchToProps = {
    setSelectedFontOptions,
    getFontMap
}

export default container(FontMapView, mapStateToProps, mapDispatchToProps)